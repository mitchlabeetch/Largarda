# LARGO 2.0 — QUICK START GUIDE

> **For**: Christophe Berthon, Managing Partner — Alecia M&A  
> **Version**: 2.0  
> **Reading time**: 10 minutes

---

## 🎯 Ce que fait Largo 2.0

Largo est votre **assistant IA dédié aux opérations de fusion-acquisition** pour PME et ETI françaises (focus Côte d'Azur).

### Capacités principales

| Fonction | Description | Temps économisé |
|----------|-------------|-----------------|
| 🔍 **Recherche entreprise** | Analyse complète SIRENE + Pappers + scoring M&A | 2h → 30s |
| 💰 **Valorisation** | Multiples sectoriels, ajustements, fourchette EV/Equity | 4h → 1min |
| 📊 **Génération documents** | PowerPoint, Excel, Word depuis templates | 3h → 2min |
| 📱 **Communication** | WhatsApp, Email, réponses intelligentes | Instantané |
| 📈 **Veille M&A** | Résumé quotidien des actualités | 1h/jour → automatique |
| 🤖 **Enrichissement prospects** | Recherche multi-sources, scoring | 1h → 2min |

---

## 🚀 Démarrage en 5 minutes

### Étape 1 : Premier message à Largo

**Via WhatsApp** (recommandé) :
```
"Largo, recherche l'entreprise SIREN 123 456 789"
```

**Réponse attendue** (30 secondes) :
- Fiche entreprise complète
- Scoring attractivité M&A (1-10)
- Risques et opportunités identifiés
- Recommandations de prochaines étapes

### Étape 2 : Valorisation rapide

```
"Largo, valorise cette entreprise : EBITDA 2M€, secteur tech, 50 salariés"
```

**Réponse** :
- Fourchette valeur entreprise : 12-18M€
- Multiple appliqué : 6-9x EBITDA
- Analyse de sensibilité
- Recommandations de négociation

### Étape 3 : Génération document

```
"Largo, crée un teaser pour [nom entreprise]"
```

**Résultat** :
- PowerPoint professionnel généré
- Template Alecia branding
- Reçu par WhatsApp + Email

---

## 📱 Commandes principales

### Recherche & Analyse

| Commande | Exemple | Résultat |
|----------|---------|----------|
| `recherche [SIREN/nom]` | `recherche 123456789` | Fiche complète |
| `analyse [entreprise]` | `analyse TechCorp` | Scoring M&A |
| `valorise [params]` | `valorise EBITDA 1M€ secteur industrie` | Fourchette valeur |
| `comparables [secteur]` | `comparables tech` | Transactions similaires |

### Documents

| Commande | Exemple | Résultat |
|----------|---------|----------|
| `crée teaser [entreprise]` | `crée teaser TechCorp` | PowerPoint teaser |
| `crée profil [entreprise]` | `crée profil TechCorp` | Company profile |
| `crée valuation [entreprise]` | `crée valuation TechCorp` | Rapport valorisation |
| `crée résumé [projet]` | `crée résumé Projet Alpha` | Executive summary |

### Veille & Prospection

| Commande | Description |
|----------|-------------|
| `briefing du jour` | Résumé actualités M&A |
| `veille [secteur]` | Alertes sectorielles |
| `enrichis [contact]` | Enrichissement prospect |

---

## 💡 Workflows automatiques (n8n)

### 1. Briefing M&A Quotidien

**Déclencheur** : Tous les jours à 8h00  
**Actions** :
- Agrège actualités (Les Echos, La Tribune, Capital Finance)
- Analyse par Kimi
- Envoie résumé WhatsApp + Email

**Résultat** : Vous recevez chaque matin :
```
📊 BRIEFING M&A DU JOUR — 18 Mars 2026

🔥 TOP 3 OPÉRATIONS
1. [Deal 1] - Acquéreur X rachète Cible Y pour ZM€
2. [Deal 2] - ...
3. [Deal 3] - ...

📈 TENDANCES
- Secteur Tech : +15% de transactions
- Multiples moyens : 8.2x EBITDA

🎯 OPPORTUNITÉS POUR ALECIA
- 2 cibles potentielles identifiées
- Contact à activer : [nom]

_15 articles analysés | Largo 2.0_
```

### 2. Enrichissement Prospect

**Déclencheur** : Nouveau contact dans Pipedrive  
**Actions** :
- Recherche SIRENE + Pappers
- Analyse LinkedIn + Clearbit
- Scoring M&A automatique
- Création fiche enrichie

### 3. Réponse Messages

**Déclencheur** : Message WhatsApp/Email reçu  
**Actions** :
- Détection intention (recherche, valuation, document)
- Réponse automatique si simple
- Escalade à vous si complexe

---

## 🔧 Configuration personnelle

### Vos préférences (éditer dans n8n)

```json
{
  "name": "Christophe Berthon",
  "communication": ["whatsapp", "email"],
  "whatsapp_number": "+336XXXXXXXX",
  "email": "christophe.berthon@alecia.fr",
  "reporting_time": "08:00",
  "sectors_of_interest": ["tech", "industrie", "services", "biotech"],
  "regions_of_interest": ["paca", "idf", "aura"],
  "deal_size_min": 2000000,
  "deal_size_max": 50000000
}
```

### Canaux de communication

| Canal | Statut | Utilisation |
|-------|--------|-------------|
| WhatsApp | ✅ Actif | Messages rapides, alertes |
| Email | ✅ Actif | Documents, rapports détaillés |
| Slack | ⚙️ Configurable | Équipe interne |
| Teams | ⚙️ Configurable | Réunions, collaboration |

---

## 📊 Coûts mensuels

| Service | Coût | Usage |
|---------|------|-------|
| VPS (Contabo/Hetzner) | 15€ | Infrastructure |
| Kimi API | ~3€ | 6M tokens/mois |
| Pappers API | 0€ (gratuit) | Enrichissement |
| n8n | 0€ (self-hosted) | Workflows |
| **TOTAL** | **~18€/mois** | vs ~180€/mois OpenClaw |

**Économie** : ~90% de réduction

---

## 🆘 Support & Dépannage

### Problèmes courants

| Problème | Solution |
|----------|----------|
| Largo ne répond pas | Vérifier statut : `largo status` |
| WhatsApp déconnecté | Scanner QR code : `https://votre-server:8003/qr` |
| Erreur API | Vérifier clés dans `.env` |
| Base de données lente | Redémarrer : `largo restart` |

### Commandes de gestion

```bash
# Voir statut
largo status

# Voir logs
largo logs n8n

# Redémarrer service
largo restart

# Backup manuel
largo backup

# Accès base de données
largo shell postgres
```

### Contact support

- **Email** : support@largo.fr
- **WhatsApp** : Message direct à Largo avec "support"
- **Documentation** : https://docs.largo.fr

---

## 📚 Ressources

### Documentation complète

| Document | Description |
|----------|-------------|
| [INDEX.md](INDEX.md) | Navigation complète |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Architecture technique |
| [SKILLS.md](SKILLS.md) | Capacités détaillées |
| [WORKFLOWS.md](WORKFLOWS.md) | Workflows n8n |

### Scripts Python

```python
# Recherche entreprise
from scripts.mna.france_mna import FranceMNAResearcher
researcher = FranceMNAResearcher()
result = researcher.full_research("123456789")

# Valorisation
from scripts.mna.valuation import ValuationEngine
engine = ValuationEngine()
result = engine.valuate_by_multiples(ebitda=1000000, sector="tech")

# Génération PowerPoint
from scripts.documents.pptx_generator import PowerPointGenerator
generator = PowerPointGenerator()
generator.generate(template="teaser", data={"company": "TechCorp"})
```

---

## 🎯 Roadmap & Évolutions

### Version 2.1 (Q2 2026)
- [ ] Intégration Microsoft 365 complète
- [ ] Assistant vocal (appels)
- [ ] Prédiction deals (ML)

### Version 2.2 (Q3 2026)
- [ ] Due diligence automatisée
- [ ] Matching acheteurs/cibles
- [ ] Tableau de bord temps réel

---

## ✨ Philosophie Largo

> **"Ma force n'est pas de tout FAIRE, mais de tout APPRENDRE"**

Largo s'améliore avec chaque interaction :
- Apprend vos préférences
- Mémorise vos décisions
- Suggère des actions proactives
- Devient plus pertinent chaque jour

---

*Largo 2.0 — Votre partenaire M&A augmenté par l'IA*

**Généré** : 18 Mars 2026  
**Version** : 2.0.0  
**Statut** : Production Ready
