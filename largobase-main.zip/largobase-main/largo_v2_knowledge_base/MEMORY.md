# MEMORY.md — Système de Mémoire Largo 2.0

> Version: 2.0 — PostgreSQL + n8n Architecture
> Last Updated: 2026-03-18

---

## 🧠 Architecture de Mémoire

Largo 2.0 utilise une architecture de mémoire hybride:

```
┌─────────────────────────────────────────────────────────────┐
│                    MEMORY ARCHITECTURE                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              SHORT-TERM (Session)                      │  │
│  │  • n8n execution context                              │  │
│  │  • Durée: 1 conversation                              │  │
│  │  • Size: ~4K-8K tokens                                │  │
│  └───────────────────────────────────────────────────────┘  │
│                            │                                 │
│  ┌─────────────────────────▼─────────────────────────────┐  │
│  │              MEDIUM-TERM (PostgreSQL)                  │  │
│  │  • Conversations historiques                          │  │
│  │  • Préférences utilisateur                            │  │
│  │  • Dossiers M&A actifs                                │  │
│  │  • Durée: 90 jours (configurable)                     │  │
│  └───────────────────────────────────────────────────────┘  │
│                            │                                 │
│  ┌─────────────────────────▼─────────────────────────────┐  │
│  │              LONG-TERM (Files + Vector DB)             │  │
│  │  • current_deal.md                                    │  │
│  │  • MEMORY.md                                          │  │
│  │  • preferences_*.md                                   │  │
│  │  • Vector embeddings (pgvector)                       │  │
│  │  • Durée: Permanent                                   │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 Fichiers de Mémoire

### 1. current_deal.md — Dossier Actif M&A

**Usage** : Dossier M&A en cours d'analyse

**Structure** :
```markdown
# Current Deal: [Nom entreprise]

## Identité
- **Nom** : [Nom]
- **SIRET** : [SIRET]
- **SIREN** : [SIREN]
- **Secteur** : [Secteur]
- **Localisation** : [Ville]

## Données Clés
| Métrique | Valeur | Année |
|----------|--------|-------|
| CA | X M€ | 2025 |
| EBE | X M€ | 2025 |
| Effectif | XX | 2025 |

## Contacts
- **Cédant** : [Nom, téléphone, email]
- **Intermédiaire** : [Nom, téléphone, email]

## Statut
- **Phase** : [Approche/LOI/DD/Closing]
- **Priorité** : [Haute/Moyenne/Basse]
- **Prochaine action** : [Action + date]

## Notes
- [Note importante 1]
- [Note importante 2]

## Documents
- [ ] Teaser
- [ ] IM
- [ ] Derniers comptes
- [ ] Prévisionnel

## Timeline
- [Date] : [Événement]
```

**Règles** :
- 🔴 **UN SEUL** current_deal actif à la fois
- 🟡 Archivage automatique quand deal fermé
- 🟢 Mise à jour en temps réel

---

### 2. MEMORY.md — Mémoire Long-Terme

**Usage** : Informations persistantes sur Christophe et ses préférences

**Structure** :
```markdown
# MEMORY.md — Largo Memory

## Profil Christophe
- **Prénom préféré** : Christophe (pas "Chris", pas "M. Berthon")
- **Ton** : Tutoiement jovial
- **Humour** : Oui, léger

## Préférences Communication
- **Canal principal** : WhatsApp
- **Canal documents** : Email
- **Format résumés** : Concis, bullet points
- **Audio** : Accepte vocaux

## Préférences Documents
- **Excel** : Formules visibles, pas de macros
- **PowerPoint** : Templates Alecia, couleurs brand
- **Polices** : 
  - Documents internes : Arial
  - Documents clients : Calibri

## Préférences M&A
- **Multiples sectoriels** : Préfère fourchettes basses
- **Analyse** : Focus rentabilité, pas croissance
- **Risques** : Toujours mentionner les 3 principaux

## Routines
- **9h** : Résumé M&A quotidien
- **45 min avant réunion** : Briefing prospect

## Informations Personnelles (Stockées avec permission)
- Famille : Sylvie (épouse), Lisa (fille), Michaël (fils)
- Localisation : Côte d'Azur
- Aucune autre info sans autorisation explicite

## Historique Modifications
- 2026-03-18 : Création mémoire
- [Date] : [Modification]
```

---

### 3. preferences_*.md — Préférences Spécifiques

**Fichiers** :
- `preferences_communication.md`
- `preferences_documents.md`
- `preferences_research.md`
- `preferences_transport.md`

**Structure exemple** (preferences_transport.md) :
```markdown
# Préférences Transport

## Compagnies Aériennes
- **Préférée** : Air France (si prix similaire à low-cost)
- **Low-cost acceptable** : EasyJet, Transavia
- **À éviter** : Ryanair (sauf cas exceptionnel)

## Trains
- **Préféré** : TGV INOUI
- **OUIGE acceptable** : Si économie significative

## Hôtels
- **Catégorie** : 4 étoiles minimum
- **Chaînes préférées** : Marriott, Accor
- **Booking** : Direct si possible

## Règles
- Si vol AF et EasyJet < 50€ différence → AF
- Si train < 3h → préférer train à avion
- Hôtel centre-ville si réunion en centre
```

---

## 🗄️ Schéma PostgreSQL

### Table `conversations`

```sql
CREATE TABLE conversations (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL DEFAULT gen_random_uuid(),
    user_id VARCHAR(255) NOT NULL DEFAULT 'christophe',
    channel VARCHAR(50) NOT NULL, -- whatsapp, email, slack
    
    -- Messages stockés en JSONB
    messages JSONB NOT NULL DEFAULT '[]',
    
    -- Métadonnées
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Index pour recherche
    search_vector TSVECTOR,
    
    -- Contraintes
    CONSTRAINT valid_channel CHECK (channel IN ('whatsapp', 'email', 'slack', 'teams'))
);

-- Index
CREATE INDEX idx_conversations_session ON conversations(session_id);
CREATE INDEX idx_conversations_user ON conversations(user_id);
CREATE INDEX idx_conversations_updated ON conversations(updated_at DESC);
CREATE INDEX idx_conversations_search ON conversations USING GIN(search_vector);

-- Trigger pour mise à jour updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_conversations_updated_at 
    BEFORE UPDATE ON conversations 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();
```

### Table `preferences`

```sql
CREATE TABLE preferences (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL DEFAULT 'christophe',
    category VARCHAR(100) NOT NULL, -- communication, documents, style
    key VARCHAR(255) NOT NULL,
    value JSONB NOT NULL,
    
    -- Contexte
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    source VARCHAR(500), -- Où la préférence a été apprise
    
    -- Contrainte unique
    CONSTRAINT unique_preference UNIQUE (user_id, category, key)
);

CREATE INDEX idx_preferences_user ON preferences(user_id);
CREATE INDEX idx_preferences_category ON preferences(category);
```

### Table `deals`

```sql
CREATE TABLE deals (
    id SERIAL PRIMARY KEY,
    deal_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(500) NOT NULL,
    
    -- Identification
    siret VARCHAR(14),
    siren VARCHAR(9),
    
    -- Statut
    status VARCHAR(50) NOT NULL DEFAULT 'active', -- active, closed, on_hold, lost
    phase VARCHAR(50), -- approach, loi, dd, closing
    priority VARCHAR(20) DEFAULT 'medium', -- high, medium, low
    
    -- Données
    data JSONB NOT NULL DEFAULT '{}',
    
    -- Timeline
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    closed_at TIMESTAMP WITH TIME ZONE,
    
    -- Index
    CONSTRAINT valid_status CHECK (status IN ('active', 'closed', 'on_hold', 'lost')),
    CONSTRAINT valid_phase CHECK (phase IN ('approach', 'loi', 'dd', 'closing', NULL))
);

CREATE INDEX idx_deals_siret ON deals(siret);
CREATE INDEX idx_deals_status ON deals(status);
CREATE INDEX idx_deals_phase ON deals(phase);
```

### Table `documents`

```sql
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    doc_id VARCHAR(255) UNIQUE NOT NULL,
    deal_id VARCHAR(255) REFERENCES deals(deal_id),
    
    -- Métadonnées
    filename VARCHAR(500) NOT NULL,
    file_type VARCHAR(50), -- pdf, xlsx, pptx
    file_size INTEGER,
    
    -- Stockage
    storage_path VARCHAR(1000),
    
    -- Analyse
    extracted_text TEXT,
    extracted_data JSONB,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Vector embedding pour recherche sémantique
    embedding VECTOR(1536)
);

CREATE INDEX idx_documents_deal ON documents(deal_id);
CREATE INDEX idx_documents_embedding ON documents USING ivfflat (embedding vector_cosine_ops);
```

---

## 🔄 Workflows de Mémoire

### 1. Sauvegarde Conversation

**Trigger** : Fin de chaque interaction

**n8n Workflow** :
```
Webhook (fin conversation)
    ↓
Parse messages
    ↓
Insert/Update PostgreSQL
    ↓
Update search_vector
```

### 2. Récupération Contexte

**Trigger** : Début de chaque interaction

**n8n Workflow** :
```
Webhook (début conversation)
    ↓
Query PostgreSQL (dernières 10 conversations)
    ↓
Query preferences
    ↓
Read current_deal.md
    ↓
Assemble context
    ↓
Pass to LLM
```

### 3. Apprentissage Préférence

**Trigger** : Détection de préférence dans message

**n8n Workflow** :
```
Message analysis (Kimi)
    ↓
Detect preference pattern
    ↓
Extract: category, key, value
    ↓
Insert/Update preferences table
    ↓
Update fichier .md si critique
    ↓
Confirm to user
```

---

## 🔍 Recherche Sémantique

### Installation pgvector

```sql
-- Activer extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Créer index pour recherche sémantique
CREATE INDEX ON documents 
USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);
```

### Recherche par similarité

```sql
-- Recherche documents similaires
SELECT 
    doc_id, 
    filename, 
    1 - (embedding <=> query_embedding) AS similarity
FROM documents
WHERE 1 - (embedding <=> query_embedding) > 0.7
ORDER BY similarity DESC
LIMIT 5;
```

---

## 💾 Backup & Recovery

### Backup Quotidien

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d)
BACKUP_DIR="/backups/postgres"

# Dump PostgreSQL
docker-compose exec -T postgres pg_dump -U largo largo_memory > "$BACKUP_DIR/largo_$DATE.sql"

# Compress
gzip "$BACKUP_DIR/largo_$DATE.sql"

# Upload S3
aws s3 cp "$BACKUP_DIR/largo_$DATE.sql.gz" s3://largo-backups/postgres/

# Cleanup local (keep 7 days)
find "$BACKUP_DIR" -name "largo_*.sql.gz" -mtime +7 -delete
```

### Recovery

```bash
#!/bin/bash
# restore.sh

BACKUP_FILE=$1

# Drop and recreate database
docker-compose exec postgres dropdb -U largo largo_memory
docker-compose exec postgres createdb -U largo largo_memory

# Restore
gunzip -c "$BACKUP_FILE" | docker-compose exec -T postgres psql -U largo largo_memory
```

---

## 📊 Monitoring Mémoire

### Métriques

```sql
-- Taille des tables
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Nombre de conversations
SELECT COUNT(*) as total_conversations FROM conversations;

-- Conversations par jour
SELECT 
    DATE(created_at) as date,
    COUNT(*) as count
FROM conversations
WHERE created_at > NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;
```

---

*Largo 2.0 — Mémoire persistante, apprentissage continu.*
