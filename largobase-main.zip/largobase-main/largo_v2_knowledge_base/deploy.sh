#!/bin/bash
#
# Largo 2.0 - Deployment Script
# Automates VPS setup and Largo deployment
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
LARGO_VERSION="2.0.0"
INSTALL_DIR="/opt/largo"
DOCKER_COMPOSE_VERSION="2.24.0"

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root or with sudo"
        exit 1
    fi
}

# Detect OS
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    else
        log_error "Cannot detect OS"
        exit 1
    fi
    
    log_info "Detected OS: $OS $VER"
}

# Update system packages
update_system() {
    log_info "Updating system packages..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        apt-get update -qq
        apt-get upgrade -y -qq
        apt-get install -y -qq curl wget git ufw fail2ban
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        yum update -y -q
        yum install -y -q curl wget git firewalld fail2ban
    fi
    
    log_success "System updated"
}

# Install Docker
install_docker() {
    log_info "Installing Docker..."
    
    if command -v docker &> /dev/null; then
        log_warn "Docker already installed, skipping"
        return
    fi
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        # Remove old versions
        apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
        
        # Install prerequisites
        apt-get install -y -qq ca-certificates gnupg lsb-release
        
        # Add Docker's official GPG key
        mkdir -p /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        
        # Set up repository
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
        
        # Install Docker
        apt-get update -qq
        apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
        
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        # Add Docker repository
        yum install -y -q yum-utils
        yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
        
        # Install Docker
        yum install -y -q docker-ce docker-ce-cli containerd.io docker-compose-plugin
    fi
    
    # Start and enable Docker
    systemctl start docker
    systemctl enable docker
    
    log_success "Docker installed"
}

# Install Docker Compose
install_docker_compose() {
    log_info "Installing Docker Compose..."
    
    if docker compose version &> /dev/null; then
        log_warn "Docker Compose already installed, skipping"
        return
    fi
    
    # Install Docker Compose plugin
    DOCKER_CONFIG=${DOCKER_CONFIG:-$HOME/.docker}
    mkdir -p $DOCKER_CONFIG/cli-plugins
    curl -SL https://github.com/docker/compose/releases/download/v$DOCKER_COMPOSE_VERSION/docker-compose-linux-x86_64 -o $DOCKER_CONFIG/cli-plugins/docker-compose
    chmod +x $DOCKER_CONFIG/cli-plugins/docker-compose
    
    log_success "Docker Compose installed"
}

# Setup firewall
setup_firewall() {
    log_info "Configuring firewall..."
    
    if command -v ufw &> /dev/null; then
        # Ubuntu/Debian with UFW
        ufw default deny incoming
        ufw default allow outgoing
        ufw allow ssh
        ufw allow 80/tcp
        ufw allow 443/tcp
        ufw allow 5678/tcp  # n8n
        
        # Enable UFW non-interactively
        echo "y" | ufw enable
        
        log_success "UFW firewall configured"
        
    elif command -v firewall-cmd &> /dev/null; then
        # CentOS/RHEL with firewalld
        systemctl start firewalld
        systemctl enable firewalld
        
        firewall-cmd --permanent --add-service=ssh
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --permanent --add-port=5678/tcp
        firewall-cmd --reload
        
        log_success "Firewalld configured"
    fi
}

# Setup fail2ban
setup_fail2ban() {
    log_info "Configuring fail2ban..."
    
    systemctl start fail2ban
    systemctl enable fail2ban
    
    # Create custom jail for SSH
    cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
EOF
    
    systemctl restart fail2ban
    log_success "Fail2ban configured"
}

# Create Largo directories
setup_directories() {
    log_info "Setting up Largo directories..."
    
    mkdir -p $INSTALL_DIR
    mkdir -p $INSTALL_DIR/data/postgres
    mkdir -p $INSTALL_DIR/data/redis
    mkdir -p $INSTALL_DIR/data/n8n
    mkdir -p $INSTALL_DIR/data/minio
    mkdir -p $INSTALL_DIR/logs
    mkdir -p $INSTALL_DIR/backups
    
    log_success "Directories created"
}

# Generate environment file
generate_env() {
    log_info "Generating environment configuration..."
    
    # Generate random passwords
    POSTGRES_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    REDIS_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    N8N_ENCRYPTION_KEY=$(openssl rand -base64 32)
    MINIO_ROOT_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    JWT_SECRET=$(openssl rand -base64 32)
    
    cat > $INSTALL_DIR/.env << EOF
# Largo 2.0 Environment Configuration
# Generated: $(date)

# Domain Configuration
DOMAIN=${DOMAIN:-largo.local}
N8N_WEBHOOK_URL=https://\${DOMAIN}/n8n/

# Database Configuration
POSTGRES_USER=largo
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
POSTGRES_DB=largo
DATABASE_URL=postgresql://largo:$POSTGRES_PASSWORD@postgres:5432/largo

# Redis Configuration
REDIS_PASSWORD=$REDIS_PASSWORD
REDIS_URL=redis://:$REDIS_PASSWORD@redis:6379/0

# n8n Configuration
N8N_ENCRYPTION_KEY=$N8N_ENCRYPTION_KEY
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=changeme
N8N_PORT=5678
N8N_PROTOCOL=https
N8N_SSL_CERT=/certs/cert.pem
N8N_SSL_KEY=/certs/key.pem

# MinIO Configuration
MINIO_ROOT_USER=largo
MINIO_ROOT_PASSWORD=$MINIO_ROOT_PASSWORD
MINIO_BROWSER=on

# API Keys (to be filled in)
KIMI_API_KEY=your_kimi_api_key_here
PAPPERS_API_KEY=your_pappers_api_key_here
LINKEDIN_API_TOKEN=your_linkedin_token_here
CLEARBIT_API_KEY=your_clearbit_key_here

# Communication
CHRISTOPHE_WHATSAPP_NUMBER=+33600000000
CHRISTOPHE_EMAIL=christophe.berthon@alecia.fr

# Security
JWT_SECRET=$JWT_SECRET

# Feature Flags
ENABLE_WHATSAPP=true
ENABLE_EMAIL=true
ENABLE_SLACK=false
ENABLE_TEAMS=false

# Logging
LOG_LEVEL=info
EOF
    
    # Save credentials for reference
    cat > $INSTALL_DIR/.credentials << EOF
# Largo 2.0 Credentials - KEEP SECURE!
# Generated: $(date)

PostgreSQL Password: $POSTGRES_PASSWORD
Redis Password: $REDIS_PASSWORD
n8n Encryption Key: $N8N_ENCRYPTION_KEY
MinIO Root Password: $MINIO_ROOT_PASSWORD
JWT Secret: $JWT_SECRET

# Default n8n Login
Username: admin
Password: changeme (CHANGE THIS!)
EOF
    
    chmod 600 $INSTALL_DIR/.env
    chmod 600 $INSTALL_DIR/.credentials
    
    log_success "Environment file created at $INSTALL_DIR/.env"
    log_warn "IMPORTANT: Update API keys in $INSTALL_DIR/.env"
}

# Create docker-compose.yml
create_docker_compose() {
    log_info "Creating Docker Compose configuration..."
    
    cat > $INSTALL_DIR/docker-compose.yml << 'EOF'
version: '3.8'

services:
  # n8n - Workflow Automation
  n8n:
    image: n8nio/n8n:1.50.0
    restart: always
    ports:
      - "127.0.0.1:5678:5678"
    environment:
      - N8N_ENCRYPTION_KEY=${N8N_ENCRYPTION_KEY}
      - N8N_WEBHOOK_URL=${N8N_WEBHOOK_URL}
      - N8N_BASIC_AUTH_ACTIVE=${N8N_BASIC_AUTH_ACTIVE}
      - N8N_BASIC_AUTH_USER=${N8N_BASIC_AUTH_USER}
      - N8N_BASIC_AUTH_PASSWORD=${N8N_BASIC_AUTH_PASSWORD}
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgres
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
      - DB_POSTGRESDB_USER=${POSTGRES_USER}
      - DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}
      - EXECUTIONS_MODE=regular
      - EXECUTIONS_TIMEOUT=300
      - EXECUTIONS_TIMEOUT_MAX=3600
    volumes:
      - ./data/n8n:/home/node/.n8n
    depends_on:
      - postgres
      - redis
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "wget", "--spider", "-q", "http://localhost:5678/healthz"]
      interval: 30s
      timeout: 10s
      retries: 3

  # PostgreSQL - Database
  postgres:
    image: postgres:15-alpine
    restart: always
    environment:
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_DB=${POSTGRES_DB}
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql:ro
    ports:
      - "127.0.0.1:5432:5432"
    networks:
      - largo-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Redis - Cache & Queue
  redis:
    image: redis:7-alpine
    restart: always
    command: redis-server --requirepass ${REDIS_PASSWORD} --appendonly yes
    volumes:
      - ./data/redis:/data
    ports:
      - "127.0.0.1:6379:6379"
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "redis-cli", "--raw", "incr", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  # MinIO - Object Storage
  minio:
    image: minio/minio:latest
    restart: always
    command: server /data --console-address ":9001"
    environment:
      - MINIO_ROOT_USER=${MINIO_ROOT_USER}
      - MINIO_ROOT_PASSWORD=${MINIO_ROOT_PASSWORD}
    volumes:
      - ./data/minio:/data
    ports:
      - "127.0.0.1:9000:9000"
      - "127.0.0.1:9001:9001"
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 20s
      retries: 3

  # M&A Research Service
  mna-research:
    build: ./services/mna-research
    restart: always
    ports:
      - "127.0.0.1:8001:8000"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
      - KIMI_API_KEY=${KIMI_API_KEY}
      - PAPPERS_API_KEY=${PAPPERS_API_KEY}
    depends_on:
      - postgres
      - redis
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # PowerPoint Generator Service
  pptx-generator:
    build: ./services/pptx-generator
    restart: always
    ports:
      - "127.0.0.1:8002:8000"
    volumes:
      - ./templates/pptx:/app/templates:ro
      - ./output/pptx:/app/output
    environment:
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - redis
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # WhatsApp Gateway Service
  whatsapp-gateway:
    build: ./services/whatsapp-gateway
    restart: always
    ports:
      - "127.0.0.1:8003:8000"
    environment:
      - WEBHOOK_URL=http://n8n:5678/webhook/message
    volumes:
      - ./data/whatsapp-auth:/app/auth
    depends_on:
      - n8n
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Document Parser Service
  document-parser:
    build: ./services/document-parser
    restart: always
    ports:
      - "127.0.0.1:8004:8000"
    volumes:
      - ./uploads:/app/uploads
      - ./output/documents:/app/output
    environment:
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - redis
    networks:
      - largo-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - ./logs/nginx:/var/log/nginx
    depends_on:
      - n8n
      - mna-research
      - pptx-generator
    networks:
      - largo-network

networks:
  largo-network:
    driver: bridge
EOF
    
    log_success "Docker Compose file created"
}

# Create init.sql for PostgreSQL
create_init_sql() {
    log_info "Creating database initialization script..."
    
    cat > $INSTALL_DIR/init.sql << 'EOF'
-- Largo 2.0 Database Schema

-- Company research results
CREATE TABLE IF NOT EXISTS company_research (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(50) UNIQUE NOT NULL,
    query VARCHAR(255),
    siren VARCHAR(20),
    company_name VARCHAR(255),
    result_json JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Valuations
CREATE TABLE IF NOT EXISTS valuations (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(50) UNIQUE NOT NULL,
    sector VARCHAR(100),
    ebitda DECIMAL(15,2),
    ev_low DECIMAL(15,2),
    ev_high DECIMAL(15,2),
    multiple_applied DECIMAL(5,2),
    result_json JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Messages (WhatsApp, Email, etc.)
CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    message_id VARCHAR(100) UNIQUE NOT NULL,
    source VARCHAR(50),
    from_id VARCHAR(100),
    from_name VARCHAR(255),
    message TEXT,
    intent VARCHAR(50),
    response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Daily M&A summaries
CREATE TABLE IF NOT EXISTS daily_summaries (
    id SERIAL PRIMARY KEY,
    run_id VARCHAR(50) UNIQUE NOT NULL,
    date DATE NOT NULL,
    summary TEXT,
    statistics JSONB,
    articles JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Prospect enrichments
CREATE TABLE IF NOT EXISTS prospect_enrichments (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(50) UNIQUE NOT NULL,
    company_name VARCHAR(255),
    siren VARCHAR(20),
    sector VARCHAR(100),
    revenue DECIMAL(15,2),
    enrichment_json JSONB,
    data_quality VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Document generations
CREATE TABLE IF NOT EXISTS document_generations (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(50) UNIQUE NOT NULL,
    document_type VARCHAR(50),
    template VARCHAR(100),
    file_url TEXT,
    file_name VARCHAR(255),
    pages INTEGER,
    quality_passed BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User preferences and memory
CREATE TABLE IF NOT EXISTS user_preferences (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(100) UNIQUE NOT NULL,
    preferences JSONB DEFAULT '{}',
    memory_json JSONB DEFAULT '{}',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_company_research_siren ON company_research(siren);
CREATE INDEX idx_company_research_created ON company_research(created_at);
CREATE INDEX idx_valuations_sector ON valuations(sector);
CREATE INDEX idx_messages_source ON messages(source);
CREATE INDEX idx_messages_created ON messages(created_at);
CREATE INDEX idx_daily_summaries_date ON daily_summaries(date);
CREATE INDEX idx_prospect_siren ON prospect_enrichments(siren);

-- Insert default user (Christophe)
INSERT INTO user_preferences (user_id, preferences) 
VALUES ('christophe.berthon@alecia.fr', '{
    "name": "Christophe Berthon",
    "role": "Managing Partner",
    "company": "Alecia M&A",
    "preferences": {
        "language": "fr",
        "communication": ["whatsapp", "email"],
        "reporting_time": "08:00",
        "sectors_of_interest": ["tech", "industrie", "services"]
    }
}') ON CONFLICT (user_id) DO NOTHING;
EOF
    
    log_success "Database initialization script created"
}

# Create nginx configuration
create_nginx_config() {
    log_info "Creating Nginx configuration..."
    
    mkdir -p $INSTALL_DIR/nginx
    
    cat > $INSTALL_DIR/nginx/nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging
    log_format largo '$remote_addr - $remote_user [$time_local] "$request" '
                     '$status $body_bytes_sent "$http_referer" '
                     '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log largo;
    error_log /var/log/nginx/error.log;

    # Gzip
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    # n8n - Workflow Automation
    server {
        listen 80;
        server_name n8n.*;

        location / {
            proxy_pass http://n8n:5678;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # WebSocket support
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
        }
    }

    # M&A Research API
    server {
        listen 80;
        server_name api.*;

        location / {
            proxy_pass http://mna-research:8000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }

    # Default server
    server {
        listen 80 default_server;
        server_name _;

        location / {
            return 200 'Largo 2.0 is running\n';
            add_header Content-Type text/plain;
        }

        location /health {
            return 200 '{"status":"healthy","service":"largo","version":"2.0.0"}\n';
            add_header Content-Type application/json;
        }
    }
}
EOF
    
    log_success "Nginx configuration created"
}

# Create backup script
create_backup_script() {
    log_info "Creating backup script..."
    
    cat > $INSTALL_DIR/backup.sh << 'EOF'
#!/bin/bash
# Largo 2.0 Backup Script

BACKUP_DIR="/opt/largo/backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup PostgreSQL
echo "Backing up PostgreSQL..."
docker exec largo-postgres-1 pg_dump -U largo largo | gzip > $BACKUP_DIR/postgres_$DATE.sql.gz

# Backup n8n workflows
echo "Backing up n8n workflows..."
tar -czf $BACKUP_DIR/n8n_$DATE.tar.gz -C /opt/largo/data n8n

# Backup Redis (if needed)
echo "Backing up Redis..."
docker exec largo-redis-1 redis-cli BGSAVE

# Cleanup old backups
echo "Cleaning up old backups..."
find $BACKUP_DIR -name "*.gz" -mtime +$RETENTION_DAYS -delete

echo "Backup completed: $BACKUP_DIR/*_$DATE.*"
EOF
    
    chmod +x $INSTALL_DIR/backup.sh
    
    # Add cron job for daily backups
    (crontab -l 2>/dev/null; echo "0 2 * * * /opt/largo/backup.sh >> /opt/largo/logs/backup.log 2>&1") | crontab -
    
    log_success "Backup script created and scheduled"
}

# Create management script
create_manage_script() {
    log_info "Creating management script..."
    
    cat > $INSTALL_DIR/largo.sh << 'EOF'
#!/bin/bash
# Largo 2.0 Management Script

LARGO_DIR="/opt/largo"
COMPOSE_FILE="$LARGO_DIR/docker-compose.yml"

show_help() {
    cat << 'HELP'
Largo 2.0 Management Script

Usage: largo.sh [command]

Commands:
    start       Start all Largo services
    stop        Stop all Largo services
    restart     Restart all Largo services
    status      Show service status
    logs        Show logs (use: largo.sh logs [service])
    update      Update Largo to latest version
    backup      Run manual backup
    shell       Open shell in service container
    reset       Reset all data (DANGEROUS!)
    help        Show this help message

Examples:
    largo.sh start
    largo.sh logs n8n
    largo.sh shell postgres
HELP
}

start_services() {
    echo "Starting Largo 2.0 services..."
    cd $LARGO_DIR
    docker compose up -d
    echo "Services started. Access n8n at http://localhost:5678"
}

stop_services() {
    echo "Stopping Largo 2.0 services..."
    cd $LARGO_DIR
    docker compose down
    echo "Services stopped"
}

show_status() {
    echo "Largo 2.0 Service Status:"
    cd $LARGO_DIR
    docker compose ps
}

show_logs() {
    cd $LARGO_DIR
    if [ -z "$2" ]; then
        docker compose logs -f
    else
        docker compose logs -f $2
    fi
}

run_backup() {
    echo "Running backup..."
    $LARGO_DIR/backup.sh
}

open_shell() {
    if [ -z "$2" ]; then
        echo "Usage: largo.sh shell <service-name>"
        echo "Services: n8n, postgres, redis, mna-research, pptx-generator, whatsapp-gateway, document-parser"
        exit 1
    fi
    cd $LARGO_DIR
    docker compose exec $2 /bin/sh
}

case "$1" in
    start)
        start_services
        ;;
    stop)
        stop_services
        ;;
    restart)
        stop_services
        sleep 2
        start_services
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs "$@"
        ;;
    backup)
        run_backup
        ;;
    shell)
        open_shell "$@"
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
EOF
    
    chmod +x $INSTALL_DIR/largo.sh
    ln -sf $INSTALL_DIR/largo.sh /usr/local/bin/largo
    
    log_success "Management script created. Use 'largo' command to manage services"
}

# Main deployment function
main() {
    echo "========================================"
    echo "  Largo 2.0 Deployment Script"
    echo "  Version: $LARGO_VERSION"
    echo "========================================"
    echo
    
    check_root
    detect_os
    
    log_info "Starting deployment..."
    
    update_system
    install_docker
    install_docker_compose
    setup_firewall
    setup_fail2ban
    setup_directories
    generate_env
    create_docker_compose
    create_init_sql
    create_nginx_config
    create_backup_script
    create_manage_script
    
    echo
    echo "========================================"
    log_success "Largo 2.0 deployment preparation complete!"
    echo "========================================"
    echo
    echo "Next steps:"
    echo "  1. Edit $INSTALL_DIR/.env and add your API keys"
    echo "  2. Copy your services to $INSTALL_DIR/services/"
    echo "  3. Run: largo start"
    echo "  4. Access n8n at http://your-server-ip:5678"
    echo
    echo "Default credentials saved in: $INSTALL_DIR/.credentials"
    echo
    log_warn "IMPORTANT: Change default passwords before production use!"
}

# Run main function
main "$@"
