# Largo 2.0 — Assistant M&A Personnel

> **Version**: 2.0 — n8n Architecture Edition  
> **Statut**: Architecture complète, prêt pour implémentation  
> **Dernière mise à jour**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Largo 2.0 est un assistant IA personnel conçu pour Christophe Berthon, associé fondateur d'Alecia M&A. Il remplace l'architecture OpenClaw par une solution moderne basée sur **n8n** et **Kimi API**.

### Pourquoi la migration ?

| Aspect | OpenClaw (v1) | n8n (v2) |
|--------|---------------|----------|
| **Coût base** | ~€6/jour (heartbeat) | ~€15/mois (VPS) |
| **Architecture** | Polling continu | Event-driven |
| **Sécurité** | Risque ClawHavoc | Self-hosted, contrôlé |
| **Personnalisation** | Limitée | SSH/root complet |
| **LLM** | OpenRouter multi | Kimi + Claude hybride |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         LARGO 2.0                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   WhatsApp  │  │    Email    │  │    Slack    │         │
│  │  (Baileys)  │  │ (IMAP/SMTP) │  │  (Webhook)  │         │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘         │
│         └─────────────────┴─────────────────┘               │
│                           │                                  │
│                    ┌──────▼──────┐                          │
│                    │     n8n     │                          │
│                    │  (VPS $15)  │                          │
│                    └──────┬──────┘                          │
│                           │                                  │
│  ┌────────────┬───────────┼───────────┬────────────┐        │
│  │            │           │           │            │        │
│  ▼            ▼           ▼           ▼            ▼        │
│ ┌────┐    ┌─────┐    ┌──────┐    ┌─────┐     ┌──────┐     │
│ │Kimi│    │Claude│   │Python│    │Postgre│    │Redis │     │
│ │$0.5│    │$3/M │   │Svcs  │    │SQL   │     │Cache │     │
│ └────┘    └─────┘    └──────┘    └─────┘     └──────┘     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 Contenu de ce Repository

```
largo-v2/
├── README.md                 # Ce fichier
├── SOUL.md                   # Philosophie et identité
├── IDENTITY.md               # Personnalité détaillée
├── USER.md                   # Profils utilisateurs
├── ARCHITECTURE.md           # Architecture technique
├── API_REFERENCE.md          # Documentation APIs
├── SKILLS.md                 # Capacités et workflows
├── MEMORY.md                 # Système de mémoire
├── DEPLOYMENT.md             # Guide de déploiement
├── WORKFLOWS.md              # Documentation workflows
│
├── docker-compose.yml        # Configuration Docker
├── .env.example              # Template variables d'environnement
├── init.sql                  # Initialisation PostgreSQL
│
├── scripts/                  # Scripts Python
│   ├── france_mna.py        # Recherche M&A France
│   ├── duckduckgo_search.py # Recherche web
│   ├── browser_scraper.py   # Scraping avancé
│   └── pappers_api.py       # API Pappers
│
├── services/                 # Microservices Python
│   ├── pptx-generator/      # Génération PowerPoint
│   ├── mna-research/        # Recherche M&A
│   ├── audio-processor/     # TTS/STT
│   ├── document-parser/     # OCR/PDF
│   └── whatsapp-gateway/    # Gateway WhatsApp
│
├── workflows/                # Workflows n8n (JSON)
│   ├── mna/
│   ├── documents/
│   ├── communication/
│   ├── routines/
│   └── system/
│
└── templates/                # Templates PowerPoint
    ├── executive_summary.pptx
    ├── company_profile.pptx
    └── valuation_report.pptx
```

---

## 🚀 Démarrage Rapide

### 1. Prérequis

- VPS avec 4vCPU/8GB RAM (~€15/mois)
- Domaine (ex: largo.fr)
- Docker & Docker Compose

### 2. Installation

```bash
# Clone
git clone https://github.com/michael/largo-v2.git
cd largo-v2

# Configuration
cp .env.example .env
# Éditer .env avec vos clés API

# Démarrage
docker-compose up -d

# Vérification
curl http://localhost:5678/healthz
```

### 3. Configuration n8n

```
URL: https://n8n.largo.fr
User: admin (dans .env)
Password: (dans .env)
```

Importer les workflows depuis `workflows/`.

---

## 💰 Budget

**Objectif: < €20/mois**

| Composant | Coût |
|-----------|------|
| VPS (4vCPU/8GB) | ~€15 |
| Kimi API (usage modéré) | ~€3-5 |
| Claude API (10% usage) | ~€1-2 |
| Domaine | ~€1 |
| **Total** | **~€20-23** |

*Optimisation: Cache Redis, routage hybride Kimi/Claude*

---

## 🛡️ Sécurité

- ✅ VPS dédié (pas de partage)
- ✅ PostgreSQL chiffré
- ✅ Pas de télémétrie
- ✅ Conversations isolées
- ✅ SSH key auth only
- ✅ Fail2ban
- ✅ SSL Let's Encrypt

---

## 🔧 Intégrations

### Messagerie
- WhatsApp (Baileys)
- Email (IMAP/SMTP)
- Slack

### Productivité
- Microsoft 365 (Graph API)
- Pipedrive (CRM)

### Données
- SIRENE (INSEE)
- Pappers
- API Entreprise

### LLM
- Kimi (Moonshot) — Principal
- Claude (Anthropic) — Premium

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [SOUL.md](SOUL.md) | Philosophie et règles de conduite |
| [IDENTITY.md](IDENTITY.md) | Personnalité et style |
| [USER.md](USER.md) | Profils utilisateurs |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Architecture technique |
| [API_REFERENCE.md](API_REFERENCE.md) | Documentation APIs |
| [SKILLS.md](SKILLS.md) | Capacités et workflows |
| [MEMORY.md](MEMORY.md) | Système de mémoire |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Guide de déploiement |
| [WORKFLOWS.md](WORKFLOWS.md) | Documentation workflows |

---

## 🎯 Roadmap

### Phase 1: Core (Semaine 1-2)
- [x] Architecture design
- [x] Docker setup
- [x] PostgreSQL schema
- [ ] n8n deployment
- [ ] WhatsApp integration

### Phase 2: M&A (Semaine 3-4)
- [ ] SIRENE/Pappers APIs
- [ ] Research workflows
- [ ] Valuation engine
- [ ] Document generation

### Phase 3: Intelligence (Semaine 5-6)
- [ ] Kimi integration
- [ ] Memory system
- [ ] Learning preferences
- [ ] Routines automation

### Phase 4: Polish (Semaine 7-8)
- [ ] Error handling
- [ ] Monitoring
- [ ] Documentation
- [ ] Testing

---

## 🤝 Support

**Michaël** — Support technique uniquement
- Infrastructure
- Configuration
- Debugging

**Christophe** — Propriétaire
- Toutes fonctionnalités
- Confidentialité absolue

---

## 📄 License

Propriétaire — Usage exclusif Christophe Berthon

---

*Largo 2.0 — Évolutif par nature, confidentiel par design.*
