# LARGO 2.0 — Flowise Knowledge Base Index

> **Version**: 2.0-Flowise  
> **Purpose**: Fichiers prêts à uploader dans Flowise

---

## 📂 Structure

```
flowise_kb/
├── INDEX.md                          ← Vous êtes ici
├── prompts/
│   └── SYSTEM_PROMPT.md              # System prompt complet pour Largo
├── tools/                            # Custom Tools (11)
│   ├── search_company.json           # Recherche entreprise
│   ├── get_valuation.json            # Calcul valorisation
│   ├── get_multiples.json            # Multiples sectoriels
│   ├── web_search.json               # Recherche web
│   ├── deep_research.json            # Recherche approfondie
│   ├── generate_document.json        # Génération documents
│   ├── save_memory.json              # Sauvegarde mémoire
│   ├── get_memory.json               # Récupération mémoire
│   ├── delegate_to_agent.json        # Délégation multi-agents
│   ├── send_notification.json        # Notifications
│   └── query_rag.json                # Interrogation RAG
├── agentflows/                       # Configurations agents (6)
│   ├── largo_main_agent.json         # Agent principal
│   ├── document_agent.json           # Agent documents
│   ├── research_agent.json           # Agent recherche
│   ├── meeting_agent.json            # Agent réunions
│   ├── email_agent.json              # Agent email
│   └── prospect_agent.json           # Agent prospection
├── documents/                        # Configurations document loaders (4)
│   ├── pdf_loader_config.json        # PDF loader
│   ├── docx_loader_config.json       # DOCX loader
│   ├── csv_loader_config.json        # CSV loader
│   └── knowledge_base_structure.json # Structure KB
└── memory/                           # Configurations mémoire (4)
    ├── buffer_memory.json            # Mémoire court terme
    ├── zep_memory.json               # Mémoire Zep
    ├── vector_memory.json            # Mémoire vectorielle
    └── conversation_store.json       # Stockage conversations
```

---

## 🚀 Utilisation

### 1. Importer les Tools

**Dans Flowise** :
1. Aller dans **Tools**
2. Cliquer sur **Add New**
3. Pour chaque fichier JSON dans `tools/` :
   - Copier le contenu
   - Coller dans le formulaire
   - Sauvegarder

### 2. Créer le Chatflow Principal

1. Aller dans **Chatflows**
2. Créer **New Chatflow**
3. Nommer : `Largo Main Agent`
4. Configurer selon `prompts/SYSTEM_PROMPT.md`
5. Ajouter les tools importés

### 3. Configurer le RAG

1. Aller dans **Document Stores**
2. Créer un nouveau store
3. Configurer selon `documents/knowledge_base_structure.json`
4. Uploader les documents

### 4. Configurer la Mémoire

1. Dans le chatflow, ajouter un node **Buffer Memory**
2. Configurer selon `memory/buffer_memory.json`
3. (Optionnel) Configurer Zep selon `memory/zep_memory.json`

---

## 📊 Inventaire

| Catégorie | Fichiers | Description |
|-----------|----------|-------------|
| Prompts | 1 | System prompt complet |
| Tools | 11 | Custom tools pour M&A |
| Agentflows | 6 | Configurations agents |
| Documents | 4 | Configs loaders et KB |
| Memory | 4 | Configs mémoire |
| **Total** | **26** | Fichiers uploadables |

---

## 🔗 Liens vers les Guides

Pour l'implémentation détaillée, voir :
- `../flowise_guides/README.md` — Vue d'ensemble
- `../flowise_guides/setup/` — Guides de configuration

---

*Flowise Knowledge Base for Largo 2.0*
