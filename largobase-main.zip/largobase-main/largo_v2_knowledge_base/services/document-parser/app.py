"""
Largo 2.0 - Document Parser Service
Extracts text, tables, and data from various document formats
"""

import os
import io
import json
import re
import ipaddress
import socket
import requests
import magic
from urllib.parse import urlparse
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import aiofiles

# Document parsers
import PyPDF2
import pdfplumber
from docx import Document as DocxDocument
from openpyxl import load_workbook
from PIL import Image
import pytesseract
from pdf2image import convert_from_path

app = FastAPI(title="Largo Document Parser", version="2.0.0")

# Configuration
UPLOAD_DIR = Path("/app/uploads")
OUTPUT_DIR = Path("/app/output")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)


class ParseRequest(BaseModel):
    extract_tables: bool = True
    extract_images: bool = False
    ocr_enabled: bool = True
    language: str = "fra+eng"


class ParseResponse(BaseModel):
    document_id: str
    filename: str
    file_type: str
    file_size: int
    text_content: str
    tables: List[List[List[str]]]
    metadata: Dict[str, Any]
    extraction_stats: Dict[str, Any]
    parsed_at: str


def detect_file_type(file_path: Path) -> str:
    """Detect file type using libmagic"""
    mime = magic.Magic(mime=True)
    return mime.from_filename(str(file_path))


def extract_text_from_pdf(file_path: Path, use_ocr: bool = True) -> Dict[str, Any]:
    """Extract text from PDF using multiple methods"""
    text_content = []
    tables = []
    metadata = {}
    
    # Try pdfplumber first (better for tables)
    try:
        with pdfplumber.open(file_path) as pdf:
            metadata = {
                "pages": len(pdf.pages),
                "pdf_info": pdf.metadata
            }
            
            for i, page in enumerate(pdf.pages):
                # Extract text
                page_text = page.extract_text()
                if page_text:
                    text_content.append(f"--- Page {i+1} ---\n{page_text}")
                
                # Extract tables
                page_tables = page.extract_tables()
                for table in page_tables:
                    if table:
                        tables.append(table)
    except Exception as e:
        metadata["pdfplumber_error"] = str(e)
    
    # Fallback to PyPDF2
    if not text_content:
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                metadata["pages_pypdf2"] = len(pdf_reader.pages)
                
                for i, page in enumerate(pdf_reader.pages):
                    page_text = page.extract_text()
                    if page_text:
                        text_content.append(f"--- Page {i+1} ---\n{page_text}")
        except Exception as e:
            metadata["pypdf2_error"] = str(e)
    
    # OCR fallback for scanned PDFs
    if use_ocr and (not text_content or len(''.join(text_content).strip()) < 100):
        try:
            images = convert_from_path(file_path, dpi=200)
            ocr_text = []
            
            for i, image in enumerate(images):
                text = pytesseract.image_to_string(image, lang='fra+eng')
                if text.strip():
                    ocr_text.append(f"--- Page {i+1} (OCR) ---\n{text}")
            
            if ocr_text:
                text_content = ocr_text
                metadata["ocr_used"] = True
        except Exception as e:
            metadata["ocr_error"] = str(e)
    
    return {
        "text": '\n\n'.join(text_content),
        "tables": tables,
        "metadata": metadata
    }


def extract_text_from_docx(file_path: Path) -> Dict[str, Any]:
    """Extract text from Word document"""
    doc = DocxDocument(file_path)
    
    # Extract paragraphs
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    
    # Extract tables
    tables = []
    for table in doc.tables:
        table_data = []
        for row in table.rows:
            row_data = [cell.text for cell in row.cells]
            table_data.append(row_data)
        tables.append(table_data)
    
    # Metadata
    metadata = {
        "paragraphs": len(doc.paragraphs),
        "tables": len(doc.tables),
        "sections": len(doc.sections)
    }
    
    # Core properties if available
    if doc.core_properties:
        metadata["author"] = doc.core_properties.author
        metadata["created"] = str(doc.core_properties.created) if doc.core_properties.created else None
        metadata["title"] = doc.core_properties.title
    
    return {
        "text": '\n\n'.join(paragraphs),
        "tables": tables,
        "metadata": metadata
    }


def extract_text_from_excel(file_path: Path) -> Dict[str, Any]:
    """Extract data from Excel file"""
    wb = load_workbook(file_path, data_only=True)
    
    all_sheets = []
    sheet_names = []
    
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        sheet_names.append(sheet_name)
        
        sheet_data = []
        for row in sheet.iter_rows():
            row_data = [str(cell.value) if cell.value is not None else '' for cell in row]
            if any(row_data):  # Skip empty rows
                sheet_data.append(row_data)
        
        all_sheets.append(sheet_data)
    
    # Combine all sheets into text
    text_parts = []
    for i, sheet_data in enumerate(all_sheets):
        text_parts.append(f"--- Sheet: {sheet_names[i]} ---")
        for row in sheet_data:
            text_parts.append(' | '.join(row))
    
    metadata = {
        "sheets": sheet_names,
        "sheet_count": len(sheet_names)
    }
    
    return {
        "text": '\n'.join(text_parts),
        "tables": all_sheets,
        "metadata": metadata
    }


def extract_text_from_image(file_path: Path, language: str = "fra+eng") -> Dict[str, Any]:
    """Extract text from image using OCR"""
    image = Image.open(file_path)
    
    # OCR
    text = pytesseract.image_to_string(image, lang=language)
    
    # Get OCR data with confidence
    data = pytesseract.image_to_data(image, lang=language, output_type=pytesseract.Output.DICT)
    
    # Calculate average confidence
    confidences = [int(c) for c in data['conf'] if int(c) > 0]
    avg_confidence = sum(confidences) / len(confidences) if confidences else 0
    
    metadata = {
        "image_size": image.size,
        "image_mode": image.mode,
        "ocr_confidence": round(avg_confidence, 2),
        "language": language
    }
    
    return {
        "text": text,
        "tables": [],
        "metadata": metadata
    }


@app.post("/parse", response_model=ParseResponse)
async def parse_document(
    file: UploadFile = File(...),
    extract_tables: bool = Form(True),
    extract_images: bool = Form(False),
    ocr_enabled: bool = Form(True),
    language: str = Form("fra+eng")
):
    """Parse uploaded document and extract content"""
    
    # Generate document ID
    doc_id = f"doc_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hash(file.filename) % 10000}"
    file_path = UPLOAD_DIR / f"{doc_id}_{file.filename}"
    
    try:
        # Save uploaded file
        async with aiofiles.open(file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        file_size = file_path.stat().st_size
        file_type = detect_file_type(file_path)
        
        # Parse based on file type
        mime_type = file_type.lower()
        
        if 'pdf' in mime_type:
            result = extract_text_from_pdf(file_path, use_ocr=ocr_enabled)
        elif 'word' in mime_type or 'document' in mime_type or file.filename.endswith('.docx'):
            result = extract_text_from_docx(file_path)
        elif 'excel' in mime_type or 'spreadsheet' in mime_type or file.filename.endswith('.xlsx'):
            result = extract_text_from_excel(file_path)
        elif 'image' in mime_type:
            result = extract_text_from_image(file_path, language=language)
        else:
            # Try generic text extraction
            try:
                async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                    text = await f.read()
                result = {"text": text, "tables": [], "metadata": {"encoding": "utf-8"}}
            except:
                raise HTTPException(400, f"Unsupported file type: {mime_type}")
        
        # Clean up uploaded file
        file_path.unlink(missing_ok=True)
        
        # Calculate stats
        text_length = len(result["text"])
        word_count = len(result["text"].split())
        table_count = len(result["tables"])
        
        return ParseResponse(
            document_id=doc_id,
            filename=file.filename,
            file_type=file_type,
            file_size=file_size,
            text_content=result["text"],
            tables=result["tables"] if extract_tables else [],
            metadata=result["metadata"],
            extraction_stats={
                "text_length": text_length,
                "word_count": word_count,
                "table_count": table_count,
                "pages": result["metadata"].get("pages", result["metadata"].get("sheets", 1))
            },
            parsed_at=datetime.now().isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        # Clean up on error
        file_path.unlink(missing_ok=True)
        raise HTTPException(500, f"Parse error: {str(e)}")


@app.post("/parse-url")
async def parse_document_url(url: str, options: ParseRequest):
    """Parse document from URL"""
    # Validate URL scheme (only http/https allowed)
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(status_code=400, detail="Only http and https URLs are allowed")

    # Reject private/internal IP addresses to prevent SSRF
    try:
        hostname = parsed.hostname or ""
        resolved_ip = socket.gethostbyname(hostname)
        ip_obj = ipaddress.ip_address(resolved_ip)
        if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_reserved:
            raise HTTPException(status_code=400, detail="Access to internal addresses is not allowed")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=400, detail="Could not resolve URL hostname")

    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        # Save to temp file
        doc_id = f"doc_url_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        file_path = UPLOAD_DIR / f"{doc_id}_download"
        
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(response.content)
        
        # Detect type from content
        file_type = detect_file_type(file_path)
        
        # Create mock UploadFile and call parse
        # (simplified - in production, refactor to share logic)
        
        file_path.unlink(missing_ok=True)
        
        return {"status": "parsed", "url": url, "type": file_type}
        
    except Exception as e:
        raise HTTPException(500, f"URL parse error: {str(e)}")


@app.get("/supported-formats")
async def list_supported_formats():
    """List supported document formats"""
    return {
        "formats": [
            {
                "mime_type": "application/pdf",
                "extensions": [".pdf"],
                "description": "PDF documents",
                "features": ["text", "tables", "ocr"]
            },
            {
                "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "extensions": [".docx"],
                "description": "Microsoft Word documents",
                "features": ["text", "tables"]
            },
            {
                "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "extensions": [".xlsx"],
                "description": "Microsoft Excel spreadsheets",
                "features": ["tables", "data"]
            },
            {
                "mime_type": "image/*",
                "extensions": [".jpg", ".jpeg", ".png", ".tiff", ".bmp"],
                "description": "Image files (OCR)",
                "features": ["ocr"]
            },
            {
                "mime_type": "text/plain",
                "extensions": [".txt", ".md"],
                "description": "Plain text files",
                "features": ["text"]
            }
        ],
        "ocr_languages": ["fra", "eng", "fra+eng", "deu", "spa", "ita"]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "document-parser",
        "version": "2.0.0",
        "ocr_available": True,
        "tesseract_version": pytesseract.get_tesseract_version()
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
