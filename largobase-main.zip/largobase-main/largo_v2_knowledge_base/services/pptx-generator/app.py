"""
Largo 2.0 - PowerPoint Generator Service
Generates professional M&A presentations from templates
"""

import os
import re
import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RgbColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

app = FastAPI(title="Largo PPTX Generator", version="2.0.0")

# Configuration
OUTPUT_DIR = Path("/app/output")
TEMPLATES_DIR = Path("/app/templates")
OUTPUT_DIR.mkdir(exist_ok=True)

# Alecia brand colors
BRAND_COLORS = {
    "alecia": {
        "primary": RgbColor(0x1a, 0x36, 0x5d),      # Dark blue
        "secondary": RgbColor(0xc9, 0xa2, 0x27),    # Gold
        "accent": RgbColor(0x4a, 0x90, 0xa4),       # Teal
        "text": RgbColor(0x33, 0x33, 0x33),         # Dark gray
        "light": RgbColor(0xf5, 0xf5, 0xf5),        # Light gray
    }
}


class SlideData(BaseModel):
    title: str
    content: Optional[str] = None
    bullets: Optional[List[str]] = None
    image_url: Optional[str] = None
    chart_data: Optional[Dict[str, Any]] = None
    table_data: Optional[List[List[str]]] = None


class PPTXRequest(BaseModel):
    template: str = Field(..., description="Template name: executive_summary, company_profile, valuation_report, teaser_acquisition, im, loi")
    data: Dict[str, Any] = Field(default_factory=dict, description="Template data")
    output_format: str = Field(default="pptx", description="Output format")
    branding: str = Field(default="alecia", description="Branding style")
    request_id: Optional[str] = None


class PPTXResponse(BaseModel):
    request_id: str
    file_url: str
    file_name: str
    file_size: int
    pages: int
    download_url: str
    generated_at: str


def apply_alecia_branding(prs: Presentation):
    """Apply Alecia branding to all slides"""
    colors = BRAND_COLORS["alecia"]
    
    for slide in prs.slides:
        # Set background
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = colors["light"]
        
        # Style title if exists
        if slide.shapes.title:
            title = slide.shapes.title
            title.text_frame.paragraphs[0].font.color.rgb = colors["primary"]
            title.text_frame.paragraphs[0].font.bold = True
            title.text_frame.paragraphs[0].font.size = Pt(32)


def create_title_slide(prs: Presentation, data: Dict[str, Any]):
    """Create title slide"""
    slide_layout = prs.slide_layouts[0]  # Title slide layout
    slide = prs.slides.add_slide(slide_layout)
    
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = data.get("title", "M&A Presentation")
    subtitle.text = data.get("subtitle", "Confidential - Alecia M&A")
    
    # Add date
    if data.get("date"):
        left = Inches(1)
        top = Inches(6.5)
        width = Inches(8)
        height = Inches(0.5)
        textbox = slide.shapes.add_textbox(left, top, width, height)
        tf = textbox.text_frame
        tf.text = data.get("date")
        tf.paragraphs[0].font.size = Pt(12)
        tf.paragraphs[0].font.color.rgb = BRAND_COLORS["alecia"]["text"]


def create_content_slide(prs: Presentation, slide_data: SlideData):
    """Create a content slide with bullets"""
    slide_layout = prs.slide_layouts[1]  # Title and Content
    slide = prs.slides.add_slide(slide_layout)
    
    # Title
    title = slide.shapes.title
    title.text = slide_data.title
    
    # Content
    if slide_data.bullets:
        body = slide.placeholders[1]
        tf = body.text_frame
        tf.clear()
        
        for i, bullet in enumerate(slide_data.bullets):
            if i == 0:
                p = tf.paragraphs[0]
            else:
                p = tf.add_paragraph()
            p.text = bullet
            p.level = 0
            p.font.size = Pt(14)


def create_two_column_slide(prs: Presentation, slide_data: SlideData):
    """Create a two-column slide"""
    slide_layout = prs.slide_layouts[5]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)
    
    # Title
    left = Inches(0.5)
    top = Inches(0.5)
    width = Inches(9)
    height = Inches(1)
    title_box = slide.shapes.add_textbox(left, top, width, height)
    title_box.text_frame.text = slide_data.title
    title_box.text_frame.paragraphs[0].font.size = Pt(28)
    title_box.text_frame.paragraphs[0].font.bold = True
    title_box.text_frame.paragraphs[0].font.color.rgb = BRAND_COLORS["alecia"]["primary"]


def create_executive_summary_presentation(data: Dict[str, Any]) -> Presentation:
    """Create executive summary presentation"""
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    # Title slide
    create_title_slide(prs, {
        "title": data.get("project_name", "Executive Summary"),
        "subtitle": f"{data.get('company_name', 'Target Company')} - M&A Opportunity",
        "date": data.get("date", datetime.now().strftime("%B %Y"))
    })
    
    # Executive Overview
    create_content_slide(prs, SlideData(
        title="Executive Overview",
        bullets=[
            f"Target: {data.get('company_name', 'N/A')}",
            f"Sector: {data.get('sector', 'N/A')}",
            f"Revenue: {data.get('revenue', 'N/A')}",
            f"Employees: {data.get('employees', 'N/A')}",
            f"Location: {data.get('location', 'N/A')}",
        ]
    ))
    
    # Investment Highlights
    create_content_slide(prs, SlideData(
        title="Investment Highlights",
        bullets=data.get("highlights", [
            "Strong market position",
            "Experienced management team",
            "Growth opportunities",
            "Stable cash flows"
        ])
    ))
    
    # Financial Overview
    financials = data.get("financials", {})
    create_content_slide(prs, SlideData(
        title="Financial Overview",
        bullets=[
            f"Revenue: {financials.get('revenue', 'N/A')}",
            f"EBITDA: {financials.get('ebitda', 'N/A')}",
            f"EBITDA Margin: {financials.get('margin', 'N/A')}",
            f"Enterprise Value: {financials.get('ev', 'N/A')}",
        ]
    ))
    
    # Valuation
    valuation = data.get("valuation", {})
    create_content_slide(prs, SlideData(
        title="Valuation Summary",
        bullets=[
            f"EV/EBITDA Multiple: {valuation.get('multiple', 'N/A')}x",
            f"Enterprise Value Range: {valuation.get('ev_range', 'N/A')}",
            f"Equity Value Range: {valuation.get('equity_range', 'N/A')}",
            "Comparable transactions support valuation range",
        ]
    ))
    
    # Next Steps
    create_content_slide(prs, SlideData(
        title="Recommended Next Steps",
        bullets=data.get("next_steps", [
            "Sign NDA and receive Information Memorandum",
            "Management presentation",
            "Initial due diligence",
            "Submit non-binding offer"
        ])
    ))
    
    apply_alecia_branding(prs)
    return prs


def create_company_profile_presentation(data: Dict[str, Any]) -> Presentation:
    """Create company profile presentation"""
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    # Title slide
    create_title_slide(prs, {
        "title": data.get("company_name", "Company Profile"),
        "subtitle": "Company Overview and M&A Profile",
        "date": datetime.now().strftime("%B %Y")
    })
    
    # Company Overview
    create_content_slide(prs, SlideData(
        title="Company Overview",
        bullets=[
            f"Founded: {data.get('founded', 'N/A')}",
            f"Headquarters: {data.get('headquarters', 'N/A')}",
            f"Legal Form: {data.get('legal_form', 'N/A')}",
            f"SIREN: {data.get('siren', 'N/A')}",
            f"Website: {data.get('website', 'N/A')}",
        ]
    ))
    
    # Business Description
    create_content_slide(prs, SlideData(
        title="Business Description",
        bullets=data.get("business_description", ["Business description not provided"])
    ))
    
    # Market Position
    create_content_slide(prs, SlideData(
        title="Market Position",
        bullets=data.get("market_position", [
            "Market leader in segment",
            "Strong brand recognition",
            "Diversified customer base"
        ])
    ))
    
    # Management Team
    management = data.get("management", [])
    if management:
        create_content_slide(prs, SlideData(
            title="Management Team",
            bullets=[f"{m.get('name', 'N/A')} - {m.get('role', 'N/A')}" for m in management]
        ))
    
    # Financial Summary
    financials = data.get("financials", {})
    create_content_slide(prs, SlideData(
        title="Financial Summary (Last 3 Years)",
        bullets=[
            f"Revenue Growth: {financials.get('revenue_growth', 'N/A')}",
            f"EBITDA Margin: {financials.get('ebitda_margin', 'N/A')}",
            f"Net Margin: {financials.get('net_margin', 'N/A')}",
            f"Cash Conversion: {financials.get('cash_conversion', 'N/A')}",
        ]
    ))
    
    apply_alecia_branding(prs)
    return prs


def create_valuation_report_presentation(data: Dict[str, Any]) -> Presentation:
    """Create valuation report presentation"""
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    # Title slide
    create_title_slide(prs, {
        "title": "Valuation Report",
        "subtitle": f"{data.get('company_name', 'Target Company')}",
        "date": datetime.now().strftime("%B %Y")
    })
    
    # Valuation Summary
    valuation = data.get("valuation", {})
    create_content_slide(prs, SlideData(
        title="Valuation Summary",
        bullets=[
            f"Enterprise Value: {valuation.get('ev', 'N/A')}",
            f"Equity Value: {valuation.get('equity_value', 'N/A')}",
            f"EV/EBITDA: {valuation.get('ev_ebitda', 'N/A')}x",
            f"EV/Revenue: {valuation.get('ev_revenue', 'N/A')}x",
            f"P/E Ratio: {valuation.get('pe_ratio', 'N/A')}x",
        ]
    ))
    
    # Methodology
    create_content_slide(prs, SlideData(
        title="Valuation Methodology",
        bullets=[
            "Trading Comparables: Public company multiples",
            "Transaction Comparables: M&A precedent transactions",
            "DCF Analysis: Discounted cash flow valuation",
            "LBO Analysis: Leveraged buyout feasibility"
        ]
    ))
    
    # Comparable Companies
    comparables = data.get("comparables", [])
    if comparables:
        create_content_slide(prs, SlideData(
            title="Comparable Companies",
            bullets=[f"{c.get('name', 'N/A')}: {c.get('ev_ebitda', 'N/A')}x EV/EBITDA" for c in comparables[:4]]
        ))
    
    # Key Assumptions
    create_content_slide(prs, SlideData(
        title="Key Assumptions",
        bullets=data.get("assumptions", [
            "Revenue growth: 5-10% annually",
            "EBITDA margin: stable/improving",
            "Discount rate: 10-12%",
            "Terminal growth: 2%"
        ])
    ))
    
    # Sensitivity Analysis
    create_content_slide(prs, SlideData(
        title="Sensitivity Analysis",
        bullets=[
            "Base case: Midpoint of valuation range",
            "Upside case: Higher growth, margin expansion",
            "Downside case: Lower growth, margin pressure",
            "Impact of 1x multiple change: ±€X million"
        ]
    ))
    
    apply_alecia_branding(prs)
    return prs


def create_teaser_presentation(data: Dict[str, Any]) -> Presentation:
    """Create acquisition teaser presentation"""
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    # Title slide
    create_title_slide(prs, {
        "title": "Exclusive Acquisition Opportunity",
        "subtitle": "Confidential - For Serious Buyers Only",
        "date": datetime.now().strftime("%B %Y")
    })
    
    # Investment Opportunity
    create_content_slide(prs, SlideData(
        title="Investment Opportunity",
        bullets=[
            f"Sector: {data.get('sector', 'N/A')}",
            f"Revenue: {data.get('revenue', 'N/A')}",
            f"EBITDA: {data.get('ebitda', 'N/A')}",
            f"Employees: {data.get('employees', 'N/A')}",
            f"Location: {data.get('location', 'N/A')}",
        ]
    ))
    
    # Key Highlights
    create_content_slide(prs, SlideData(
        title="Key Investment Highlights",
        bullets=data.get("highlights", [
            "Market leader with strong competitive position",
            "Proven track record of profitable growth",
            "Experienced and committed management team",
            "Multiple avenues for value creation"
        ])
    ))
    
    # Business Overview
    create_content_slide(prs, SlideData(
        title="Business Overview",
        bullets=data.get("business_overview", [
            "Description of core business activities",
            "Customer base and relationships",
            "Products and services portfolio"
        ])
    ))
    
    # Financial Highlights
    create_content_slide(prs, SlideData(
        title="Financial Highlights",
        bullets=[
            f"Revenue CAGR: {data.get('revenue_cagr', 'N/A')}",
            f"EBITDA Margin: {data.get('ebitda_margin', 'N/A')}",
            f"Strong cash generation",
            f"Limited capex requirements"
        ]
    ))
    
    # Contact
    create_content_slide(prs, SlideData(
        title="Contact Information",
        bullets=[
            "For more information, please contact:",
            "",
            "Christophe Berthon",
            "Managing Partner - Alecia M&A",
            "christophe.berthon@alecia.fr",
            "+33 6 XX XX XX XX"
        ]
    ))
    
    apply_alecia_branding(prs)
    return prs


@app.post("/generate", response_model=PPTXResponse)
async def generate_presentation(request: PPTXRequest, background_tasks: BackgroundTasks):
    """Generate a PowerPoint presentation from template"""
    
    try:
        # Generate unique filename — sanitize request_id to prevent path traversal
        raw_id = request.request_id or str(uuid.uuid4())[:8]
        request_id = re.sub(r'[^A-Za-z0-9_-]', '', raw_id)[:32] or str(uuid.uuid4())[:8]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"{request.template}_{timestamp}_{request_id}.pptx"
        file_path = OUTPUT_DIR / file_name
        
        # Create presentation based on template
        if request.template == "executive_summary":
            prs = create_executive_summary_presentation(request.data)
        elif request.template == "company_profile":
            prs = create_company_profile_presentation(request.data)
        elif request.template == "valuation_report":
            prs = create_valuation_report_presentation(request.data)
        elif request.template == "teaser_acquisition":
            prs = create_teaser_presentation(request.data)
        else:
            # Default to executive summary
            prs = create_executive_summary_presentation(request.data)
        
        # Save presentation
        prs.save(str(file_path))
        
        # Get file info
        file_size = file_path.stat().st_size
        pages = len(prs.slides)
        
        return PPTXResponse(
            request_id=request_id,
            file_url=f"/download/{file_name}",
            file_name=file_name,
            file_size=file_size,
            pages=pages,
            download_url=f"/download/{file_name}",
            generated_at=datetime.now().isoformat()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@app.get("/download/{file_name}")
async def download_presentation(file_name: str):
    """Download generated presentation"""
    # Sanitize: strip any directory components to prevent path traversal
    safe_name = Path(file_name).name
    file_path = (OUTPUT_DIR / safe_name).resolve()

    # Ensure the resolved path stays within OUTPUT_DIR
    if not str(file_path).startswith(str(OUTPUT_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid file name")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    return FileResponse(
        path=str(file_path),
        filename=safe_name,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation"
    )


@app.get("/templates")
async def list_templates():
    """List available templates"""
    return {
        "templates": [
            {
                "id": "executive_summary",
                "name": "Executive Summary",
                "description": "High-level M&A opportunity overview",
                "slides": 6
            },
            {
                "id": "company_profile",
                "name": "Company Profile",
                "description": "Detailed company overview for buyers",
                "slides": 7
            },
            {
                "id": "valuation_report",
                "name": "Valuation Report",
                "description": "Complete valuation analysis",
                "slides": 7
            },
            {
                "id": "teaser_acquisition",
                "name": "Acquisition Teaser",
                "description": "Anonymous deal teaser for distribution",
                "slides": 7
            }
        ]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "pptx-generator", "version": "2.0.0"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
