"""
Largo 2.0 - Valuation Engine
Comprehensive valuation calculations for M&A
"""

import json
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class CompanySize(Enum):
    TPE = "tpe"           # < 2M€ revenue
    PME = "pme"           # 2-50M€ revenue
    ETI = "eti"           # 50-150M€ revenue
    LARGE = "large"       # > 150M€ revenue


class Sector(Enum):
    TECH_SAAS = "tech_saas"
    SERVICES_INFORMATIQUE = "services_informatique"
    BIOTECH = "biotech"
    INDUSTRIE = "industrie"
    DISTRIBUTION = "distribution"
    CONSTRUCTION = "construction"
    RETAIL = "retail"
    GENERAL = "general"


@dataclass
class ValuationInput:
    ebitda: Optional[float] = None
    ebe: Optional[float] = None
    revenue: Optional[float] = None
    net_debt: float = 0
    sector: str = "general"
    subsector: Optional[str] = None
    region: str = "france"
    company_size: str = "pme"
    growth_rate: float = 0
    margin: Optional[float] = None
    working_capital_needs: float = 0


# Sector multiples (EV/EBITDA) - France PME/ETI focus
SECTOR_MULTIPLES = {
    "tech_saas": {"low": 8.0, "mid": 11.0, "high": 15.0},
    "services_informatique": {"low": 6.0, "mid": 8.0, "high": 10.0},
    "biotech": {"low": 8.0, "mid": 11.0, "high": 14.0},
    "industrie": {"low": 5.0, "mid": 6.5, "high": 8.0},
    "distribution": {"low": 4.5, "mid": 5.5, "high": 7.0},
    "construction": {"low": 4.0, "mid": 5.0, "high": 6.0},
    "retail": {"low": 4.0, "mid": 5.0, "high": 6.5},
    "general": {"low": 5.0, "mid": 6.5, "high": 8.0}
}

# EBE multiples when EBITDA not available
EBE_MULTIPLES = {
    "tech_saas": {"low": 7.0, "mid": 10.0, "high": 13.0},
    "services_informatique": {"low": 5.5, "mid": 7.5, "high": 9.5},
    "biotech": {"low": 7.0, "mid": 10.0, "high": 12.5},
    "industrie": {"low": 4.5, "mid": 6.0, "high": 7.5},
    "distribution": {"low": 4.0, "mid": 5.0, "high": 6.5},
    "construction": {"low": 3.5, "mid": 4.5, "high": 5.5},
    "retail": {"low": 3.5, "mid": 4.5, "high": 6.0},
    "general": {"low": 4.5, "mid": 6.0, "high": 7.5}
}

# Revenue multiples for early-stage/loss-making companies
REVENUE_MULTIPLES = {
    "tech_saas": {"low": 3.0, "mid": 5.0, "high": 8.0},
    "services_informatique": {"low": 0.8, "mid": 1.2, "high": 1.8},
    "biotech": {"low": 2.0, "mid": 4.0, "high": 7.0},
    "industrie": {"low": 0.5, "mid": 0.8, "high": 1.2},
    "distribution": {"low": 0.3, "mid": 0.5, "high": 0.8},
    "construction": {"low": 0.2, "mid": 0.4, "high": 0.6},
    "retail": {"low": 0.3, "mid": 0.5, "high": 0.8},
    "general": {"low": 0.5, "mid": 0.8, "high": 1.2}
}

# Size adjustments to multiples
SIZE_ADJUSTMENTS = {
    "tpe": -0.5,
    "pme": 0.0,
    "eti": 0.5,
    "large": 1.0
}

# Growth adjustments
GROWTH_ADJUSTMENTS = {
    "negative": -1.0,
    "0-5%": -0.5,
    "5-10%": 0.0,
    "10-15%": 0.5,
    "15%+": 1.0
}


class ValuationEngine:
    """M&A Valuation Engine for French PME/ETI"""
    
    def __init__(self):
        self.sector_multiples = SECTOR_MULTIPLES
        self.ebe_multiples = EBE_MULTIPLES
        self.revenue_multiples = REVENUE_MULTIPLES
    
    def get_base_multiple(self, sector: str) -> Dict[str, float]:
        """Get base multiple for sector"""
        return self.sector_multiples.get(sector, self.sector_multiples["general"])
    
    def calculate_size_adjustment(self, company_size: str) -> float:
        """Calculate size adjustment to multiple"""
        return SIZE_ADJUSTMENTS.get(company_size, 0.0)
    
    def calculate_growth_adjustment(self, growth_rate: float) -> float:
        """Calculate growth adjustment to multiple"""
        if growth_rate < 0:
            return GROWTH_ADJUSTMENTS["negative"]
        elif growth_rate < 5:
            return GROWTH_ADJUSTMENTS["0-5%"]
        elif growth_rate < 10:
            return GROWTH_ADJUSTMENTS["5-10%"]
        elif growth_rate < 15:
            return GROWTH_ADJUSTMENTS["10-15%"]
        else:
            return GROWTH_ADJUSTMENTS["15%+"]
    
    def calculate_margin_adjustment(self, margin: Optional[float]) -> float:
        """Calculate margin adjustment to multiple"""
        if margin is None:
            return 0.0
        
        if margin > 0.20:
            return 0.5
        elif margin > 0.15:
            return 0.25
        elif margin > 0.10:
            return 0.0
        elif margin > 0.05:
            return -0.25
        else:
            return -0.5
    
    def apply_adjustments(self, base_multiple: Dict[str, float], 
                          adjustments: List[float]) -> Dict[str, float]:
        """Apply adjustments to base multiple"""
        total_adjustment = sum(adjustments)
        
        return {
            "low": max(3.0, base_multiple["low"] + total_adjustment),
            "mid": max(4.0, base_multiple["mid"] + total_adjustment),
            "high": max(5.0, base_multiple["high"] + total_adjustment)
        }
    
    def valuate(self, input_data: ValuationInput) -> Dict[str, Any]:
        """Run complete valuation"""
        
        # Determine which metric to use
        if input_data.ebitda and input_data.ebitda > 0:
            metric = input_data.ebitda
            metric_type = "ebitda"
            base_multiples = self.get_base_multiple(input_data.sector)
        elif input_data.ebe and input_data.ebe > 0:
            metric = input_data.ebe
            metric_type = "ebe"
            base_multiples = self.ebe_multiples.get(input_data.sector, self.ebe_multiples["general"])
        elif input_data.revenue and input_data.revenue > 0:
            metric = input_data.revenue
            metric_type = "revenue"
            base_multiples = self.revenue_multiples.get(input_data.sector, self.revenue_multiples["general"])
        else:
            raise ValueError("At least one financial metric (EBITDA, EBE, or Revenue) must be provided")
        
        # Calculate adjustments
        adjustments = [
            self.calculate_size_adjustment(input_data.company_size),
            self.calculate_growth_adjustment(input_data.growth_rate),
            self.calculate_margin_adjustment(input_data.margin)
        ]
        
        adjusted_multiples = self.apply_adjustments(base_multiples, adjustments)
        
        # Calculate enterprise value
        ev_low = metric * adjusted_multiples["low"]
        ev_mid = metric * adjusted_multiples["mid"]
        ev_high = metric * adjusted_multiples["high"]
        
        # Calculate equity value
        equity_low = ev_low - input_data.net_debt
        equity_mid = ev_mid - input_data.net_debt
        equity_high = ev_high - input_data.net_debt
        
        # Format currency
        def fmt(val: float) -> str:
            if val >= 1_000_000_000:
                return f"{val/1_000_000_000:.1f}Md€"
            elif val >= 1_000_000:
                return f"{val/1_000_000:.1f}M€"
            elif val >= 1_000:
                return f"{val/1_000:.0f}k€"
            else:
                return f"{val:.0f}€"
        
        # Build response
        return {
            "enterprise_value": {
                "low": round(ev_low, 0),
                "mid": round(ev_mid, 0),
                "high": round(ev_high, 0),
                "formatted_low": fmt(ev_low),
                "formatted_mid": fmt(ev_mid),
                "formatted_high": fmt(ev_high)
            },
            "equity_value": {
                "low": round(equity_low, 0),
                "mid": round(equity_mid, 0),
                "high": round(equity_high, 0),
                "formatted_low": fmt(equity_low),
                "formatted_mid": fmt(equity_mid),
                "formatted_high": fmt(equity_high)
            },
            "multiple": {
                "applied_low": round(adjusted_multiples["low"], 2),
                "applied_mid": round(adjusted_multiples["mid"], 2),
                "applied_high": round(adjusted_multiples["high"], 2),
                "base_low": round(base_multiples["low"], 2),
                "base_mid": round(base_multiples["mid"], 2),
                "base_high": round(base_multiples["high"], 2),
                "total_adjustment": round(sum(adjustments), 2),
                "metric_type": metric_type
            },
            "methodology": {
                "primary": f"Multiple-based valuation using {metric_type.upper()}",
                "approach": "Market approach - comparable company multiples",
                "basis": f"French {input_data.company_size.upper()} sector multiples"
            },
            "adjustments": [
                {"factor": "Company size", "impact": adjustments[0]},
                {"factor": "Growth rate", "impact": adjustments[1]},
                {"factor": "Profitability margin", "impact": adjustments[2]}
            ],
            "key_drivers": [
                f"{metric_type.upper()} of {fmt(metric)}",
                f"Sector: {input_data.sector}",
                f"Growth rate: {input_data.growth_rate}%",
                f"Net debt: {fmt(input_data.net_debt)}"
            ],
            "risk_factors": [
                "Market multiple volatility",
                "Sector-specific risks",
                "Company-specific execution risk"
            ],
            "sensitivity": {
                "description": "Impact of 1x multiple change",
                "value_change": fmt(metric),
                "ev_impact": fmt(metric),
                "equity_impact": fmt(metric)
            }
        }
    
    def quick_valuation(self, ebitda: float, sector: str = "general") -> Dict[str, Any]:
        """Quick valuation with minimal inputs"""
        input_data = ValuationInput(
            ebitda=ebitda,
            sector=sector,
            company_size="pme"
        )
        return self.valuate(input_data)


# Singleton instance
valuation_engine = ValuationEngine()


if __name__ == "__main__":
    # Test
    test_input = ValuationInput(
        ebitda=1_000_000,
        sector="tech_saas",
        company_size="pme",
        growth_rate=15,
        net_debt=500_000
    )
    
    result = valuation_engine.valuate(test_input)
    print(json.dumps(result, indent=2, default=str))
