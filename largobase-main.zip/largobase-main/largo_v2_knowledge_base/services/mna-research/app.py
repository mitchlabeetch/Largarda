"""
Largo 2.0 - M&A Research Service
Core microservice for M&A analysis and valuation
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from enum import Enum

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import requests

from valuation import ValuationEngine, ValuationInput

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Largo M&A Research", version="2.0.0")

# Initialize valuation engine
valuation_engine = ValuationEngine()


class CompanyData(BaseModel):
    siren: Optional[str] = None
    siret: Optional[str] = None
    name: str
    sector: str
    subsector: Optional[str] = None
    revenue: Optional[float] = None
    ebitda: Optional[float] = None
    ebe: Optional[float] = None
    net_debt: float = 0
    employees: Optional[int] = None
    region: str = "france"
    company_size: str = "pme"


class AnalysisRequest(BaseModel):
    company_data: Dict[str, Any]
    depth: str = "standard"  # quick, standard, deep
    include_comparables: bool = True
    include_risks: bool = True


class AnalysisResponse(BaseModel):
    attractiveness_score: float
    score_breakdown: Dict[str, float]
    summary: str
    risks: List[Dict[str, Any]]
    opportunities: List[Dict[str, Any]]
    recommendations: List[str]
    comparables: List[Dict[str, Any]]
    key_metrics: Dict[str, Any]
    analysis_timestamp: str


class ValuationRequest(BaseModel):
    ebitda: Optional[float] = None
    ebe: Optional[float] = None
    revenue: Optional[float] = None
    net_debt: float = 0
    sector: str = "general"
    subsector: Optional[str] = None
    region: str = "france"
    company_size: str = "pme"
    growth_rate: float = 0
    margin: Optional[float] = None
    working_capital_needs: float = 0


class ValuationResponse(BaseModel):
    enterprise_value: Dict[str, Any]
    equity_value: Dict[str, Any]
    multiple: Dict[str, Any]
    methodology: Dict[str, Any]
    adjustments: List[Dict[str, Any]]
    key_drivers: List[str]
    risk_factors: List[str]
    sensitivity: Dict[str, Any]


# Sector attractiveness scoring
SECTOR_ATTRACTIVENESS = {
    "tech_saas": 9.0,
    "services_informatique": 8.5,
    "biotech": 8.0,
    "industrie": 6.5,
    "distribution": 5.5,
    "construction": 5.0,
    "retail": 5.0,
    "general": 6.0
}

# Risk factors by sector
SECTOR_RISKS = {
    "tech_saas": [
        {"factor": "High customer concentration", "severity": "medium"},
        {"factor": "Technology obsolescence risk", "severity": "high"},
        {"factor": "Key person dependency", "severity": "high"}
    ],
    "industrie": [
        {"factor": "Cyclical demand", "severity": "medium"},
        {"factor": "Capital intensity", "severity": "medium"},
        {"factor": "Environmental regulations", "severity": "medium"}
    ],
    "general": [
        {"factor": "Market competition", "severity": "medium"},
        {"factor": "Economic sensitivity", "severity": "medium"}
    ]
}


def calculate_attractiveness_score(company: Dict[str, Any]) -> Tuple[float, Dict[str, float]]:
    """Calculate M&A attractiveness score (0-10)"""
    
    sector = company.get("sector", "general")
    revenue = company.get("revenue", 0) or 0
    ebitda = company.get("ebitda", 0) or 0
    employees = company.get("employees", 0) or 0
    
    # Base sector score
    base_score = SECTOR_ATTRACTIVENESS.get(sector, 6.0)
    
    # Financial health (0-2 points)
    financial_score = 1.0
    if ebitda > 0 and revenue > 0:
        margin = ebitda / revenue
        if margin > 0.20:
            financial_score = 2.0
        elif margin > 0.10:
            financial_score = 1.5
        elif margin > 0.05:
            financial_score = 1.0
        else:
            financial_score = 0.5
    
    # Size score (0-2 points) - sweet spot for PME/ETI
    size_score = 1.0
    if 2_000_000 <= revenue <= 50_000_000:
        size_score = 2.0  # Ideal PME/ETI range
    elif 50_000_000 < revenue <= 150_000_000:
        size_score = 1.5  # ETI
    elif revenue > 150_000_000:
        size_score = 1.0  # Large - fewer buyers
    elif revenue < 2_000_000:
        size_score = 0.5  # Small - limited interest
    
    # Growth potential (0-2 points)
    growth_score = 1.0
    growth_rate = company.get("growth_rate", 0)
    if growth_rate > 15:
        growth_score = 2.0
    elif growth_rate > 5:
        growth_score = 1.5
    elif growth_rate > 0:
        growth_score = 1.0
    else:
        growth_score = 0.5
    
    # Market position (0-2 points)
    market_score = 1.0
    if employees > 50:
        market_score = 1.5
    if employees > 200:
        market_score = 2.0
    
    # Calculate total
    total = min(10, base_score + financial_score + size_score + growth_score + market_score - 2)
    
    breakdown = {
        "sector_attractiveness": base_score,
        "financial_health": financial_score,
        "size_appropriateness": size_score,
        "growth_potential": growth_score,
        "market_position": market_score
    }
    
    return total, breakdown


def get_comparable_companies(sector: str, revenue: float) -> List[Dict[str, Any]]:
    """Get comparable companies for benchmarking"""
    
    comparables = {
        "tech_saas": [
            {"name": "Sage", "ev_ebitda": 12.5, "country": "UK", "revenue": "2.0B€"},
            {"name": "Dassault Systèmes", "ev_ebitda": 18.0, "country": "FR", "revenue": "5.8B€"},
            {"name": "Cegid", "ev_ebitda": 15.0, "country": "FR", "revenue": "800M€"}
        ],
        "services_informatique": [
            {"name": "Capgemini", "ev_ebitda": 8.5, "country": "FR", "revenue": "22B€"},
            {"name": "Sopra Steria", "ev_ebitda": 9.0, "country": "FR", "revenue": "5.5B€"},
            {"name": "Wavestone", "ev_ebitda": 12.0, "country": "FR", "revenue": "500M€"}
        ],
        "industrie": [
            {"name": "Legrand", "ev_ebitda": 11.0, "country": "FR", "revenue": "8.0B€"},
            {"name": "Rexel", "ev_ebitda": 8.5, "country": "FR", "revenue": "18B€"},
            {"name": "Fives", "ev_ebitda": 7.5, "country": "FR", "revenue": "2.0B€"}
        ],
        "general": [
            {"name": "Mid-market PME Average", "ev_ebitda": 6.5, "country": "FR", "revenue": "10-50M€"},
            {"name": "Small-cap ETI Average", "ev_ebitda": 8.0, "country": "FR", "revenue": "50-150M€"}
        ]
    }
    
    return comparables.get(sector, comparables["general"])


@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_company(request: AnalysisRequest):
    """Analyze a company for M&A potential"""
    
    try:
        company = request.company_data
        
        # Calculate attractiveness score
        score, breakdown = calculate_attractiveness_score(company)
        
        # Get sector-specific risks
        sector = company.get("sector", "general")
        risks = SECTOR_RISKS.get(sector, SECTOR_RISKS["general"]).copy()
        
        # Add generic risks based on financials
        revenue = company.get("revenue", 0) or 0
        ebitda = company.get("ebitda", 0) or 0
        
        if revenue > 0 and ebitda / revenue < 0.05:
            risks.append({"factor": "Low profitability", "severity": "high"})
        
        if company.get("net_debt", 0) > revenue * 3:
            risks.append({"factor": "High leverage", "severity": "high"})
        
        # Generate opportunities
        opportunities = [
            {"factor": "Growth potential in core market", "impact": "high"},
            {"factor": "Operational improvement opportunities", "impact": "medium"},
            {"factor": "Potential for add-on acquisitions", "impact": "medium"}
        ]
        
        if sector in ["tech_saas", "services_informatique"]:
            opportunities.append({"factor": "Digital transformation tailwinds", "impact": "high"})
        
        # Generate recommendations
        recommendations = [
            "Request detailed financial statements",
            "Conduct management interview",
            "Analyze customer concentration",
            "Review competitive positioning"
        ]
        
        if score >= 7:
            recommendations.insert(0, "High priority - Schedule meeting quickly")
        elif score >= 5:
            recommendations.insert(0, "Medium priority - Further analysis needed")
        else:
            recommendations.insert(0, "Low priority - Significant concerns identified")
        
        # Get comparables
        comparables = get_comparable_companies(sector, revenue) if request.include_comparables else []
        
        return AnalysisResponse(
            attractiveness_score=round(score, 1),
            score_breakdown=breakdown,
            summary=f"Company scores {score:.1f}/10 for M&A attractiveness. "
                   f"Key strengths: {', '.join([k for k, v in breakdown.items() if v >= 1.5])}. "
                   f"Sector: {sector}",
            risks=risks,
            opportunities=opportunities,
            recommendations=recommendations,
            comparables=comparables,
            key_metrics={
                "revenue": revenue,
                "ebitda": ebitda,
                "margin": round(ebitda / revenue, 3) if revenue > 0 else None,
                "employees": company.get("employees"),
                "net_debt": company.get("net_debt", 0)
            },
            analysis_timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Analysis failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@app.post("/valuation", response_model=ValuationResponse)
async def calculate_valuation(request: ValuationRequest):
    """Calculate company valuation"""
    
    try:
        # Convert to valuation engine input
        valuation_input = ValuationInput(
            ebitda=request.ebitda,
            ebe=request.ebe,
            revenue=request.revenue,
            net_debt=request.net_debt,
            sector=request.sector,
            subsector=request.subsector,
            region=request.region,
            company_size=request.company_size,
            growth_rate=request.growth_rate,
            margin=request.margin,
            working_capital_needs=request.working_capital_needs
        )
        
        # Run valuation
        result = valuation_engine.valuate(valuation_input)
        
        return ValuationResponse(
            enterprise_value=result["enterprise_value"],
            equity_value=result["equity_value"],
            multiple=result["multiple"],
            methodology=result["methodology"],
            adjustments=result.get("adjustments", []),
            key_drivers=result.get("key_drivers", []),
            risk_factors=result.get("risk_factors", []),
            sensitivity=result.get("sensitivity", {})
        )
        
    except Exception as e:
        logger.error(f"Valuation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Valuation failed: {str(e)}")


@app.get("/sectors")
async def list_sectors():
    """List supported sectors with multiples"""
    return {
        "sectors": [
            {
                "id": "tech_saas",
                "name": "Tech / SaaS",
                "ebitda_multiple_range": "8.0x - 15.0x",
                "attractiveness": 9.0
            },
            {
                "id": "services_informatique",
                "name": "IT Services",
                "ebitda_multiple_range": "6.0x - 10.0x",
                "attractiveness": 8.5
            },
            {
                "id": "biotech",
                "name": "Biotech / Pharma",
                "ebitda_multiple_range": "8.0x - 14.0x",
                "attractiveness": 8.0
            },
            {
                "id": "industrie",
                "name": "Industrials",
                "ebitda_multiple_range": "5.0x - 8.0x",
                "attractiveness": 6.5
            },
            {
                "id": "distribution",
                "name": "Distribution",
                "ebitda_multiple_range": "4.5x - 7.0x",
                "attractiveness": 5.5
            },
            {
                "id": "retail",
                "name": "Retail",
                "ebitda_multiple_range": "4.0x - 6.5x",
                "attractiveness": 5.0
            }
        ]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "mna-research",
        "version": "2.0.0",
        "valuation_engine": "active"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
