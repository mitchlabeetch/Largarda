/**
 * Largo 2.0 - WhatsApp Gateway Service
 * Uses Baileys library for WhatsApp Web integration
 */

const express = require('express');
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const { 
  default: makeWASocket, 
  DisconnectReason, 
  useSingleFileAuthState,
  fetchLatestBaileysVersion 
} = require('@whiskeysockets/baileys');
const QRCode = require('qrcode');
const NodeCache = require('node-cache');
const fs = require('fs');
const path = require('path');
const pino = require('pino');

const app = express();
app.use(express.json());

const chatsLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' }
});

// Configuration
const PORT = process.env.PORT || 8000;
const AUTH_DIR = process.env.AUTH_DIR || '/app/auth';
const WEBHOOK_URL = process.env.WEBHOOK_URL || 'http://n8n:5678/webhook/message';

// Ensure auth directory exists
if (!fs.existsSync(AUTH_DIR)) {
  fs.mkdirSync(AUTH_DIR, { recursive: true });
}

// Logger
const logger = pino({ level: 'info' });

// Message cache (for deduplication)
const msgCache = new NodeCache({ stdTTL: 300 });

// Global socket state
let sock = null;
let qrCode = null;
let connectionState = 'disconnected';
let userInfo = null;

/**
 * Initialize WhatsApp connection
 */
async function connectToWhatsApp() {
  const { state, saveCreds } = useSingleFileAuthState(
    path.join(AUTH_DIR, 'auth_info.json')
  );
  
  const { version } = await fetchLatestBaileysVersion();
  
  sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: true,
    auth: state,
    browser: ['Largo 2.0', 'Chrome', '1.0'],
  });
  
  // Connection events
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    
    if (qr) {
      // Generate QR code for scanning
      qrCode = await QRCode.toDataURL(qr);
      connectionState = 'qr_ready';
      logger.info('QR Code generated - scan with WhatsApp');
    }
    
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      logger.info(`Connection closed. Reconnecting: ${shouldReconnect}`);
      connectionState = 'disconnected';
      qrCode = null;
      
      if (shouldReconnect) {
        setTimeout(connectToWhatsApp, 5000);
      }
    } else if (connection === 'open') {
      connectionState = 'connected';
      qrCode = null;
      userInfo = sock.user;
      logger.info(`Connected as ${userInfo.name} (${userInfo.id})`);
    }
  });
  
  // Credentials update
  sock.ev.on('creds.update', saveCreds);
  
  // Message handler
  sock.ev.on('messages.upsert', async (m) => {
    if (m.type === 'notify') {
      for (const msg of m.messages) {
        await handleIncomingMessage(msg);
      }
    }
  });
}

/**
 * Handle incoming messages
 */
async function handleIncomingMessage(msg) {
  try {
    // Skip if no message or from me
    if (!msg.message || msg.key.fromMe) return;
    
    // Deduplication check
    const msgId = msg.key.id;
    if (msgCache.has(msgId)) return;
    msgCache.set(msgId, true);
    
    const sender = msg.key.remoteJid;
    const senderName = msg.pushName || 'Unknown';
    
    // Extract message content
    let messageText = '';
    let messageType = 'text';
    
    if (msg.message.conversation) {
      messageText = msg.message.conversation;
    } else if (msg.message.extendedTextMessage) {
      messageText = msg.message.extendedTextMessage.text;
    } else if (msg.message.imageMessage) {
      messageType = 'image';
      messageText = msg.message.imageMessage.caption || '';
    } else if (msg.message.documentMessage) {
      messageType = 'document';
      messageText = msg.message.documentMessage.caption || '';
    }
    
    logger.info(`Message from ${senderName}: ${messageText.substring(0, 50)}...`);
    
    // Forward to webhook (n8n)
    const payload = {
      source: 'whatsapp',
      messageId: msgId,
      timestamp: new Date().toISOString(),
      from: {
        id: sender,
        number: sender.split('@')[0],
        name: senderName
      },
      message: messageText,
      messageType: messageType,
      raw: msg
    };
    
    // Send to n8n webhook
    try {
      await axios.post(WEBHOOK_URL, payload, { timeout: 10000 });
      logger.info('Message forwarded to webhook');
    } catch (webhookError) {
      logger.error('Webhook error:', webhookError.message);
    }
    
  } catch (error) {
    logger.error('Error handling message:', error);
  }
}

/**
 * Send WhatsApp message
 */
async function sendMessage(to, message, options = {}) {
  if (!sock || connectionState !== 'connected') {
    throw new Error('WhatsApp not connected');
  }
  
  // Format number
  let jid = to;
  if (!to.includes('@')) {
    jid = `${to.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
  }
  
  try {
    let result;
    
    if (options.media) {
      // Send media message
      result = await sock.sendMessage(jid, {
        [options.mediaType || 'image']: { url: options.mediaUrl },
        caption: message
      });
    } else {
      // Send text message
      result = await sock.sendMessage(jid, { text: message });
    }
    
    logger.info(`Message sent to ${to}`);
    return { success: true, messageId: result.key.id };
    
  } catch (error) {
    logger.error('Send error:', error);
    throw error;
  }
}

// API Routes

/**
 * Health check
 */
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'whatsapp-gateway',
    version: '2.0.0',
    connection: connectionState,
    user: userInfo ? { name: userInfo.name, id: userInfo.id } : null
  });
});

/**
 * Get QR code for pairing
 */
app.get('/qr', (req, res) => {
  if (connectionState === 'connected') {
    return res.json({ 
      status: 'connected', 
      message: 'Already connected',
      user: userInfo 
    });
  }
  
  if (qrCode) {
    res.json({ 
      status: 'qr_ready', 
      qrCode: qrCode,
      message: 'Scan QR code with WhatsApp' 
    });
  } else {
    res.json({ 
      status: connectionState, 
      message: 'QR code not ready yet' 
    });
  }
});

/**
 * Send message
 */
app.post('/send', async (req, res) => {
  try {
    const { to, message, media, mediaType } = req.body;
    
    if (!to || !message) {
      return res.status(400).json({ 
        error: 'Missing required fields: to, message' 
      });
    }
    
    const result = await sendMessage(to, message, { media, mediaType });
    res.json({
      success: true,
      messageId: result.messageId,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to send message',
      details: error.message 
    });
  }
});

/**
 * Get connection status
 */
app.get('/status', (req, res) => {
  res.json({
    connection: connectionState,
    user: userInfo,
    timestamp: new Date().toISOString()
  });
});

/**
 * Disconnect (logout)
 */
app.post('/disconnect', async (req, res) => {
  try {
    if (sock) {
      await sock.logout();
      connectionState = 'disconnected';
      userInfo = null;
    }
    
    // Clear auth file
    const authFile = path.join(AUTH_DIR, 'auth_info.json');
    if (fs.existsSync(authFile)) {
      fs.unlinkSync(authFile);
    }
    
    res.json({ success: true, message: 'Disconnected' });
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Get chats/contacts
 */
app.get('/chats', chatsLimiter, async (req, res) => {
  try {
    if (!sock || connectionState !== 'connected') {
      return res.status(503).json({ error: 'Not connected' });
    }
    
    const chats = await sock.groupFetchAllParticipating();
    res.json({ chats });
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
app.listen(PORT, () => {
  logger.info(`WhatsApp Gateway listening on port ${PORT}`);
  connectToWhatsApp();
});
