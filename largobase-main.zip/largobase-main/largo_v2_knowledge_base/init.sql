-- ============================================
-- LARGO 2.0 — PostgreSQL Initialization
-- ============================================
-- This script runs automatically when PostgreSQL starts for the first time

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For text search

-- Try to enable pgvector (optional, for semantic search)
-- Note: Requires pgvector to be installed in the image
DO $$
BEGIN
    CREATE EXTENSION IF NOT EXISTS "vector";
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'pgvector not available, skipping';
END $$;

-- ============================================
-- TABLES
-- ============================================

-- Conversations table (session history)
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL DEFAULT uuid_generate_v4(),
    user_id VARCHAR(255) NOT NULL DEFAULT 'christophe',
    channel VARCHAR(50) NOT NULL,
    messages JSONB NOT NULL DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_channel CHECK (channel IN ('whatsapp', 'email', 'slack', 'teams', 'api'))
);

-- Preferences table (user preferences)
CREATE TABLE IF NOT EXISTS preferences (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL DEFAULT 'christophe',
    category VARCHAR(100) NOT NULL,
    key VARCHAR(255) NOT NULL,
    value JSONB NOT NULL,
    source VARCHAR(500),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_preference UNIQUE (user_id, category, key),
    CONSTRAINT valid_category CHECK (category IN ('communication', 'documents', 'style', 'research', 'transport', 'general'))
);

-- Deals table (M&A deals)
CREATE TABLE IF NOT EXISTS deals (
    id SERIAL PRIMARY KEY,
    deal_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(500) NOT NULL,
    siret VARCHAR(14),
    siren VARCHAR(9),
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    phase VARCHAR(50),
    priority VARCHAR(20) DEFAULT 'medium',
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    closed_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT valid_status CHECK (status IN ('active', 'closed', 'on_hold', 'lost')),
    CONSTRAINT valid_phase CHECK (phase IN ('approach', 'loi', 'dd', 'closing', NULL)),
    CONSTRAINT valid_priority CHECK (priority IN ('high', 'medium', 'low'))
);

-- Documents table (stored documents)
CREATE TABLE IF NOT EXISTS documents (
    id SERIAL PRIMARY KEY,
    doc_id VARCHAR(255) UNIQUE NOT NULL,
    deal_id VARCHAR(255) REFERENCES deals(deal_id) ON DELETE SET NULL,
    filename VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size INTEGER,
    storage_path VARCHAR(1000),
    extracted_text TEXT,
    extracted_data JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_file_type CHECK (file_type IN ('pdf', 'xlsx', 'pptx', 'docx', 'csv', 'txt', 'jpg', 'png'))
);

-- Executions table (n8n execution logs)
CREATE TABLE IF NOT EXISTS executions (
    id SERIAL PRIMARY KEY,
    execution_id UUID NOT NULL DEFAULT uuid_generate_v4(),
    workflow_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    finished_at TIMESTAMP WITH TIME ZONE,
    data JSONB DEFAULT '{}',
    error_message TEXT,
    
    CONSTRAINT valid_execution_status CHECK (status IN ('running', 'success', 'error', 'cancelled'))
);

-- API Calls table (LLM API usage tracking)
CREATE TABLE IF NOT EXISTS api_calls (
    id SERIAL PRIMARY KEY,
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    tokens_input INTEGER DEFAULT 0,
    tokens_output INTEGER DEFAULT 0,
    cost DECIMAL(10, 6) DEFAULT 0,
    request_data JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_provider CHECK (provider IN ('kimi', 'claude', 'openai', 'other'))
);

-- Contacts table (for M&A)
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    contact_id VARCHAR(255) UNIQUE NOT NULL,
    deal_id VARCHAR(255) REFERENCES deals(deal_id) ON DELETE SET NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    company VARCHAR(255),
    role VARCHAR(100),
    type VARCHAR(50), -- cedant, acquereur, intermediaire, etc.
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT valid_contact_type CHECK (type IN ('cedant', 'acquereur', 'intermediaire', 'avocat', 'expert', 'banque', 'other'))
);

-- Scheduled tasks table
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id SERIAL PRIMARY KEY,
    task_name VARCHAR(255) NOT NULL,
    cron_expression VARCHAR(100) NOT NULL,
    workflow_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    last_run_at TIMESTAMP WITH TIME ZONE,
    next_run_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================

-- Conversations indexes
CREATE INDEX IF NOT EXISTS idx_conversations_session ON conversations(session_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_channel ON conversations(channel);
CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversations_created ON conversations(created_at DESC);

-- Preferences indexes
CREATE INDEX IF NOT EXISTS idx_preferences_user ON preferences(user_id);
CREATE INDEX IF NOT EXISTS idx_preferences_category ON preferences(category);

-- Deals indexes
CREATE INDEX IF NOT EXISTS idx_deals_siret ON deals(siret);
CREATE INDEX IF NOT EXISTS idx_deals_siren ON deals(siren);
CREATE INDEX IF NOT EXISTS idx_deals_status ON deals(status);
CREATE INDEX IF NOT EXISTS idx_deals_phase ON deals(phase);
CREATE INDEX IF NOT EXISTS idx_deals_priority ON deals(priority);
CREATE INDEX IF NOT EXISTS idx_deals_updated ON deals(updated_at DESC);

-- Documents indexes
CREATE INDEX IF NOT EXISTS idx_documents_deal ON documents(deal_id);
CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(file_type);
CREATE INDEX IF NOT EXISTS idx_documents_created ON documents(created_at DESC);

-- Executions indexes
CREATE INDEX IF NOT EXISTS idx_executions_workflow ON executions(workflow_name);
CREATE INDEX IF NOT EXISTS idx_executions_status ON executions(status);
CREATE INDEX IF NOT EXISTS idx_executions_started ON executions(started_at DESC);

-- API calls indexes
CREATE INDEX IF NOT EXISTS idx_api_calls_provider ON api_calls(provider);
CREATE INDEX IF NOT EXISTS idx_api_calls_created ON api_calls(created_at DESC);

-- Contacts indexes
CREATE INDEX IF NOT EXISTS idx_contacts_deal ON contacts(deal_id);
CREATE INDEX IF NOT EXISTS idx_contacts_type ON contacts(type);

-- ============================================
-- TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to all tables with updated_at
CREATE TRIGGER update_conversations_updated_at 
    BEFORE UPDATE ON conversations 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_preferences_updated_at 
    BEFORE UPDATE ON preferences 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_deals_updated_at 
    BEFORE UPDATE ON deals 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contacts_updated_at 
    BEFORE UPDATE ON contacts 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_scheduled_tasks_updated_at 
    BEFORE UPDATE ON scheduled_tasks 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- VIEWS
-- ============================================

-- Active deals view
CREATE OR REPLACE VIEW active_deals AS
SELECT * FROM deals 
WHERE status = 'active' 
ORDER BY priority DESC, updated_at DESC;

-- API usage summary (daily)
CREATE OR REPLACE VIEW daily_api_usage AS
SELECT 
    DATE(created_at) as date,
    provider,
    model,
    COUNT(*) as call_count,
    SUM(tokens_input) as total_input_tokens,
    SUM(tokens_output) as total_output_tokens,
    SUM(cost) as total_cost
FROM api_calls
GROUP BY DATE(created_at), provider, model
ORDER BY date DESC, total_cost DESC;

-- ============================================
-- INITIAL DATA
-- ============================================

-- Insert default scheduled tasks
INSERT INTO scheduled_tasks (task_name, cron_expression, workflow_name, is_active)
VALUES 
    ('daily_mna_summary', '0 9 * * *', 'daily-mna-summary', true),
    ('prospect_enrichment', '0 2 * * *', 'prospect-enrichment', true),
    ('backup_database', '0 3 * * *', 'backup-database', true)
ON CONFLICT DO NOTHING;

-- Insert default preferences for Christophe
INSERT INTO preferences (user_id, category, key, value, source)
VALUES 
    ('christophe', 'communication', 'preferred_channel', '"whatsapp"', 'initial_setup'),
    ('christophe', 'communication', 'tone', '"jovial"', 'initial_setup'),
    ('christophe', 'documents', 'excel_formulas_visible', 'true', 'initial_setup'),
    ('christophe', 'style', 'language', '"fr"', 'initial_setup')
ON CONFLICT (user_id, category, key) DO NOTHING;

-- ============================================
-- COMMENTS
-- ============================================

COMMENT ON TABLE conversations IS 'Chat history and session data';
COMMENT ON TABLE preferences IS 'User preferences learned over time';
COMMENT ON TABLE deals IS 'M&A deals being tracked';
COMMENT ON TABLE documents IS 'Files and documents associated with deals';
COMMENT ON TABLE api_calls IS 'Tracking of LLM API usage and costs';

-- ============================================
-- GRANTS
-- ============================================

-- Grant all privileges to largo user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO largo;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO largo;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO largo;

-- ============================================
-- COMPLETION
-- ============================================

SELECT 'Largo 2.0 database initialized successfully' as status;
