# API_REFERENCE.md — Largo 2.0 APIs & Integrations

> Version: 2.0 — n8n Architecture Edition
> Last Updated: 2026-03-18

---

## 🌐 APIs Externes

### 1. Kimi API (Moonshot AI)

**Endpoint** : `https://api.moonshot.cn/v1`

**Authentification** : Bearer Token

```bash
curl https://api.moonshot.cn/v1/chat/completions \
  -H "Authorization: Bearer $KIMI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "kimi-k2-0711-preview",
    "messages": [
      {"role": "system", "content": "Tu es Largo, assistant M&A..."},
      {"role": "user", "content": "Analyse cette entreprise..."}
    ],
    "temperature": 0.3,
    "max_tokens": 4000
  }'
```

**Modèles disponibles** :

| Modèle | Context | Prix Input | Prix Output | Usage |
|--------|---------|------------|-------------|-------|
| `kimi-k2-0711-preview` | 2M | $0.50/M | $1.00/M | Général |
| `kimi-k2-0711-preview-long` | 2M | $0.80/M | $1.60/M | Long context |

**n8n Configuration** :

```json
{
  "name": "Kimi API",
  "type": "httpRequest",
  "method": "POST",
  "url": "https://api.moonshot.cn/v1/chat/completions",
  "headers": {
    "Authorization": "Bearer={{ $credentials.kimiApiKey }}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "kimi-k2-0711-preview",
    "messages": "={{ $json.messages }}",
    "temperature": 0.3
  }
}
```

---

### 2. Claude API (Anthropic)

**Endpoint** : `https://api.anthropic.com/v1`

**Authentification** : x-api-key Header

```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $CLAUDE_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "claude-3-5-sonnet-20241022",
    "max_tokens": 4096,
    "messages": [
      {"role": "user", "content": "Review ce document..."}
    ]
  }'
```

**Modèles disponibles** :

| Modèle | Context | Prix Input | Prix Output | Usage |
|--------|---------|------------|-------------|-------|
| `claude-3-5-sonnet-20241022` | 200K | $3.00/M | $15.00/M | Qualité critique |
| `claude-3-5-haiku-20241022` | 200K | $0.80/M | $4.00/M | Rapide |

**n8n Configuration** :

```json
{
  "name": "Claude API",
  "type": "httpRequest",
  "method": "POST",
  "url": "https://api.anthropic.com/v1/messages",
  "headers": {
    "x-api-key": "={{ $credentials.claudeApiKey }}",
    "anthropic-version": "2023-06-01",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "claude-3-5-sonnet-20241022",
    "max_tokens": 4096,
    "messages": "={{ $json.messages }}"
  }
}
```

---

### 3. API Recherche Entreprises (France)

**Endpoint** : `https://recherche-entreprises.api.gouv.fr`

**Authentification** : Aucune (publique)

```bash
# Recherche par SIRET
curl "https://recherche-entreprises.api.gouv.fr/search?q=34977287100027"

# Recherche par nom
curl "https://recherche-entreprises.api.gouv.fr/search?q=Alecia+M%26A"

# Avec filtres
curl "https://recherche-entreprises.api.gouv.fr/search?q=Alecia&code_postal=06000"
```

**Réponse** :

```json
{
  "results": [
    {
      "siren": "123456789",
      "nom_complet": "ALECIA CONSEIL",
      "siege": {
        "adresse": "10 AVENUE JEAN MEDECIN",
        "code_postal": "06000",
        "commune": "NICE"
      },
      "activite_principale": "7022Z",
      "section_activite_principale": "M"
    }
  ]
}
```

---

### 4. API SIRENE (INSEE)

**Endpoint** : `https://api.insee.fr/entreprises/sirene/V3.11`

**Authentification** : Bearer Token (OAuth2)

```bash
# Token
curl -X POST "https://api.insee.fr/token" \
  -H "Authorization: Basic $INSEE_CREDENTIALS" \
  -d "grant_type=client_credentials"

# Recherche SIRET
curl "https://api.insee.fr/entreprises/sirene/V3.11/siret/34977287100027" \
  -H "Authorization: Bearer $TOKEN"

# Recherche SIREN
curl "https://api.insee.fr/entreprises/sirene/V3.11/siren/349772871" \
  -H "Authorization: Bearer $TOKEN"
```

---

### 5. Pappers API

**Endpoint** : `https://api.pappers.fr/v2`

**Authentification** : API Key (header ou query)

```bash
# Recherche entreprise
curl "https://api.pappers.fr/v2/entreprise?siren=349772871&api_token=$PAPPERS_API_KEY"

# Recherche par nom
curl "https://api.pappers.fr/v2/recherche?q=Alecia&api_token=$PAPPERS_API_KEY"

# Document (KBIS, etc.)
curl "https://api.pappers.fr/v2/document/telecharger?siren=349772871&type=kbis&api_token=$PAPPERS_API_KEY"
```

**Réponse entreprise** :

```json
{
  "siren": "349772871",
  "nom_entreprise": "ALECIA CONSEIL",
  "personne_morale": true,
  "denomination": "ALECIA CONSEIL",
  "nom": null,
  "prenom": null,
  "sexe": null,
  "code_naf": "7022Z",
  "libelle_code_naf": "Conseil pour les affaires et autres conseils de gestion",
  "domaine_activite": "Activités des sièges sociaux ; conseil de gestion",
  "conventions_collectives": [],
  "date_creation": "1989-01-01",
  "date_creation_formate": "01/01/1989",
  "entreprise_cessee": false,
  "date_cessation": null,
  "entreprise_employeuse": true,
  "societe_a_mission": false,
  "categorie_juridique": "Société par actions simplifiée",
  "forme_juridique": "SAS",
  "micro_entreprise": false,
  "forme_exercice": "Commercial",
  "effectif": "20 à 49 salariés",
  "effectif_min": 20,
  "effectif_max": 49,
  "tranche_effectif": "21",
  "annee_effectif": 2022,
  "capital": 100000,
  "capital_formate": "100 000 €",
  "statut_rcs": "Inscrit",
  "statut_rne": "Inscrit",
  "numero_rcs": "NICE B 123 456 789",
  "numero_tva_intracommunautaire": "FR12345678901",
  " siege": {
    "adresse_ligne_1": "10 AVENUE JEAN MEDECIN",
    "code_postal": "06000",
    "ville": "NICE",
    "pays": "FRANCE"
  },
  "diffusable": true,
  "duree_personne_morale": "99 ans",
  "derniere_mise_a_jour_sirene": "2024-01-15",
  "derniere_mise_a_jour_rcs": "2024-01-15"
}
```

---

### 6. API Entreprise (Beta Gouv)

**Endpoint** : `https://entreprise.api.gouv.fr/v3`

**Authentification** : Bearer Token

```bash
# Données établissement
curl "https://entreprise.api.gouv.fr/v3/insee/sirene/etablissements/34977287100027" \
  -H "Authorization: Bearer $API_ENTREPRISE_TOKEN"

# Chiffres d'affaires (API Banque de France)
curl "https://entreprise.api.gouv.fr/v3/banque_de_france/unites_legales/349772871/ratios_financiers" \
  -H "Authorization: Bearer $API_ENTREPRISE_TOKEN"

# Attestation fiscale
curl "https://entreprise.api.gouv.fr/v3/dgfip/unites_legales/349772871/attestation_fiscale" \
  -H "Authorization: Bearer $API_ENTREPRISE_TOKEN"
```

---

### 7. DuckDuckGo Search (Gratuit)

**Library** : `duckduckgo-search` (Python)

```python
from duckduckgo_search import DDGS

def search_web(query, max_results=5):
    with DDGS() as ddgs:
        results = ddgs.text(query, max_results=max_results)
        return [
            {
                "title": r["title"],
                "link": r["href"],
                "snippet": r["body"]
            }
            for r in results
        ]

# Usage
results = search_web("actualité M&A France 2026", max_results=10)
```

**n8n Configuration (via Python)** :

```python
# n8n Function Node
import subprocess
import json

def search_ddg(query):
    result = subprocess.run(
        ['python3', '/app/scripts/duckduckgo_search.py', query],
        capture_output=True,
        text=True
    )
    return json.loads(result.stdout)

return [{"results": search_ddg($json.query)}]
```

---

### 8. Brave Search API

**Endpoint** : `https://api.search.brave.com/res/v1/web/search`

**Authentification** : X-Subscription-Token Header

```bash
curl "https://api.search.brave.com/res/v1/web/search?q=actualité+M%26A+France" \
  -H "X-Subscription-Token: $BRAVE_API_KEY" \
  -H "Accept: application/json"
```

**Tarification** :
- 2,000 requêtes/mois gratuites
- $3/1,000 requêtes au-delà

---

### 9. Microsoft Graph API

**Endpoint** : `https://graph.microsoft.com/v1.0`

**Authentification** : OAuth2

```bash
# Lire emails
curl "https://graph.microsoft.com/v1.0/me/messages?$top=10" \
  -H "Authorization: Bearer $MS_GRAPH_TOKEN"

# Envoyer email
curl -X POST "https://graph.microsoft.com/v1.0/me/sendMail" \
  -H "Authorization: Bearer $MS_GRAPH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "message": {
      "subject": "Analyse M&A",
      "body": {"contentType": "HTML", "content": "<p>Voici l'analyse...</p>"},
      "toRecipients": [{"emailAddress": {"address": "christophe@alecia.fr"}}]
    }
  }'

# Lire calendrier
curl "https://graph.microsoft.com/v1.0/me/calendar/events?$top=10" \
  -H "Authorization: Bearer $MS_GRAPH_TOKEN"
```

---

### 10. Pipedrive API

**Endpoint** : `https://api.pipedrive.com/v1`

**Authentification** : api_token Query Param

```bash
# Liste deals
curl "https://api.pipedrive.com/v1/deals?api_token=$PIPEDRIVE_API_KEY"

# Créer deal
curl -X POST "https://api.pipedrive.com/v1/deals?api_token=$PIPEDRIVE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Projet Acquisition - Société X",
    "value": 5000000,
    "currency": "EUR",
    "stage_id": 1,
    "person_id": 123
  }'

# Ajouter activité
curl -X POST "https://api.pipedrive.com/v1/activities?api_token=$PIPEDRIVE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Call de suivi",
    "type": "call",
    "deal_id": 456,
    "due_date": "2026-03-20",
    "due_time": "14:00"
  }'
```

---

## 🔌 APIs Internes (Microservices)

### 1. PowerPoint Generator

**Endpoint** : `http://pptx-generator:8000/generate`

```bash
curl -X POST "http://localhost:8000/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "template": "templates/q3_executive.pptx",
    "data": {
      "title": "Analyse Acquisition - Société X",
      "date": "2026-03-18",
      "slides": [
        {
          "type": "title",
          "title": "Executive Summary",
          "subtitle": "Projet d'acquisition - Small Cap Industrie"
        },
        {
          "type": "metrics",
          "title": "KPIs Clés",
          "data": {
            "CA": "12.5M€",
            "EBE": "2.1M€",
            "Marge": "16.8%",
            "Effectif": "45"
          }
        },
        {
          "type": "chart",
          "title": "Évolution CA (5 ans)",
          "chart_type": "line",
          "data": [["2022", 10.2], ["2023", 11.1], ["2024", 11.8], ["2025", 12.5]]
        }
      ]
    }
  }'
```

---

### 2. M&A Research Service

**Endpoint** : `http://mna-research:8001/research`

```bash
# Recherche complète entreprise
curl -X POST "http://localhost:8001/research" \
  -H "Content-Type: application/json" \
  -d '{
    "siret": "34977287100027",
    "depth": "full"
  }'

# Réponse
{
  "sirene": { /* données INSEE */ },
  "pappers": { /* données Pappers */ },
  "financials": { /* ratios */ },
  "news": [ /* actualités */ ],
  "risks": [ /* alertes */ ]
}
```

---

### 3. Audio Processor

**Endpoint** : `http://audio-processor:8002`

```bash
# Text-to-Speech
curl -X POST "http://localhost:8002/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Voici le résumé de votre journée...",
    "voice": "fr-FR-HenriNeural",
    "output_format": "ogg"
  }' \
  --output response.ogg

# Speech-to-Text
curl -X POST "http://localhost:8002/stt" \
  -F "audio=@message.ogg" \
  -F "language=fr"
```

---

## 📋 Résumé des Credentials Requis

| Service | Variable | Type | Où l'obtenir |
|---------|----------|------|--------------|
| Kimi API | `KIMI_API_KEY` | Bearer | platform.moonshot.cn |
| Claude API | `CLAUDE_API_KEY` | x-api-key | console.anthropic.com |
| Pappers | `PAPPERS_API_KEY` | Query | pappers.fr/api |
| INSEE | `INSEE_CLIENT_ID/SECRET` | OAuth2 | api.insee.fr |
| API Entreprise | `API_ENTREPRISE_TOKEN` | Bearer | entreprise.api.gouv.fr |
| Brave Search | `BRAVE_API_KEY` | Header | brave.com/search/api |
| Microsoft Graph | `MS_GRAPH_TOKEN` | OAuth2 | azure.microsoft.com |
| Pipedrive | `PIPEDRIVE_API_KEY` | Query | pipedrive.com/settings/api |

---

*Largo 2.0 — APIs maîtrisées, intégrations fluides.*
