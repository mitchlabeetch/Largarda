# USER.md — Profils Utilisateurs Largo 2.0

> Version: 2.0 — n8n Architecture Edition
> Last Updated: 2026-03-18

---

## 👤 Christophe Berthon — Propriétaire Principal

### Informations de Base

| Attribut | Valeur |
|----------|--------|
| **Nom** | Christophe Berthon |
| **Rôle** | Associé fondateur, Alecia M&A |
| **Localisation** | Côte d'Azur, France (Europe/Paris) |
| **Fuseau horaire** | UTC+1 (CET/CEST) |
| **Langue** | Français (natif) |

### Contexte Professionnel

**Alecia M&A**
- Cabinet de conseil en fusion-acquisition
- Spécialisation : Small-mid cap (1-50M€ CA)
- Zone : France / Francophone uniquement
- Position : Cédants ET investisseurs

### Famille (Contexte Personnel)

| Membre | Relation | Mention autorisée |
|--------|----------|-------------------|
| **Sylvie** | Épouse | ✅ Oui |
| **Lisa** | Fille | ✅ Oui |
| **Michaël** | Fils | ✅ Oui (avec humour) |

### Préférences de Communication

| Aspect | Préférence | Source |
|--------|------------|--------|
| **Tutoiement** | ✅ Oui | Message d'intro |
| **Ton** | Jovial, léger | Message d'intro |
| **Canal principal** | WhatsApp | À confirmer |
| **Canal documents** | Email | Message d'intro |
| **Audio** | ✅ Accepte vocaux | Message d'intro |

### Outils Utilisés

| Catégorie | Outil | Statut intégration |
|-----------|-------|-------------------|
| **Bureautique** | Office 365 (Excel, PowerPoint, Outlook) | ✅ Prêt |
| **Communication** | Microsoft Teams | ✅ Prêt |
| **CRM** | Pipedrive | ✅ Prêt |
| **Messagerie** | Slack | ✅ Prêt |
| **Suite interne** | Alecia Suite | 🔄 À venir |

### Accès Autorisé

- ✅ **WhatsApp** : Numéro configuré
- ✅ **Email** : largo@largo.fr
- ✅ **Admin** : largo.fr/admin (mot de passe par Michaël)
- ✅ **Slack** : Workspace Alecia

---

## 👤 Michaël — Support Technique

### Informations de Base

| Attribut | Valeur |
|----------|--------|
| **Nom** | Michaël Berthon |
| **Rôle** | Créateur et mainteneur technique de Largo |
| **Relation** | Fils de Christophe |
| **Accès** | Support technique uniquement |

### Responsabilités

| Domaine | Actions |
|---------|---------|
| **Infrastructure** | VPS, déploiement, maintenance |
| **Configuration** | Clés API, intégrations |
| **Debugging** | Problèmes techniques |
| **Mises à jour** | Skills, workflows, modèles |

### Restrictions CRITIQUES

| Interdit | Raison |
|----------|--------|
| ❌ Accès conversations Christophe-Largo | Confidentialité absolue |
| ❌ Lecture contenu échangé | Vie privée |
| ❌ Décisions métier | Rôle technique uniquement |
| ❌ Contact Christophe sans autorisation | Respect de l'autonomie |

### Protocole de Contact

```
Christophe demande → Largo demande confirmation → 
Christophe confirme → Largo contacte Michaël
```

---

## 🚫 Utilisateurs Non-Autorisés

### Règle Absolue

**AUCUN autre utilisateur** n'a accès à Largo sans autorisation explicite de Christophe.

### Politique de Confidentialité

| Scénario | Action |
|----------|--------|
| Collègue demande accès | Refus + proposition de demander à Christophe |
| Client mentionne Largo | Ne pas confirmer existence sans autorisation |
| Tiers demande information | Réponse : "Je ne peux pas discuter de ça" |

---

## 🔐 Authentification & Sécurité

### Méthodes d'Authentification

| Méthode | Usage | Configuration |
|---------|-------|---------------|
| **WhatsApp** | Principal | Baileys + numéro vérifié |
| **Email** | Documents | IMAP/SMTP authentifié |
| **Admin panel** | Gestion | Mot de passe fort (Michaël) |

### Allowlist

Seuls les contacts suivants peuvent interagir avec Largo:

1. ✅ Christophe Berthon (WhatsApp, Email)
2. ✅ Michaël Berthon (Telegram — support uniquement)

---

## 📊 Profil d'Usage Attendu

### Scénarios d'Usage Typiques

| Scénario | Fréquence | Canal |
|----------|-----------|-------|
| **Résumé M&A quotidien** | Quotidien 9h | WhatsApp |
| **Recherche entreprise** | 2-3x/semaine | WhatsApp/Email |
| **Analyse financière** | 1-2x/semaine | Email |
| **Génération document** | 1x/semaine | Email |
| **Préparation réunion** | 2-3x/semaine | WhatsApp |

### Patterns de Charge

```
Pic matinal : 9h-10h (résumé M&A, préparation journée)
Activité modérée : 10h-12h, 14h-18h
Veille : 18h-20h (résumés, planification)
```

---

## 🎯 Objectifs & KPIs

### Objectifs pour Christophe

1. **Gain de temps** : Automatiser tâches répétitives
2. **Meilleure information** : Recherche et synthèse rapide
3. **Qualité documents** : Decks et analyses professionnels
4. **Veille M&A** : Rester informé sans effort

### KPIs de Satisfaction

| Métrique | Cible |
|----------|-------|
| **Temps de réponse** | < 30s (simple), < 2min (complexe) |
| **Précision recherche** | > 90% sources vérifiées |
| **Satisfaction documents** | Feedback positif > 80% |
| **Adoption quotidienne** | Usage > 5 jours/semaine |

---

*Largo 2.0 — Conçu pour Christophe, protégé contre tous les autres.*
