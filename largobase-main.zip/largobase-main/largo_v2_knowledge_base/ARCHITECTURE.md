# ARCHITECTURE.md — Largo 2.0 Technical Architecture

> Version: 2.0-Flowise  
> Last Updated: 2026-04-12  
> Status: Production Ready  
> Déploiement primaire: **Flowise Assistant**

---

## 🏗️ Architecture Primaire — Flowise Assistant

Largo est déployé comme un **Flowise Assistant** avec agents, tools, RAG et mémoire.

```
┌──────────────────────────────────────────────────────────────────┐
│                    LARGO 2.0 — FLOWISE ARCHITECTURE               │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│   ┌───────────────────────────────────────────────────────────┐  │
│   │                   LARGO MAIN AGENT                         │  │
│   │                                                            │  │
│   │  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐  │  │
│   │  │ System Prompt│→ │  Chat Model  │→ │   TOOLS (11)    │  │  │
│   │  │ (SOUL +      │  │  Groq/Ollama │  │ search_company  │  │  │
│   │  │  IDENTITY)   │  │  /Kimi/GPT-4 │  │ get_valuation   │  │  │
│   │  └──────────────┘  └──────────────┘  │ web_search      │  │  │
│   │         ↑                            │ deep_research   │  │  │
│   │  ┌──────┴──────┐                     │ generate_doc    │  │  │
│   │  │Buffer Memory│                     │ save_memory     │  │  │
│   │  │   (k=10)    │                     │ get_memory      │  │  │
│   │  └─────────────┘                     │ delegate_agent  │  │  │
│   │                                      │ send_notif      │  │  │
│   │  ┌─────────────────────────────┐     │ query_rag       │  │  │
│   │  │   Vector Store (RAG)        │     │ get_multiples   │  │  │
│   │  │ Chroma / Pinecone           │     └─────────────────┘  │  │
│   │  │ Embeddings: Ollama /        │                           │  │
│   │  │            HuggingFace      │                           │  │
│   │  └─────────────────────────────┘                           │  │
│   └───────────────────────────────────────────────────────────┘  │
│                              │                                    │
│              delegate_to_agent tool                               │
│         ┌────────────────────┼──────────────────┐               │
│         ↓                   ↓                   ↓               │
│  ┌─────────────┐   ┌──────────────┐   ┌──────────────┐         │
│  │document_    │   │research_     │   │meeting_      │         │
│  │agent        │   │agent         │   │agent         │         │
│  └─────────────┘   └──────────────┘   └──────────────┘         │
│  ┌─────────────┐   ┌──────────────┐                             │
│  │email_agent  │   │prospect_agent│                             │
│  └─────────────┘   └──────────────┘                             │
│                                                                   │
│   ┌───────────────────────────────────────────────────────────┐  │
│   │               INFRASTRUCTURE (100% Free Tier)              │  │
│   │                                                            │  │
│   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│   │  │  Groq    │  │  Ollama  │  │  Chroma  │  │ Pinecone │  │  │
│   │  │ (Cloud)  │  │  (Local) │  │  (Local) │  │ (Cloud)  │  │  │
│   │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │  │
│   │  ┌──────────┐  ┌──────────┐  ┌────────────────────────┐  │  │
│   │  │   Zep    │  │HuggingFace  │  DuckDuckGo / Brave   │  │  │
│   │  │ (Memory) │  │(Embedding)  │  (Web Search)         │  │  │
│   │  └──────────┘  └──────────┘  └────────────────────────┘  │  │
│   └───────────────────────────────────────────────────────────┘  │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Flux de Données Flowise

### Requête Utilisateur → Réponse Agent

```
Message Utilisateur
       ↓
Flowise Chat API (port 3000)
       ↓
Buffer Memory (récupération contexte k=10)
       ↓
Largo Main Agent (System Prompt + LLM)
       ↓
Décision : réponse directe / RAG / tool / délégation
       ↓
┌──────────────────────────────────────────────────┐
│  Si RAG      → query_rag → Vector Store           │
│  Si Recherche → search_company / web_search       │
│  Si Valorisation → get_valuation / get_multiples  │
│  Si Document  → generate_document → Microservice  │
│  Si Mémoire   → save_memory / get_memory          │
│  Si Délégation → delegate_to_agent → Sub-Agent    │
└──────────────────────────────────────────────────┘
       ↓
Buffer Memory (mise à jour contexte)
       ↓
Réponse structurée à l'utilisateur
```

### Recherche Entreprise (Tool: search_company)

```
"Recherche SIREN 123456789"
       ↓
Largo Main Agent
       ↓
Tool: search_company (paramètres: query, include_financials)
       ↓
Microservice mna-research (Flask API)
       ↓
APIs: Pappers / INSEE SIRENE / Infogreffe
       ↓
Fiche entreprise + scoring M&A
       ↓
Réponse formatée à Christophe
```

### Valorisation (Tool: get_valuation)

```
"Valorise avec EBITDA 500K€, secteur IT"
       ↓
Largo Main Agent
       ↓
Tool: get_valuation (ebitda, sector, net_debt, growth_rate)
       │
       ├─ Tool: get_multiples (multiples sectoriels)
       │
       ↓
Calcul EV / Equity (fourchette)
       ↓
Analyse formatée avec contexte M&A France
```

### Génération Document (Tool: generate_document)

```
"Génère un teaser PowerPoint pour Projet X"
       ↓
Largo Main Agent
       ↓
Tool: generate_document (template, data, format)
       ↓
Microservice pptx-generator (Flask API)
       ↓
python-pptx → PPTX généré
       ↓
Tool: send_notification → Email / WhatsApp
```

---

## 🛠️ Composants Détaillés

### 1. Flowise (Orchestrateur Agent)

```yaml
Version: 1.6.x+
Port: 3000
Docker Image: flowiseai/flowise
Database: SQLite (dev) / PostgreSQL (prod)
```

Fichiers de configuration : [flowise_kb/](flowise_kb/)

### 2. Chat Models (LLM)

| Provider | Modèle | Free Tier | Usage |
|----------|--------|-----------|-------|
| **Groq** ⭐ | llama-3.3-70b | 1M tokens/jour | Principal (cloud) |
| **Ollama** | llama3.2:70b | Illimité | Principal (local) |
| **Kimi** | kimi-k2-0711-preview | 1M tokens | 2M context (Data Rooms) |
| **OpenRouter** | claude-3.5-sonnet | 200 req/jour | Premium qualité |
| **Google** | Gemini Pro | 60 req/min | Alternative |

### 3. Vector Store (RAG)

| Provider | Free Tier | Recommandé |
|----------|-----------|------------|
| **Chroma** ⭐ | Illimité (local) | Dev / local |
| **Pinecone** | 100K vecteurs | Prod cloud |
| **Qdrant** | Illimité (local) | Alternative |

Contenu RAG : fichiers `knowledge/` uploadés dans Flowise Document Store.

### 4. Embeddings

| Provider | Modèle | Free Tier |
|----------|--------|-----------|
| **Ollama** ⭐ | nomic-embed-text | Illimité |
| **HuggingFace** | all-MiniLM-L6-v2 | 30K req/jour |

### 5. Mémoire

| Type | Provider | Rôle |
|------|----------|------|
| **Buffer Memory** | Flowise natif | Court terme (k=10 messages) |
| **Zep** | Zep Cloud / self-hosted | Long terme persistant |
| **Vector Memory** | Vector Store | Préférences et faits |
| **Conversation Store** | PostgreSQL | Historique complet |

Configs : [flowise_kb/memory/](flowise_kb/memory/)

### 6. Custom Tools (11)

| Tool | Rôle | Backend |
|------|------|---------|
| `search_company` | Recherche entreprise FR | mna-research microservice |
| `get_valuation` | Valorisation multiples | mna-research microservice |
| `get_multiples` | Multiples sectoriels | mna-research microservice |
| `web_search` | Recherche web | DuckDuckGo / Brave API |
| `deep_research` | Recherche approfondie | browser_scraper + LLM |
| `generate_document` | Génération PPTX/Word/Excel | pptx-generator microservice |
| `save_memory` | Sauvegarde préférence | Zep / PostgreSQL |
| `get_memory` | Récupération mémoire | Zep / PostgreSQL |
| `delegate_to_agent` | Délégation sous-agent | Flowise Agentflow |
| `send_notification` | WhatsApp / Email | whatsapp-gateway / SMTP |
| `query_rag` | Interrogation KB | Vector Store |

Configs JSON : [flowise_kb/tools/](flowise_kb/tools/)

### 7. Microservices Python (Docker)

```
services/
├── mna-research/        # Recherche M&A France (Flask, port 5001)
│   ├── app.py           → Endpoints: /search, /valuation, /multiples
│   ├── valuation.py     → Moteur de valorisation
│   └── Dockerfile
│
├── pptx-generator/      # Génération PowerPoint (Flask, port 5002)
│   ├── app.py           → Endpoint: /generate
│   └── Dockerfile
│
├── document-parser/     # OCR & extraction (Flask, port 5003)
│   ├── app.py           → Endpoint: /parse
│   └── Dockerfile
│
└── whatsapp-gateway/    # Gateway WhatsApp (Node.js, port 3001)
    ├── app.js           → Baileys WebSocket
    └── Dockerfile
```

### 8. Base de Données

```yaml
PostgreSQL 15+:
  Database: largo_memory
  Tables:
    - conversations  # Historique sessions
    - preferences    # Préférences utilisateur
    - deals          # Dossiers M&A suivis
    - documents      # Métadonnées documents générés
```

Schéma : [init.sql](init.sql)

---

## 📊 Schéma de Base de Données

### Table `conversations`

```sql
CREATE TABLE conversations (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    channel VARCHAR(50) NOT NULL,   -- flowise, whatsapp, email
    messages JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_session ON conversations(session_id);
CREATE INDEX idx_user ON conversations(user_id);
CREATE INDEX idx_updated ON conversations(updated_at);
```

### Table `preferences`

```sql
CREATE TABLE preferences (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,  -- communication, documents, style
    key VARCHAR(255) NOT NULL,
    value JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, category, key)
);
```

### Table `deals`

```sql
CREATE TABLE deals (
    id SERIAL PRIMARY KEY,
    deal_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(500),
    siret VARCHAR(14),
    siren VARCHAR(9),
    status VARCHAR(50),   -- active, closed, on_hold
    data JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_siret ON deals(siret);
CREATE INDEX idx_status ON deals(status);
```

---

## 🔌 Intégrations

### Web Search

```yaml
DuckDuckGo: Illimité, sans API key (défaut)
Brave Search: 2000 req/mois (API key requise)
```

### APIs M&A France

```yaml
Pappers API: https://api.pappers.fr/v2
  - Recherche SIREN/SIRET/nom
  - Dirigeants, actionnaires, financiers
  
INSEE SIRENE: https://api.insee.fr/entreprises/sirene/V3
  - Données officielles entreprises
  
Infogreffe: https://opendata.infogreffe.fr
  - Actes, bilans, kbis
```

### Notifications

```yaml
WhatsApp (Baileys):
  Gateway: services/whatsapp-gateway (port 3001)
  Auth: Multi-file auth state
  
Email (SMTP):
  SMTP: smtp.gmail.com:587 (ou Exchange)
  Features: HTML, pièces jointes
```

### Microsoft Graph (Optionnel)

```yaml
Endpoint: https://graph.microsoft.com/v1.0
Scopes: Mail.ReadWrite, Calendars.ReadWrite, Files.ReadWrite
```

---

## 🔐 Sécurité

### Variables d'Environnement

```bash
# .env (ne jamais committer)
FLOWISE_SECRET_KEY=<random-32-char>
KIMI_API_KEY=sk-<moonshot-key>
GROQ_API_KEY=gsk_<groq-key>
POSTGRES_PASSWORD=<db-password>
PAPPERS_API_KEY=<pappers-key>
```

Modèle : [.env.example](.env.example)

### Network

```yaml
Flowise UI: localhost:3000 (ou HTTPS derrière reverse proxy)
Microservices: réseau Docker interne uniquement
PostgreSQL: localhost:5432 (non exposé)
SSL: Let's Encrypt (production)
```

---

## 🚀 Déploiement

### Local (Développement)

```bash
# 1. Copier les variables d'environnement
cp .env.example .env
# Remplir les clés API dans .env

# 2. Démarrer tous les services
docker-compose up -d

# 3. Initialiser la base de données
docker-compose exec postgres psql -U largo -d largo_memory -f /init.sql

# 4. Accéder à Flowise
open http://localhost:3000
```

### Configuration Flowise

```
1. Credentials → Ajouter Groq / HuggingFace / Pinecone
2. Tools → Importer flowise_kb/tools/*.json
3. Chatflows → Importer flowise_kb/agentflows/largo_main_agent.json
4. Document Stores → Uploader knowledge/ → Indexer
5. Tester : "Salut Largo, recherche SIREN 123456789"
```

Guide détaillé : [FLOWISE_COMPLETE_GUIDE.md](FLOWISE_COMPLETE_GUIDE.md)

---

## 💰 Coûts

| Composant | Configuration | Coût mensuel |
|-----------|--------------|--------------|
| Flowise self-hosted | Docker local / VPS | 0€ – 15€ |
| LLM (Groq) | 1M tokens/jour | 0€ |
| LLM (Kimi) | Usage variable | ~5€ |
| Vector Store (Chroma) | Local | 0€ |
| Embeddings (Ollama) | Local | 0€ |
| Web Search (DuckDuckGo) | Illimité | 0€ |
| PostgreSQL | Self-hosted | 0€ |
| **Total (cloud minimal)** | | **~5€** |
| **Total (full local)** | | **0€** |

---

## 🔄 Architecture Secondaire — n8n (Optionnelle)

> L'architecture n8n est conservée pour les **routines automatisées** et l'**orchestration avancée** complémentaire à Flowise.

```yaml
n8n Self-Hosted:
  Version: 1.50.0+
  Port: 5678
  Workflows: workflows/ (6 JSON exportables)
  Usage:
    - Résumé M&A quotidien (cron 9h)
    - Enrichissement prospects (scheduled)
    - Traitement messages WhatsApp entrants
    - Génération PPTX automatisée
```

Workflows disponibles :

| Workflow | Fichier | Déclencheur |
|----------|---------|-------------|
| Recherche entreprise | [workflows/mna/research-company.json](workflows/mna/research-company.json) | Webhook |
| Valorisation | [workflows/mna/generate-valuation.json](workflows/mna/generate-valuation.json) | Webhook |
| Création PPTX | [workflows/documents/create-pptx.json](workflows/documents/create-pptx.json) | Webhook |
| Résumé M&A quotidien | [workflows/routines/daily-mna-summary.json](workflows/routines/daily-mna-summary.json) | Cron 9h |
| Enrichissement prospects | [workflows/routines/prospect-enrichment.json](workflows/routines/prospect-enrichment.json) | Cron hebdo |
| Traitement messages | [workflows/communication/process-message.json](workflows/communication/process-message.json) | Webhook WhatsApp |

---

## 📈 Monitoring

### Health Checks

```bash
# Flowise
curl http://localhost:3000/api/v1/ping

# Microservices
curl http://localhost:5001/health  # mna-research
curl http://localhost:5002/health  # pptx-generator
curl http://localhost:5003/health  # document-parser

# WhatsApp Gateway
curl http://localhost:3001/status
```

---

*Largo 2.0 — Architecture Flowise native, modulaire et 100% opérationnelle.*
