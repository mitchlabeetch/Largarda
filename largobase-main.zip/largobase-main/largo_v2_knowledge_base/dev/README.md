# Largo 2.0 — Documentation Développeur

> **Version**: 2.0 — Developer Documentation  
> **Last Updated**: 2026-03-18

---

## 🚀 Démarrage Rapide Développeur

### Prérequis

- Docker & Docker Compose
- Python 3.11+
- Node.js 18+ (pour n8n local)
- Git

### Clone & Setup

```bash
# Clone repository
git clone https://github.com/michael/largo-v2.git
cd largo-v2

# Configuration
cp dev/.env.example dev/.env
# Éditer dev/.env avec vos clés API

# Démarrage local
cd dev && docker-compose up -d

# Vérification
curl http://localhost:5678/healthz
```

---

## 📚 Documentation Développeur

| Document | Description | Audience |
|----------|-------------|----------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Architecture technique complète | Architects, DevOps |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Guide déploiement production | DevOps, Admin |
| [OPERATIONS.md](OPERATIONS.md) | Opérations quotidiennes | Admin, Support |
| [API_REFERENCE.md](API_REFERENCE.md) | Référence APIs | Développeurs |
| [SECURITY.md](SECURITY.md) | Sécurité & confidentialité | Security, DevOps |
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Dépannage | Support, Admin |

---

## 🏗️ Architecture Technique

```
┌─────────────────────────────────────────────────────────────┐
│                         CLIENTS                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│  │WhatsApp │  │  Email  │  │  Slack  │  │  Teams  │        │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘        │
└───────┼────────────┼────────────┼────────────┼─────────────┘
        │            │            │            │
        └────────────┴────────────┴────────────┘
                           │
┌──────────────────────────┼──────────────────────────────────┐
│                     n8n ORCHESTRATION                        │
│  ┌───────────────────────┼───────────────────────────────┐  │
│  │  Workflows │ Schedules │ Webhooks │ Error Handling   │  │
│  └───────────────────────┼───────────────────────────────┘  │
└──────────────────────────┼──────────────────────────────────┘
        │           │           │           │
   ┌────┘     ┌────┘     ┌────┘     ┌────┘
   ▼          ▼          ▼          ▼
┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐
│ Kimi │  │Python│  │Postgre│  │Redis │
│ API  │  │Svcs  │  │  SQL  │  │Cache │
└──────┘  └──────┘  └──────┘  └──────┘
```

---

## 🔧 Composants

### n8n (Orchestration)

**Port**: 5678  
**URL**: http://localhost:5678

**Configuration**:
- Workflows dans `workflows/`
- Credentials dans UI n8n
- Variables d'environnement dans `.env`

### PostgreSQL (Database)

**Port**: 5432  
**Database**: largo_memory

**Tables principales**:
- `conversations` — Historique conversations
- `preferences` — Préférences utilisateur
- `deals` — Dossiers M&A
- `documents` — Documents stockés

### Python Microservices

| Service | Port | Description |
|---------|------|-------------|
| mna-research | 8001 | Recherche M&A |
| pptx-generator | 8002 | Génération PowerPoint |
| excel-generator | 8003 | Génération Excel |
| document-parser | 8004 | OCR & parsing |
| whatsapp-gateway | 8005 | Gateway WhatsApp |

---

## 📝 Développement

### Ajouter un Workflow n8n

1. Créer fichier JSON dans `workflows/{category}/`
2. Nommer: `{action}-{target}.json`
3. Tester localement
4. Documenter dans WORKFLOWS.md

### Ajouter un Script Python

1. Créer fichier dans `scripts/{category}/`
2. Ajouter docstring avec usage
3. Créer tests unitaires
4. Documenter dans INDEX.md

### Ajouter un Microservice

1. Créer dossier dans `services/{name}/`
2. Fichiers requis:
   - `Dockerfile`
   - `requirements.txt`
   - `app.py`
3. Ajouter à `docker-compose.yml`
4. Documenter endpoint health

---

## 🧪 Tests

```bash
# Tests unitaires
cd scripts && python -m pytest tests/

# Tests intégration
docker-compose -f dev/docker-compose.test.yml up

# Tests workflows
n8n execute --file workflows/mna/research-company.json
```

---

## 📦 Déploiement

Voir [DEPLOYMENT.md](DEPLOYMENT.md) pour:
- Déploiement VPS
- Configuration DNS
- SSL/TLS
- Monitoring

---

## 🆘 Support

| Problème | Solution |
|----------|----------|
| n8n ne démarre pas | Vérifier `.env`, ports 5678 |
| PostgreSQL erreur | Vérifier credentials, espace disque |
| API indisponible | Vérifier tokens dans `.env` |
| Workflow échoue | Vérifier logs: `docker-compose logs n8n` |

---

*Largo 2.0 — Documentation Développeur*
