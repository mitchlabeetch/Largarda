# DEPLOYMENT.md — Guide de Déploiement Largo 2.0

> Version: 2.0 — n8n + Docker Architecture
> Last Updated: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce guide détaille le déploiement complet de Largo 2.0 sur un VPS.

**Architecture** :
- n8n (orchestration)
- PostgreSQL (mémoire)
- Redis (cache)
- MinIO (stockage fichiers)
- Python microservices

**Temps estimé** : 2-3 heures

---

## 📋 Prérequis

### VPS Recommandé

| Fournisseur | Offre | Prix | Lien |
|-------------|-------|------|------|
| **Contabo** | VPS S | ~€15/mois | contabo.com |
| **Hetzner** | CPX21 | ~€12/mois | hetzner.com |
| **OVH** | VPS Comfort | ~€15/mois | ovh.com |

**Spécifications minimales** :
- 4 vCPU
- 8 GB RAM
- 100 GB SSD
- Ubuntu 22.04 LTS

### Domaine

- Domaine : `largo.fr` (ou autre)
- Sous-domaines :
  - `n8n.largo.fr` — Interface n8n
  - `api.largo.fr` — APIs microservices
  - `minio.largo.fr` — Console MinIO (optionnel)

---

## 🚀 Installation

### Étape 1 : Préparation VPS

```bash
# Connexion SSH
ssh root@<vps-ip>

# Mise à jour
apt update && apt upgrade -y

# Installation dépendances
apt install -y \
    curl \
    wget \
    git \
    docker.io \
    docker-compose \
    nginx \
    certbot \
    python3-certbot-nginx \
    ufw \
    fail2ban

# Démarrage Docker
systemctl enable docker
systemctl start docker

# Création utilisateur
useradd -m -s /bin/bash largo
usermod -aG docker largo
```

### Étape 2 : Configuration DNS

```
Type    Name            Value               TTL
A       @               <vps-ip>            3600
A       n8n             <vps-ip>            3600
A       api             <vps-ip>            3600
A       minio           <vps-ip>            3600
```

### Étape 3 : Configuration Firewall

```bash
# UFW
ufw default deny incoming
ufw default allow outgoing

# Ports nécessaires
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS

# Activer
ufw enable
```

### Étape 4 : Clone Repository

```bash
# Switch user
su - largo

# Clone
cd ~
git clone https://github.com/michael/largo-v2.git
cd largo-v2

# Structure
mkdir -p {data/postgres,data/redis,data/minio,data/n8n,workflows,scripts}
```

### Étape 5 : Configuration Environment

```bash
# Copier template
cp .env.example .env

# Éditer
nano .env
```

**Contenu .env** :

```bash
# ============================================
# LARGO 2.0 — Configuration Environment
# ============================================

# --- Base ---
DOMAIN=largo.fr
TZ=Europe/Paris

# --- n8n ---
N8N_ENCRYPTION_KEY=<random-32-char-string>
N8N_WEBHOOK_URL=https://n8n.largo.fr/
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=<strong-password>

# --- PostgreSQL ---
POSTGRES_USER=largo
POSTGRES_PASSWORD=<strong-db-password>
POSTGRES_DB=largo_memory

# --- Redis ---
REDIS_PASSWORD=<strong-redis-password>

# --- MinIO ---
MINIO_ROOT_USER=largo
MINIO_ROOT_PASSWORD=<strong-minio-password>
MINIO_BUCKET=largo-files

# --- APIs ---
KIMI_API_KEY=sk-<moonshot-api-key>
CLAUDE_API_KEY=sk-ant-<anthropic-api-key>
PAPPERS_API_KEY=<pappers-api-key>
INSEE_API_TOKEN=<insee-token>
BRAVE_API_KEY=<brave-search-key>

# --- Microsoft Graph ---
MS_CLIENT_ID=<azure-app-id>
MS_CLIENT_SECRET=<azure-app-secret>
MS_TENANT_ID=<azure-tenant>

# --- Pipedrive ---
PIPEDRIVE_API_KEY=<pipedrive-api-key>

# --- WhatsApp (Baileys) ---
WHATSAPP_SESSION_NAME=largo-session
```

### Étape 6 : Docker Compose

**docker-compose.yml** :

```yaml
version: '3.8'

services:
  # ============================================
  # n8n — Orchestration
  # ============================================
  n8n:
    image: n8nio/n8n:1.50.0
    restart: always
    ports:
      - "127.0.0.1:5678:5678"
    environment:
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgres
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
      - DB_POSTGRESDB_USER=${POSTGRES_USER}
      - DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}
      - N8N_ENCRYPTION_KEY=${N8N_ENCRYPTION_KEY}
      - N8N_WEBHOOK_URL=${N8N_WEBHOOK_URL}
      - WEBHOOK_URL=${N8N_WEBHOOK_URL}
      - N8N_BASIC_AUTH_ACTIVE=${N8N_BASIC_AUTH_ACTIVE}
      - N8N_BASIC_AUTH_USER=${N8N_BASIC_AUTH_USER}
      - N8N_BASIC_AUTH_PASSWORD=${N8N_BASIC_AUTH_PASSWORD}
      - GENERIC_TIMEZONE=${TZ}
      - TZ=${TZ}
    volumes:
      - ./data/n8n:/home/node/.n8n
      - ./workflows:/workflows
      - ./scripts:/scripts
    depends_on:
      - postgres
      - redis
    networks:
      - largo-network

  # ============================================
  # PostgreSQL — Database
  # ============================================
  postgres:
    image: postgres:15-alpine
    restart: always
    environment:
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_DB=${POSTGRES_DB}
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    networks:
      - largo-network

  # ============================================
  # Redis — Cache
  # ============================================
  redis:
    image: redis:7-alpine
    restart: always
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - ./data/redis:/data
    networks:
      - largo-network

  # ============================================
  # MinIO — File Storage
  # ============================================
  minio:
    image: minio/minio:latest
    restart: always
    command: server /data --console-address ":9001"
    environment:
      - MINIO_ROOT_USER=${MINIO_ROOT_USER}
      - MINIO_ROOT_PASSWORD=${MINIO_ROOT_PASSWORD}
    volumes:
      - ./data/minio:/data
    networks:
      - largo-network

  # ============================================
  # Python Microservices
  # ============================================
  pptx-generator:
    build: ./services/pptx-generator
    restart: always
    environment:
      - PORT=8000
    volumes:
      - ./templates:/app/templates
      - ./data/outputs:/app/outputs
    networks:
      - largo-network

  mna-research:
    build: ./services/mna-research
    restart: always
    environment:
      - PORT=8001
      - PAPPERS_API_KEY=${PAPPERS_API_KEY}
      - INSEE_API_TOKEN=${INSEE_API_TOKEN}
    networks:
      - largo-network

  audio-processor:
    build: ./services/audio-processor
    restart: always
    environment:
      - PORT=8002
    networks:
      - largo-network

networks:
  largo-network:
    driver: bridge
```

### Étape 7 : Démarrage

```bash
# Build
docker-compose build

# Démarrage
docker-compose up -d

# Vérification
docker-compose ps
docker-compose logs -f
```

### Étape 8 : Nginx Reverse Proxy

```bash
# Configuration n8n
sudo nano /etc/nginx/sites-available/n8n
```

**Contenu** :

```nginx
server {
    listen 80;
    server_name n8n.largo.fr;
    
    location / {
        proxy_pass http://127.0.0.1:5678;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Activation
sudo ln -s /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# SSL
sudo certbot --nginx -d n8n.largo.fr
```

---

## 🔧 Configuration n8n

### 1. Premier Accès

```
URL: https://n8n.largo.fr
User: admin (from .env)
Password: (from .env)
```

### 2. Credentials

Ajouter dans n8n :

| Credential | Type | Valeur |
|------------|------|--------|
| `kimiApi` | HTTP Header | Authorization: Bearer ${KIMI_API_KEY} |
| `claudeApi` | HTTP Header | x-api-key: ${CLAUDE_API_KEY} |
| `postgresLargo` | PostgreSQL | Host: postgres, DB: largo_memory |
| `redisLargo` | Redis | Host: redis, Password: ${REDIS_PASSWORD} |

### 3. Import Workflows

```bash
# Copier workflows
cp -r workflows/* data/n8n/

# Ou via UI: Settings → Import
```

---

## ✅ Vérification

### Health Checks

```bash
# n8n
curl https://n8n.largo.fr/healthz

# PostgreSQL
docker-compose exec postgres pg_isready -U largo

# Redis
docker-compose exec redis redis-cli ping

# Microservices
curl http://localhost:8000/health
curl http://localhost:8001/health
curl http://localhost:8002/health
```

### Test End-to-End

```bash
# Test recherche entreprise
curl -X POST http://localhost:8001/research \
  -H "Content-Type: application/json" \
  -d '{"siren": "349772871"}'
```

---

## 🔒 Sécurité

### Fail2ban

```bash
# Configuration
sudo nano /etc/fail2ban/jail.local
```

```ini
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
```

```bash
sudo systemctl restart fail2ban
```

### Mises à jour automatiques

```bash
# Unattended upgrades
sudo apt install unattended-upgrades
sudo dpkg-reconfigure unattended-upgrades
```

---

## 📊 Monitoring

### Docker Logs

```bash
# Tous les services
docker-compose logs -f

# Service spécifique
docker-compose logs -f n8n
```

### Resource Usage

```bash
# Docker stats
docker stats

# VPS stats
htop
df -h
```

---

## 🔄 Mises à jour

### Mise à jour n8n

```bash
cd ~/largo-v2

# Backup
docker-compose exec postgres pg_dump -U largo largo_memory > backup_$(date +%Y%m%d).sql

# Update
docker-compose pull n8n
docker-compose up -d n8n
```

### Mise à jour complète

```bash
cd ~/largo-v2

# Backup
docker-compose exec postgres pg_dump -U largo largo_memory > backup_$(date +%Y%m%d).sql

# Update
docker-compose pull
docker-compose up -d

# Cleanup
docker system prune -f
```

---

## 🆘 Troubleshooting

### n8n ne démarre pas

```bash
# Logs
docker-compose logs n8n

# Permissions
sudo chown -R 1000:1000 data/n8n

# Reset
docker-compose down
docker-compose up -d
```

### PostgreSQL erreur

```bash
# Vérifier espace disque
df -h

# Logs
docker-compose logs postgres

# Repair
docker-compose down
docker-compose up -d postgres
```

---

*Largo 2.0 — Déployé, sécurisé, opérationnel.*
