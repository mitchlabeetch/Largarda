# POWERPOINT — Génération de Présentations

> **Version**: 2.0 — Génération PowerPoint pour M&A  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Largo peut générer des présentations PowerPoint professionnelles à partir de templates, avec préservation des master slides et insertion dynamique de données.

### Capacités

- ✅ Génération depuis templates
- ✅ Préservation master slides
- ✅ Insertion données dynamiques
- ✅ Graphiques (barres, lignes, camemberts)
- ✅ Tableaux formatés
- ✅ Images et logos

---

## 📁 TEMPLATES DISPONIBLES

### Templates M&A

| Template | Usage | Fichier |
|----------|-------|---------|
| **Executive Summary** | Résumé exécutif deal | `templates/pptx/executive_summary.pptx` |
| **Company Profile** | Profil entreprise cible | `templates/pptx/company_profile.pptx` |
| **Valuation Report** | Rapport de valorisation | `templates/pptx/valuation_report.pptx` |
| **Teaser Acquisition** | Teaser anonymisé | `templates/pptx/teaser_acquisition.pptx` |
| **Due Diligence** | Présentation DD | `templates/pptx/due_diligence.pptx` |

### Structure d'un Template

```
slide_1: Title Slide
  - Titre du projet
  - Date
  - Logo Alecia

slide_2: Executive Summary
  - Points clés
  - Recommandation

slide_3: Company Overview
  - Identité
  - Historique
  - Activité

slide_4: Financial Highlights
  - CA, EBITDA, Marge
  - Évolution

slide_5: Valuation
  - Fourchette
  - Comparables

slide_6: Next Steps
  - Actions
  - Calendrier
```

---

## 🛠️ GÉNÉRATION POWERPOINT

### Script Principal

```python
from scripts.documents.pptx_generator import PowerPointGenerator

# Initialiser
generator = PowerPointGenerator()

# Générer présentation
result = generator.generate(
    template="templates/pptx/executive_summary.pptx",
    data={
        "project_name": "Projet Acquisition - Société X",
        "date": "18 mars 2026",
        "company": {
            "name": "Société X",
            "siren": "123456789",
            "activity": "Services informatiques",
            "location": "Nice",
            "employees": 45
        },
        "financials": {
            "ca": "12.5M€",
            "ebitda": "2.1M€",
            "margin": "16.8%",
            "ev": "12M€ - 16M€"
        },
        "metrics_chart": {
            "type": "bar",
            "data": {
                "CA": [10.2, 11.1, 11.8, 12.5],
                "EBITDA": [1.5, 1.7, 1.9, 2.1]
            },
            "years": ["2022", "2023", "2024", "2025"]
        },
        "next_steps": [
            "Signature LOI - 25 mars",
            "Due Diligence - Avril",
            "Closing - Mai"
        ]
    },
    output_path="/tmp/projet_x_summary.pptx"
)

print(f"Généré: {result['output_path']}")
```

### Types de Slides Supportés

#### 1. Title Slide

```python
{
    "type": "title",
    "title": "Titre du projet",
    "subtitle": "Sous-titre optionnel",
    "date": "18 mars 2026"
}
```

#### 2. Content Slide

```python
{
    "type": "content",
    "title": "Titre de la slide",
    "content": [
        "Point 1",
        "Point 2",
        "Point 3"
    ]
}
```

#### 3. Metrics Slide

```python
{
    "type": "metrics",
    "title": "KPIs Clés",
    "metrics": [
        {"label": "CA", "value": "12.5M€", "change": "+6%"},
        {"label": "EBITDA", "value": "2.1M€", "change": "+11%"},
        {"label": "Marge", "value": "16.8%", "change": "+0.8pp"},
        {"label": "Effectif", "value": "45", "change": "+5"}
    ]
}
```

#### 4. Chart Slide

```python
{
    "type": "chart",
    "title": "Évolution CA",
    "chart_type": "line",  # line, bar, pie
    "data": {
        "labels": ["2022", "2023", "2024", "2025"],
        "datasets": [
            {
                "label": "CA (M€)",
                "data": [10.2, 11.1, 11.8, 12.5],
                "color": "#1f4e79"
            }
        ]
    }
}
```

#### 5. Table Slide

```python
{
    "type": "table",
    "title": "Comparables",
    "headers": ["Entreprise", "CA", "EV/EBITDA", "EV"],
    "rows": [
        ["Comparable A", "15M€", "6.5x", "97.5M€"],
        ["Comparable B", "12M€", "5.8x", "69.6M€"],
        ["Comparable C", "18M€", "7.2x", "129.6M€"]
    ]
}
```

#### 6. Two Column Slide

```python
{
    "type": "two_column",
    "title": "Points Forts / Points de Vigilance",
    "left": {
        "title": "Points Forts",
        "content": ["Croissance 15%/an", "Marge élevée", "Clientèle fidèle"]
    },
    "right": {
        "title": "Points de Vigilance",
        "content": ["Dépendance client", "BFR négatif", "Concurrence"]
    }
}
```

---

## 📊 GRAPHIQUES

### Graphique en Barres

```python
from scripts.documents.pptx_generator import create_bar_chart

chart = create_bar_chart(
    data={
        "Année": ["2022", "2023", "2024", "2025"],
        "CA (M€)": [10.2, 11.1, 11.8, 12.5],
        "EBITDA (M€)": [1.5, 1.7, 1.9, 2.1]
    },
    title="Évolution Financière",
    colors=["#1f4e79", "#70ad47"]
)
```

### Graphique en Lignes

```python
from scripts.documents.pptx_generator import create_line_chart

chart = create_line_chart(
    data={
        "Année": ["2022", "2023", "2024", "2025"],
        "Marge EBITDA": [14.7, 15.3, 16.1, 16.8]
    },
    title="Évolution Marge",
    show_trend=True
)
```

### Camembert

```python
from scripts.documents.pptx_generator import create_pie_chart

chart = create_pie_chart(
    data={
        "Services": 60,
        "Licences": 25,
        "Maintenance": 15
    },
    title="Répartition CA"
)
```

---

## 🎨 STYLES ET FORMATAGE

### Couleurs Alecia

```python
ALECIA_COLORS = {
    "primary": "#1f4e79",      # Bleu foncé
    "secondary": "#70ad47",     # Vert
    "accent": "#c55a11",        # Orange
    "text": "#333333",          # Gris foncé
    "light_bg": "#f2f2f2",      # Gris clair
    "white": "#ffffff"
}
```

### Polices

```python
FONTS = {
    "title": "Calibri Light",
    "heading": "Calibri",
    "body": "Calibri",
    "tables": "Calibri"
}
```

---

## 🔧 MICROSERVICE POWERPOINT

### API Endpoint

```bash
# Générer PowerPoint
curl -X POST http://localhost:8002/generate \
  -H "Content-Type: application/json" \
  -d '{
    "template": "executive_summary",
    "data": {...},
    "output_format": "pptx"
  }'

# Réponse
{
  "success": true,
  "download_url": "/files/output_xxx.pptx",
  "slide_count": 8
}
```

### Docker

```yaml
# docker-compose.yml
pptx-generator:
  build: ./services/pptx-generator
  ports:
    - "8002:8000"
  volumes:
    - ./templates:/app/templates
    - ./outputs:/app/outputs
```

---

## 📋 WORKFLOW N8N

### Créer PowerPoint depuis Deal

```json
{
  "name": "Create PPTX from Deal",
  "trigger": "manual",
  "nodes": [
    {
      "name": "Get Deal Data",
      "type": "postgres",
      "query": "SELECT * FROM deals WHERE deal_id = '{{ $json.deal_id }}'"
    },
    {
      "name": "Generate PPTX",
      "type": "httpRequest",
      "url": "http://pptx-generator:8000/generate",
      "method": "POST",
      "body": "={{ $json }}"
    },
    {
      "name": "Send Email",
      "type": "smtp",
      "to": "christophe@alecia.fr",
      "subject": "Présentation générée",
      "attachments": "={{ $json.download_url }}"
    }
  ]
}
```

---

## 🚀 EXEMPLES

### Exemple 1: Teaser Anonymisé

```python
from scripts.documents.pptx_generator import generate_teaser

teaser = generate_teaser(
    sector="Services informatiques",
    location="PACA",
    ca_range="10-15M€",
    ebitda_margin="15-20%",
    employees=45,
    highlights=[
        "Croissance 15%/an sur 3 ans",
        "Clientèle fidèle (90% de récurrence)",
        "Équipe management expérimentée"
    ],
    output="/tmp/teaser_anonyme.pptx"
)
```

### Exemple 2: Rapport Valorisation

```python
from scripts.documents.pptx_generator import generate_valuation_report

report = generate_valuation_report(
    company_name="Société X",
    siren="123456789",
    financials={
        "ca_2024": 12500000,
        "ebitda_2024": 2100000,
        "ca_2023": 11800000,
        "ebitda_2023": 1900000
    },
    valuation={
        "ebitda_multiple_range": [5.5, 7.5],
        "ev_range": [11550000, 15750000],
        "net_debt": 800000,
        "equity_value_range": [10750000, 14950000]
    },
    comparables=[...],
    output="/tmp/valuation_report.pptx"
)
```

---

*Largo 2.0 — Génération PowerPoint M&A*
