# EXCEL — Génération de Tableurs Avancés

> **Version**: 2.0 — Excel/Sheets pour M&A  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Largo peut créer des tableaux Excel avancés avec formules, tableaux croisés dynamiques, graphiques et formatage conditionnel.

### Capacités

- ✅ Formules complexes (VLOOKUP, INDEX/MATCH, SUMIFS, etc.)
- ✅ Tableaux croisés dynamiques
- ✅ Graphiques
- ✅ Formatage conditionnel
- ✅ Validation de données
- ✅ Multi-feuilles
- ✅ Export PDF

---

## 📁 TEMPLATES EXCEL

### Templates M&A

| Template | Usage | Fichier |
|----------|-------|---------|
| **Financial Model** | Modèle financier 3-5 ans | `templates/excel/financial_model.xlsx` |
| **Prospect List** | Liste prospects | `templates/excel/prospect_list.xlsx` |
| **Valuation Template** | Template valorisation | `templates/excel/valuation_template.xlsx` |
| **DD Checklist** | Checklist due diligence | `templates/excel/dd_checklist.xlsx` |
| **Comparable Analysis** | Analyse comparables | `templates/excel/comparable_analysis.xlsx` |
| **Pipeline CRM** | Pipeline deals | `templates/excel/pipeline_crm.xlsx` |

---

## 🛠️ GÉNÉRATION EXCEL

### Script Principal

```python
from scripts.documents.excel_generator import ExcelGenerator

# Initialiser
generator = ExcelGenerator()

# Générer fichier
result = generator.generate(
    template="templates/excel/financial_model.xlsx",
    data={
        "company_name": "Société X",
        "years": ["2024", "2025", "2026", "2027", "2028"],
        "revenue": {
            "product_a": [5000000, 5750000, 6612500, 7604375, 8745031],
            "product_b": [3000000, 3300000, 3630000, 3993000, 4392300],
            "total": [8000000, 9050000, 10242500, 11597375, 13137331]
        },
        "costs": {
            "cogs": [3200000, 3620000, 4097000, 4638950, 5255012],
            "personnel": [2000000, 2200000, 2420000, 2662000, 2928200],
            "other": [800000, 850000, 900000, 950000, 1000000]
        },
        "ebitda": [2000000, 2380000, 2825500, 3346425, 3954119],
        "capex": [300000, 350000, 400000, 450000, 500000],
        "working_capital": [400000, 453000, 512000, 580000, 657000]
    },
    formulas=True,
    charts=True,
    output_path="/tmp/financial_model.xlsx"
)
```

---

## 📊 FORMULES EXCEL

### Formules Générées Automatiquement

| Formule | Usage | Exemple généré |
|---------|-------|----------------|
| **SUM** | Somme | `=SUM(B2:B10)` |
| **SUMIFS** | Somme conditionnelle | `=SUMIFS(CA,Region,"PACA")` |
| **VLOOKUP** | Recherche | `=VLOOKUP(A2,Table,2,FALSE)` |
| **INDEX/MATCH** | Recherche avancée | `=INDEX(CA,MATCH(A2,Noms,0))` |
| **IF** | Condition | `=IF(B2>0,B2*1.15,0)` |
| **GROWTH** | Croissance | `=(B2-A2)/A2` |
| **AVERAGE** | Moyenne | `=AVERAGE(B2:M2)` |
| **NPV** | VAN | `=NPV(taux,F1:F5)+F0` |
| **IRR** | TRI | `=IRR(F0:F5)` |

### Modèle Financier — Structure

```
FEUILLE 1: Hypothèses
├── Croissance CA
├── Marge EBITDA
├── Capex / CA
├── BFR / CA
└── Taux d'actualisation

FEUILLE 2: Compte de Résultat
├── CA par produit
├── Coûts variables
├── Marge brute
├── Charges fixes
├── EBITDA
├── DAP
├── EBIT
├── Intérêts
├── Résultat avant impôt
├── Impôts
└── Résultat net

FEUILLE 3: Bilan
├── Actif immobilisé
├── BFR
├── Trésorerie
├── Capitaux propres
├── Dette financière
└── Passif circulant

FEUILLE 4: Flux de Trésorerie
├── FCF (Free Cash Flow)
├── DCF (Discounted Cash Flow)
└── Valeur terminale

FEUILLE 5: Ratios
├── Rentabilité
├── Structure financière
├── Liquidité
└── Valeur
```

---

## 📈 TABLEAUX CROISÉS DYNAMIQUES

### Création Pivot Table

```python
from scripts.documents.excel_generator import create_pivot_table

pivot = create_pivot_table(
    data_source="prospects",
    rows=["secteur", "region"],
    columns=["statut"],
    values=[
        {"field": "ca", "aggregation": "sum"},
        {"field": "ebitda", "aggregation": "average"}
    ],
    output_sheet="Analyse Prospects"
)
```

---

## 🎨 FORMATAGE CONDITIONNEL

### Règles de Formatage

```python
from scripts.documents.excel_generator import add_conditional_formatting

# Formatage marge EBITDA
add_conditional_formatting(
    worksheet="Compte de Résultat",
    range="E10:I10",
    rules=[
        {
            "type": "cell",
            "operator": "greaterThan",
            "value": 0.20,
            "format": {"bg_color": "#C6EFCE", "font_color": "#006100"}
        },
        {
            "type": "cell",
            "operator": "between",
            "value": [0.10, 0.20],
            "format": {"bg_color": "#FFEB9C", "font_color": "#9C5700"}
        },
        {
            "type": "cell",
            "operator": "lessThan",
            "value": 0.10,
            "format": {"bg_color": "#FFC7CE", "font_color": "#9C0006"}
        }
    ]
)
```

---

## 📊 GRAPHIQUES EXCEL

### Types de Graphiques

```python
from scripts.documents.excel_generator import add_chart

# Graphique en barres
add_chart(
    workbook=wb,
    chart_type="column",
    data_range="'Compte de Résultat'!$B$2:$F$5",
    title="Évolution CA",
    x_axis="Année",
    y_axis="CA (€)",
    location="Graphiques"
)

# Graphique en lignes
add_chart(
    workbook=wb,
    chart_type="line",
    data_range="'Ratios'!$B$2:$F$10",
    title="Évolution Marges",
    trendline=True
)

# Graphique combiné
add_chart(
    workbook=wb,
    chart_type="combo",
    primary_series=["CA", "EBITDA"],
    secondary_series=["Marge %"],
    title="Performance Financière"
)
```

---

## 🔧 MICROSERVICE EXCEL

### API Endpoint

```bash
# Générer Excel
curl -X POST http://localhost:8003/generate \
  -H "Content-Type: application/json" \
  -d '{
    "template": "financial_model",
    "data": {...},
    "options": {
      "formulas": true,
      "charts": true,
      "pivot_tables": false
    }
  }'

# Réponse
{
  "success": true,
  "download_url": "/files/financial_model_xxx.xlsx",
  "sheets": ["Hypothèses", "Compte de Résultat", "Bilan", "Flux", "Ratios"]
}
```

---

## 🚀 EXEMPLES

### Exemple 1: Liste Prospects

```python
from scripts.documents.excel_generator import generate_prospect_list

prospects = generate_prospect_list(
    sector="Imprimerie",
    departement="06",
    min_ca=1000000,
    results=[
        {"nom": "Imprimerie A", "siren": "123456789", "ca": 2500000, "ville": "Nice"},
        {"nom": "Imprimerie B", "siren": "987654321", "ca": 1800000, "ville": "Cannes"},
        # ...
    ],
    output="/tmp/prospects_imprimerie_06.xlsx"
)
```

### Exemple 2: Analyse Comparables

```python
from scripts.documents.excel_generator import generate_comparable_analysis

analysis = generate_comparable_analysis(
    target={
        "name": "Société X",
        "sector": "Services informatiques",
        "ca": 12500000,
        "ebitda": 2100000
    },
    comparables=[
        {"name": "Comp A", "ca": 15000000, "ebitda": 3000000, "ev": 97500000},
        {"name": "Comp B", "ca": 12000000, "ebitda": 2160000, "ev": 69600000},
        {"name": "Comp C", "ca": 18000000, "ebitda": 3600000, "ev": 129600000},
    ],
    output="/tmp/comparable_analysis.xlsx"
)
```

### Exemple 3: Pipeline CRM

```python
from scripts.documents.excel_generator import generate_pipeline

pipeline = generate_pipeline(
    deals=[
        {"name": "Projet A", "phase": "DD", "value": 5000000, "probability": 0.7},
        {"name": "Projet B", "phase": "LOI", "value": 8000000, "probability": 0.4},
        {"name": "Projet C", "phase": "Closing", "value": 12000000, "probability": 0.9},
    ],
    output="/tmp/pipeline.xlsx"
)
```

---

## 📋 WORKFLOW N8N

### Générer Excel depuis Recherche

```json
{
  "name": "Generate Excel from Research",
  "trigger": "webhook",
  "nodes": [
    {
      "name": "Research Company",
      "type": "httpRequest",
      "url": "http://mna-research:8001/research"
    },
    {
      "name": "Generate Excel",
      "type": "httpRequest",
      "url": "http://excel-generator:8003/generate",
      "body": "={{ $json }}"
    },
    {
      "name": "Send Email",
      "type": "smtp",
      "to": "christophe@alecia.fr",
      "attachments": "={{ $json.download_url }}"
    }
  ]
}
```

---

*Largo 2.0 — Génération Excel M&A*
