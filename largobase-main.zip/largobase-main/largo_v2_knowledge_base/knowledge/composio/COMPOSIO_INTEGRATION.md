# COMPOSIO INTEGRATION — Largo 2.0

> **Version**: 2.0 — Composio Platform Integration  
> **Last Updated**: 2026-03-18  
> **Status**: Production Ready

---

## 🎯 Vue d'Ensemble

[Composio](https://composio.dev) est une plateforme d'intégration qui fournit des connecteurs pré-authentifiés pour 100+ outils. Cette documentation couvre l'intégration complète de Composio dans Largo 2.0.

### Avantages Composio

| Avantage | Description |
|----------|-------------|
| **100+ intégrations** | Gmail, Slack, Notion, HubSpot, etc. |
| **Auth gérée** | OAuth, token refresh automatique |
| **Pas de code auth** | Élimine la complexité OAuth |
| **Sandboxing** | Exécution sécurisée des actions |
| **MCP compatible** | Model Context Protocol |

---

## 🔧 CONFIGURATION

### 1. Compte Composio

```bash
# Inscription
https://app.composio.dev/signup

# Plan recommandé: Starter ($20/mois)
# - 10,000 appels API/mois
# - 100+ intégrations
# - Support prioritaire
```

### 2. API Key

```bash
# Récupérer dans Settings > API Keys
export COMPOSIO_API_KEY="your-api-key"
```

### 3. Installation Client

```bash
pip install composio-core
```

---

## 📋 INTÉGRATIONS DISPONIBLES

### Catégorie: Productivité

| Outil | Actions | Usage Largo |
|-------|---------|-------------|
| **Gmail** | send_email, read_inbox, search | Communication |
| **Google Calendar** | create_event, list_events | Planning |
| **Google Drive** | upload, download, list | Documents |
| **Notion** | create_page, query_database | Knowledge base |
| **Slack** | send_message, create_channel | Communication |

### Catégorie: CRM & Sales

| Outil | Actions | Usage Largo |
|-------|---------|-------------|
| **HubSpot** | create_contact, create_deal | CRM |
| **Pipedrive** | create_deal, update_deal | CRM |
| **Salesforce** | create_lead, update_opportunity | CRM Enterprise |
| **Zoho CRM** | create_record, search_records | Alternative CRM |

### Catégorie: Finance

| Outil | Actions | Usage Largo |
|-------|---------|-------------|
| **QuickBooks** | create_invoice, get_report | Comptabilité |
| **Xero** | create_invoice, get_balance | Comptabilité |
| **Stripe** | create_payment, get_charges | Paiements |

### Catégorie: Communication

| Outil | Actions | Usage Largo |
|-------|---------|-------------|
| **Twilio** | send_sms, make_call | SMS/Voice |
| **SendGrid** | send_email, get_stats | Email marketing |
| **Mailchimp** | create_campaign, add_subscriber | Newsletter |

### Catégorie: Data & Research

| Outil | Actions | Usage Largo |
|-------|---------|-------------|
| **Airtable** | create_record, search_records | Base de données |
| **Google Sheets** | append_row, read_range | Spreadsheets |
| **SerpAPI** | search, get_results | Web search |

---

## 🛠️ WORKFLOWS COMPOSIO (10+)

### Workflow 1: Enrichissement Prospect Gmail + Pipedrive

```json
{
  "name": "Enrich Prospect Gmail to Pipedrive",
  "trigger": "gmail_new_email",
  "nodes": [
    {
      "name": "Gmail Trigger",
      "type": "composio_gmail",
      "action": "gmail_fetch_emails",
      "config": {
        "query": "subject:prospect OR subject:opportunité",
        "max_results": 10
      }
    },
    {
      "name": "Extract Email Data",
      "type": "code",
      "code": "// Extract sender, subject, body\nconst email = $input.first().json;\nreturn [{\n  json: {\n    from: email.from_,\n    subject: email.subject,\n    body: email.body,\n    date: email.date\n  }\n}];"
    },
    {
      "name": "Research Company",
      "type": "httpRequest",
      "url": "http://mna-research:8001/research",
      "method": "POST",
      "body": "={{ $json }}"
    },
    {
      "name": "Create Pipedrive Deal",
      "type": "composio_pipedrive",
      "action": "pipedrive_create_deal",
      "params": {
        "title": "={{ $json.subject }}",
        "person_name": "={{ $json.from }}",
        "value": 0,
        "currency": "EUR",
        "stage_id": 1
      }
    },
    {
      "name": "Add Note to Deal",
      "type": "composio_pipedrive",
      "action": "pipedrive_create_note",
      "params": {
        "content": "={{ $json.research_results }}",
        "deal_id": "={{ $pipedrive_create_deal.id }}"
      }
    }
  ]
}
```

### Workflow 2: Réunion Teams → Notion → Rappel

```json
{
  "name": "Teams Meeting to Notion + Reminder",
  "trigger": "calendar_event_upcoming",
  "nodes": [
    {
      "name": "Get Meeting Details",
      "type": "composio_google_calendar",
      "action": "googlecalendar_get_event",
      "params": {
        "event_id": "={{ $trigger.event_id }}"
      }
    },
    {
      "name": "Research Participants",
      "type": "httpRequest",
      "url": "http://mna-research:8001/batch_research",
      "method": "POST",
      "body": "={{ $json.attendees }}"
    },
    {
      "name": "Create Notion Page",
      "type": "composio_notion",
      "action": "notion_create_page",
      "params": {
        "parent": { "database_id": "meetings_db_id" },
        "properties": {
          "Name": { "title": [{ "text": { "content": "={{ $json.summary }}" } }] },
          "Date": { "date": { "start": "={{ $json.start.dateTime }}" } },
          "Participants": { "rich_text": [{ "text": { "content": "={{ $json.attendees }}" } }] },
          "Research": { "rich_text": [{ "text": { "content": "={{ $json.research_results }}" } }] }
        }
      }
    },
    {
      "name": "Send WhatsApp Reminder",
      "type": "httpRequest",
      "url": "http://whatsapp-gateway:8004/send",
      "method": "POST",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "📅 Réunion dans 45 min: {{ $json.summary }}\n👥 {{ $json.attendees.length }} participants\n🔗 Notion: {{ $notion_create_page.url }}"
      }
    }
  ]
}
```

### Workflow 3: Veille M&A Automatique

```json
{
  "name": "M&A News Monitoring",
  "trigger": "schedule_daily_8am",
  "nodes": [
    {
      "name": "Search News",
      "type": "composio_serpapi",
      "action": "serpapi_search",
      "params": {
        "query": "fusion acquisition France site:lesechos.fr OR site:cfnews.net",
        "num": 20
      }
    },
    {
      "name": "Summarize with Kimi",
      "type": "httpRequest",
      "url": "https://api.moonshot.cn/v1/chat/completions",
      "headers": {
        "Authorization": "Bearer {{ $env.KIMI_API_KEY }}"
      },
      "body": {
        "model": "kimi-k2-0711-preview",
        "messages": [
          {
            "role": "system",
            "content": "Résume les actualités M&A en format WhatsApp concis."
          },
          {
            "role": "user",
            "content": "={{ JSON.stringify($json.organic_results) }}"
          }
        ]
      }
    },
    {
      "name": "Send WhatsApp",
      "type": "httpRequest",
      "url": "http://whatsapp-gateway:8004/send",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "={{ $json.choices[0].message.content }}"
      }
    },
    {
      "name": "Save to Notion",
      "type": "composio_notion",
      "action": "notion_create_page",
      "params": {
        "parent": { "database_id": "mna_news_db_id" },
        "properties": {
          "Date": { "date": { "start": "={{ $now }}" } },
          "Summary": { "rich_text": [{ "text": { "content": "={{ $json.choices[0].message.content }}" } }] }
        }
      }
    }
  ]
}
```

### Workflow 4: Enrichissement Contact HubSpot

```json
{
  "name": "Enrich HubSpot Contact",
  "trigger": "hubspot_contact_created",
  "nodes": [
    {
      "name": "Get Contact Details",
      "type": "composio_hubspot",
      "action": "hubspot_get_contact",
      "params": {
        "contact_id": "={{ $trigger.contact_id }}"
      }
    },
    {
      "name": "Research Company",
      "type": "httpRequest",
      "url": "http://mna-research:8001/research",
      "body": {
        "identifier": "={{ $json.properties.company }}",
        "depth": "standard"
      }
    },
    {
      "name": "Update Contact",
      "type": "composio_hubspot",
      "action": "hubspot_update_contact",
      "params": {
        "contact_id": "={{ $trigger.contact_id }}",
        "properties": {
          "company_revenue": "={{ $json.research.entreprise.ca }}",
          "company_employees": "={{ $json.research.entreprise.effectif }}",
          "company_siren": "={{ $json.research.entreprise.siren }}",
          "enrichment_data": "={{ JSON.stringify($json.research) }}"
        }
      }
    }
  ]
}
```

### Workflow 5: Document Upload → Drive → Notification

```json
{
  "name": "Document Upload Pipeline",
  "trigger": "email_attachment_received",
  "nodes": [
    {
      "name": "Download Attachment",
      "type": "httpRequest",
      "url": "={{ $trigger.attachment_url }}"
    },
    {
      "name": "Upload to Drive",
      "type": "composio_google_drive",
      "action": "google_drive_upload_file",
      "params": {
        "file_path": "={{ $json.file_path }}",
        "folder_id": "documents_folder_id",
        "name": "={{ $trigger.filename }}"
      }
    },
    {
      "name": "Parse Document",
      "type": "httpRequest",
      "url": "http://document-parser:8004/parse",
      "body": {
        "file_url": "={{ $google_drive_upload_file.webViewLink }}"
      }
    },
    {
      "name": "Save to Database",
      "type": "postgres",
      "query": "INSERT INTO documents (filename, drive_url, extracted_text, metadata) VALUES ('{{ $trigger.filename }}', '{{ $google_drive_upload_file.webViewLink }}', '{{ $json.text }}', '{{ $json.metadata }}')"
    },
    {
      "name": "Notify User",
      "type": "httpRequest",
      "url": "http://whatsapp-gateway:8004/send",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "📄 Document reçu et traité: {{ $trigger.filename }}\n🔗 Drive: {{ $google_drive_upload_file.webViewLink }}"
      }
    }
  ]
}
```

### Workflow 6: Suivi Pipeline Deals

```json
{
  "name": "Deal Pipeline Tracking",
  "trigger": "pipedrive_deal_updated",
  "nodes": [
    {
      "name": "Get Deal History",
      "type": "composio_pipedrive",
      "action": "pipedrive_get_deal",
      "params": {
        "deal_id": "={{ $trigger.deal_id }}"
      }
    },
    {
      "name": "Check Stage Change",
      "type": "code",
      "code": "const deal = $input.first().json;\nconst stageChanged = deal.stage_id !== $trigger.previous_stage_id;\nreturn [{ json: { stageChanged, deal } }];"
    },
    {
      "name": "Create Calendar Event",
      "type": "composio_google_calendar",
      "action": "googlecalendar_create_event",
      "condition": "={{ $json.stageChanged }}",
      "params": {
        "summary": "Suivi {{ $json.deal.title }}",
        "description": "Deal moved to stage {{ $json.deal.stage_id }}",
        "start": { "dateTime": "={{ $addDays($now, 7) }}" },
        "end": { "dateTime": "={{ $addDays($now, 7, 1) }}" }
      }
    },
    {
      "name": "Send Notification",
      "type": "httpRequest",
      "url": "http://whatsapp-gateway:8004/send",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "🔄 Deal '{{ $json.deal.title }}' moved to new stage\n💰 Value: {{ $json.deal.value }}€\n📅 Follow-up scheduled"
      }
    }
  ]
}
```

### Workflow 7: Rapprochement Bancaire

```json
{
  "name": "Bank Reconciliation Alert",
  "trigger": "schedule_daily_6am",
  "nodes": [
    {
      "name": "Get Stripe Transactions",
      "type": "composio_stripe",
      "action": "stripe_list_charges",
      "params": {
        "created[gte]": "={{ $startOfDay($now) }}",
        "limit": 100
      }
    },
    {
      "name": "Get QuickBooks Entries",
      "type": "composio_quickbooks",
      "action": "quickbooks_get_transactions",
      "params": {
        "start_date": "={{ $formatDate($now, 'YYYY-MM-DD') }}"
      }
    },
    {
      "name": "Reconcile",
      "type": "code",
      "code": "// Match transactions\nconst stripe = $input.all()[0].json.data;\nconst qb = $input.all()[1].json;\nconst unmatched = stripe.filter(s => !qb.find(q => q.amount === s.amount));\nreturn [{ json: { unmatched_count: unmatched.length, unmatched } }];"
    },
    {
      "name": "Alert if Mismatch",
      "type": "httpRequest",
      "condition": "={{ $json.unmatched_count > 0 }}",
      "url": "http://whatsapp-gateway:8004/send",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "⚠️ {{ $json.unmatched_count }} transactions non rapprochées aujourd'hui"
      }
    }
  ]
}
```

### Workflow 8: Newsletter M&A Hebdo

```json
{
  "name": "Weekly M&A Newsletter",
  "trigger": "schedule_weekly_friday_5pm",
  "nodes": [
    {
      "name": "Get Week's Deals",
      "type": "postgres",
      "query": "SELECT * FROM deals WHERE created_at > NOW() - INTERVAL '7 days'"
    },
    {
      "name": "Get Week's News",
      "type": "composio_serpapi",
      "action": "serpapi_search",
      "params": {
        "query": "fusion acquisition France {{ $formatDate($now, 'YYYY-MM-DD') }}"
      }
    },
    {
      "name": "Generate Newsletter",
      "type": "httpRequest",
      "url": "https://api.moonshot.cn/v1/chat/completions",
      "headers": {
        "Authorization": "Bearer {{ $env.KIMI_API_KEY }}"
      },
      "body": {
        "model": "kimi-k2-0711-preview",
        "messages": [
          {
            "role": "system",
            "content": "Génère une newsletter M&A hebdomadaire professionnelle."
          },
          {
            "role": "user",
            "content": "Deals: {{ JSON.stringify($json.deals) }}\nNews: {{ JSON.stringify($json.organic_results) }}"
          }
        ]
      }
    },
    {
      "name": "Send via SendGrid",
      "type": "composio_sendgrid",
      "action": "sendgrid_send_email",
      "params": {
        "to": "christophe@alecia.fr",
        "subject": "Newsletter M&A — Semaine {{ $weekNumber($now) }}",
        "html": "={{ $json.choices[0].message.content }}"
      }
    }
  ]
}
```

### Workflow 9: Alertes Fiscales

```json
{
  "name": "Tax Deadline Alerts",
  "trigger": "schedule_daily_9am",
  "nodes": [
    {
      "name": "Check Upcoming Deadlines",
      "type": "postgres",
      "query": "SELECT * FROM tax_deadlines WHERE deadline_date BETWEEN NOW() AND NOW() + INTERVAL '7 days'"
    },
    {
      "name": "Send Alerts",
      "type": "httpRequest",
      "url": "http://whatsapp-gateway:8004/send",
      "body": {
        "jid": "={{ $env.WHATSAPP_OWNER_JID }}",
        "message": "📅 Échéances fiscales cette semaine:\n{{ $json.map(d => '• ' + d.name + ': ' + d.deadline_date).join('\\n') }}"
      }
    },
    {
      "name": "Create Calendar Events",
      "type": "composio_google_calendar",
      "action": "googlecalendar_create_event",
      "for_each": "={{ $json }}",
      "params": {
        "summary": "🚨 {{ $item.name }}",
        "description": "Échéance fiscale: {{ $item.description }}",
        "start": { "date": "={{ $item.deadline_date }}" }
      }
    }
  ]
}
```

### Workflow 10: Sync Contacts Multi-CRM

```json
{
  "name": "Multi-CRM Contact Sync",
  "trigger": "pipedrive_contact_created",
  "nodes": [
    {
      "name": "Get Pipedrive Contact",
      "type": "composio_pipedrive",
      "action": "pipedrive_get_person",
      "params": {
        "person_id": "={{ $trigger.person_id }}"
      }
    },
    {
      "name": "Create HubSpot Contact",
      "type": "composio_hubspot",
      "action": "hubspot_create_contact",
      "params": {
        "properties": {
          "email": "={{ $json.email }}",
          "firstname": "={{ $json.first_name }}",
          "lastname": "={{ $json.last_name }}",
          "company": "={{ $json.org_name }}",
          "phone": "={{ $json.phone }}"
        }
      }
    },
    {
      "name": "Create Airtable Record",
      "type": "composio_airtable",
      "action": "airtable_create_record",
      "params": {
        "base_id": "contacts_base_id",
        "table_name": "Contacts",
        "fields": {
          "Name": "={{ $json.name }}",
          "Email": "={{ $json.email }}",
          "Company": "={{ $json.org_name }}",
          "Source": "Pipedrive"
        }
      }
    },
    {
      "name": "Log Sync",
      "type": "postgres",
      "query": "INSERT INTO contact_syncs (pipedrive_id, hubspot_id, airtable_id, synced_at) VALUES ('{{ $trigger.person_id }}', '{{ $hubspot_create_contact.id }}', '{{ $airtable_create_record.id }}', NOW())"
    }
  ]
}
```

---

## 🔐 SÉCURITÉ

### Best Practices

1. **Ne jamais committer les clés API**
2. **Utiliser les variables d'environnement**
3. **Activer le sandboxing Composio**
4. **Limiter les scopes OAuth**

### Configuration Sécurisée

```python
# .env
COMPOSIO_API_KEY=sk-xxx
COMPOSIO_SANDBOX=true
COMPOSIO_ALLOWED_ACTIONS=gmail_send,pipedrive_create,...
```

---

## 💰 COÛTS

| Plan | Prix | Inclus |
|------|------|--------|
| **Free** | $0 | 1,000 appels/mois |
| **Starter** | $20/mois | 10,000 appels/mois |
| **Pro** | $50/mois | 50,000 appels/mois |
| **Enterprise** | Sur demande | Illimité |

---

*Largo 2.0 — Composio Integration Complete*
