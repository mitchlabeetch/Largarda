# FREE TOOLS DIRECTORY — Outils Gratuits & Workarounds

> **Version**: 2.0 — Ressources Gratuites pour M&A  
> **Last Updated**: 2026-03-18  
> **Budget**: 0€

---

## 🎯 Vue d'Ensemble

Ce répertoire recense les outils gratuits, les workarounds et les astuces pour réaliser des recherches M&A de qualité professionnelle sans budget.

---

## 📊 RECHERCHE ENTREPRISES — GRATUIT

### 1. APIs Publiques Françaises

| Source | Données | Limites | Workaround |
|--------|---------|---------|------------|
| **recherche-entreprises.api.gouv.fr** | SIREN, SIRET, NAF, adresse | Aucune | Utiliser directement |
| **api.insee.fr (SIRENE)** | Données détaillées | Token requis | Demande gratuite |
| **entreprise.api.gouv.fr** | Bilans, mandataires | Token requis | Demande gratuite |

#### Script Python

```python
# Recherche entreprise gratuite
import requests

def search_company_free(query: str) -> dict:
    """Recherche entreprise via API publique gratuite"""
    url = f"https://recherche-entreprises.api.gouv.fr/search?q={query}"
    response = requests.get(url)
    return response.json()

# Usage
result = search_company_free("Alecia Conseil")
```

### 2. Sites Web → API (Scraping)

| Site | Données | Méthode |
|------|---------|---------|
| **Societe.com** | Infos, dirigeants | BeautifulSoup |
| **Infogreffe** | Kbis, actes | Playwright |
| **Bodacc** | Annonces légales | RSS + parsing |
| **Pappers (free)** | Données limitées | API gratuite (100/mois) |

#### Workaround Pappers Gratuit

```python
# Pappers free tier: 100 requêtes/mois
import requests

def pappers_free(siren: str, api_key: str) -> dict:
    """Utilise le tier gratuit Pappers"""
    url = "https://api.pappers.fr/v2/entreprise"
    params = {"siren": siren, "api_token": api_key}
    response = requests.get(url, params=params)
    return response.json()

# Gestion quota
QUOTA_PAPPERS = 100  # par mois
```

### 3. LinkedIn → Données Entreprise

| Donnée | Méthode | Outil |
|--------|---------|-------|
| **Effectif** | Page entreprise | BeautifulSoup |
| **Dirigeants** | Page entreprise | Playwright |
| **Croissance** | Posts/analyses | Manuel |
| **Recrutement** | Offres d'emploi | RSS |

#### Script LinkedIn (Usage personnel uniquement)

```python
# Attention: Respecter les CGU LinkedIn
from playwright.sync_api import sync_playwright

def get_linkedin_company(company_name: str) -> dict:
    """Extrait données publiques LinkedIn"""
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(f"https://www.linkedin.com/company/{company_name}")
        
        # Extraction données publiques
        employees = page.locator('[data-test-id="about-us__size"]').text_content()
        
        browser.close()
        return {"employees": employees}
```

---

## 🔍 RECHERCHE WEB — GRATUIT

### 1. DuckDuckGo (Illimité)

| Fonction | Usage | Limites |
|----------|-------|---------|
| **Recherche texte** | Actualités, infos | Aucune |
| **Recherche news** | Veille M&A | Aucune |
| **Recherche images** | Logos, produits | Aucune |

#### Script

```python
from duckduckgo_search import DDGS

def search_news_free(query: str, max_results: int = 10) -> list:
    """Recherche actualités gratuite"""
    with DDGS() as ddgs:
        return list(ddgs.news(query, max_results=max_results))

# Veille M&A
news = search_news_free("fusion acquisition France", max_results=20)
```

### 2. Brave Search API (Gratuit)

| Plan | Requêtes | Coût |
|------|----------|------|
| **Free** | 2,000/mois | 0€ |
| **Pro** | 20,000/mois | $3/1,000 |

#### Script

```python
import requests

def brave_search_free(query: str, api_key: str) -> dict:
    """Brave Search API (2,000/mois gratuits)"""
    url = "https://api.search.brave.com/res/v1/web/search"
    headers = {"X-Subscription-Token": api_key}
    params = {"q": query}
    response = requests.get(url, headers=headers, params=params)
    return response.json()
```

### 3. Google Custom Search (Gratuit)

| Plan | Requêtes | Coût |
|------|----------|------|
| **Free** | 100/jour | 0€ |
| **Paid** | Illimité | $5/1,000 |

#### Script

```python
import requests

def google_search_free(query: str, api_key: str, cx: str) -> dict:
    """Google Custom Search (100/jour gratuits)"""
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": api_key,
        "cx": cx,
        "q": query
    }
    response = requests.get(url, params=params)
    return response.json()
```

---

## 📰 VEILLE M&A — GRATUIT

### 1. Flux RSS

| Source | URL | Fréquence |
|--------|-----|-----------|
| **Les Echos M&A** | lesechos.fr/rss/flux-m-a.xml | Quotidien |
| **Agefi** | agefi.fr/rss | Quotidien |
| **Capital Finance** | capitalfinance.fr/rss | Hebdo |
| **CFNews** | cfnews.net/rss | Hebdo |

#### Script Agrégation RSS

```python
import feedparser

def parse_rss_feed(url: str) -> list:
    """Parse un flux RSS"""
    feed = feedparser.parse(url)
    return [
        {
            "title": entry.title,
            "link": entry.link,
            "published": entry.published,
            "summary": entry.summary
        }
        for entry in feed.entries
    ]

# Agrégation multi-sources
feeds = [
    "https://www.lesechos.fr/rss/flux-m-a.xml",
    "https://www.agefi.fr/rss",
]
all_news = []
for feed_url in feeds:
    all_news.extend(parse_rss_feed(feed_url))
```

### 2. Google Alerts (Gratuit)

| Usage | Configuration |
|-------|---------------|
| **Veille entreprise** | "Nom entreprise" acquisition |
| **Veille secteur** | "secteur" fusion acquisition |
| **Veille dirigeants** | "Nom dirigeant" nomination |

#### Workaround Programmatique

```python
# Simuler Google Alerts via recherche périodique
def check_new_results(query: str, last_check: datetime) -> list:
    """Vérifie nouveaux résultats depuis dernière vérification"""
    results = search_news_free(query)
    new_results = [
        r for r in results
        if datetime.fromisoformat(r["date"]) > last_check
    ]
    return new_results
```

---

## 📊 DONNÉES FINANCIÈRES — GRATUIT

### 1. Bilans Entreprises (Gratuit)

| Source | Données | Accès |
|--------|---------|-------|
| **data.economie.gouv.fr** | Bilans anonymisés | API gratuite |
| **entreprise.api.gouv.fr** | Bilans spécifiques | Token gratuit |
| **INPI** | Comptes annuels | Téléchargement |

#### Script INPI

```python
import requests

def get_inpi_accounts(siren: str) -> list:
    """Récupère comptes annuels INPI"""
    url = f"https://opendata.datainfogreffe.fr/api/records/1.0/search/"
    params = {
        "dataset": "comptes-annuels",
        "q": siren
    }
    response = requests.get(url, params=params)
    return response.json().get("records", [])
```

### 2. Données de Marché (Gratuit)

| Source | Données | Usage |
|--------|---------|-------|
| **Yahoo Finance** | Cours, ratios | API gratuite |
| **Euronext** | Cours boursiers | Téléchargement |
| **AMF** | Informations émetteurs | Site web |

#### Script Yahoo Finance

```python
import yfinance as yf

def get_stock_data(ticker: str) -> dict:
    """Données boursières gratuites"""
    stock = yf.Ticker(ticker)
    return {
        "info": stock.info,
        "history": stock.history(period="1y"),
        "financials": stock.financials
    }
```

---

## 🗺️ DONNÉES GÉOGRAPHIQUES — GRATUIT

### 1. Géocodage (Gratuit)

| Service | Limite | Usage |
|---------|--------|-------|
| **Nominatim (OpenStreetMap)** | 1 req/sec | Adresse → Coordonnées |
| **Photon** | Illimité | Autocomplétion adresse |

#### Script

```python
import requests

def geocode_free(address: str) -> dict:
    """Géocodage gratuit via Nominatim"""
    url = "https://nominatim.openstreetmap.org/search"
    params = {
        "q": address,
        "format": "json",
        "limit": 1
    }
    headers = {"User-Agent": "Largo-M&A/1.0"}
    response = requests.get(url, params=params, headers=headers)
    return response.json()[0] if response.json() else None
```

### 2. Cartographie (Gratuit)

| Service | Usage |
|---------|-------|
| **Leaflet** | Cartes interactives |
| **OpenStreetMap** | Tuiles de carte |
| **Mapbox GL** | Visualisation (free tier) |

---

## 🤖 IA & LLM — GRATUIT / LOW-COST

### 1. Kimi (Moonshot) — Low Cost

| Modèle | Context | Prix Input | Prix Output |
|--------|---------|------------|-------------|
| **kimi-k2-0711-preview** | 2M tokens | $0.50/M | $1.00/M |

#### Script

```python
import requests
import os

def call_kimi(prompt: str, system: str = None) -> str:
    """Appel API Kimi (coût ~$0.001-0.01 par requête)"""
    api_key = os.getenv("KIMI_API_KEY")
    url = "https://api.moonshot.cn/v1/chat/completions"
    
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    
    response = requests.post(
        url,
        headers={"Authorization": f"Bearer {api_key}"},
        json={
            "model": "kimi-k2-0711-preview",
            "messages": messages,
            "temperature": 0.3
        }
    )
    return response.json()["choices"][0]["message"]["content"]
```

### 2. Ollama (Local — Gratuit)

| Modèle | Taille | Usage |
|--------|--------|-------|
| **Llama 3.1** | 8B | Général |
| **Mistral** | 7B | Français |
| **Qwen 2.5** | 7B | Multilingue |

#### Setup

```bash
# Installation
curl -fsSL https://ollama.com/install.sh | sh

# Lancement modèle
ollama run llama3.1

# API locale
curl http://localhost:11434/api/generate -d '{
  "model": "llama3.1",
  "prompt": "Analyze this company..."
}'
```

### 3. Groq (Gratuit — Limité)

| Plan | Tokens/jour | Modèles |
|------|-------------|---------|
| **Free** | 1M/jour | Llama, Mixtral |

#### Script

```python
import requests

def call_groq_free(prompt: str, api_key: str) -> str:
    """Groq API (1M tokens/jour gratuits)"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}"}
    body = {
        "model": "llama-3.1-8b-instant",
        "messages": [{"role": "user", "content": prompt}]
    }
    response = requests.post(url, headers=headers, json=body)
    return response.json()["choices"][0]["message"]["content"]
```

---

## 📧 EMAIL & COMMUNICATION — GRATUIT

### 1. Gmail API (Gratuit)

| Quota | Usage |
|-------|-------|
| **1 milliard** quotas/jour | Lecture/écriture |

#### Setup

```python
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials

# Authentification OAuth2
creds = Credentials.from_authorized_user_file('token.json')
service = build('gmail', 'v1', credentials=creds)

# Lire emails
results = service.users().messages().list(userId='me', q='subject:M&A').execute()
```

### 2. SendGrid (Gratuit)

| Plan | Emails/jour | Coût |
|------|-------------|------|
| **Free** | 100/jour | 0€ |

---

## 📁 STOCKAGE — GRATUIT

### 1. Cloud Storage

| Service | Espace | Usage |
|---------|--------|-------|
| **Google Drive** | 15 GB | Documents |
| **Dropbox** | 2 GB | Backup |
| **OneDrive** | 5 GB | Microsoft |

### 2. Base de Données

| Service | Limite | Usage |
|---------|--------|-------|
| **Supabase** | 500 MB | PostgreSQL |
| **Neon** | 500 MB | PostgreSQL |
| **MongoDB Atlas** | 512 MB | MongoDB |

---

## 🔄 WORKFLOWS — GRATUIT

### 1. n8n (Self-hosted — Gratuit)

| Option | Coût | Limites |
|--------|------|---------|
| **Self-hosted** | 0€ | Aucune |
| **Cloud** | €20/mois | Facilité |

### 2. GitHub Actions (Gratuit)

| Plan | Minutes/mois | Usage |
|------|--------------|-------|
| **Free** | 2,000 | CI/CD |

---

## 🛠️ ASTUCES & WORKAROUNDS

### Astuce 1: Contourner les Limites API

```python
# Rotation clés API (plusieurs comptes gratuits)
API_KEYS = ["key1", "key2", "key3"]
current_key = 0

def get_api_key():
    global current_key
    key = API_KEYS[current_key]
    current_key = (current_key + 1) % len(API_KEYS)
    return key
```

### Astuce 2: Cache Intelligent

```python
import json
import os
from datetime import datetime, timedelta

CACHE_DIR = ".cache"
os.makedirs(CACHE_DIR, exist_ok=True)

def cached_request(key: str, ttl_hours: int = 24):
    """Cache les résultats d'API"""
    cache_file = f"{CACHE_DIR}/{key}.json"
    
    # Vérifier cache
    if os.path.exists(cache_file):
        with open(cache_file) as f:
            data = json.load(f)
        if datetime.fromisoformat(data["cached_at"]) + timedelta(hours=ttl_hours) > datetime.now():
            return data["result"]
    
    return None

def save_cache(key: str, result: dict):
    """Sauvegarde dans le cache"""
    cache_file = f"{CACHE_DIR}/{key}.json"
    with open(cache_file, "w") as f:
        json.dump({"cached_at": datetime.now().isoformat(), "result": result}, f)
```

### Astuce 3: Rate Limiting Intelligent

```python
import time
from functools import wraps

def rate_limited(max_per_minute: int):
    """Décorateur pour limiter les appels"""
    min_interval = 60.0 / max_per_minute
    last_call = [0.0]
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            elapsed = time.time() - last_call[0]
            if elapsed < min_interval:
                time.sleep(min_interval - elapsed)
            last_call[0] = time.time()
            return func(*args, **kwargs)
        return wrapper
    return decorator

@rate_limited(max_per_minute=10)
def api_call():
    """Appel API limité à 10/minute"""
    pass
```

---

## 📊 RÉCAPITULATIF BUDGET 0€

| Catégorie | Outil | Coût |
|-----------|-------|------|
| **Recherche entreprises** | APIs publiques | 0€ |
| **Recherche web** | DuckDuckGo | 0€ |
| **Veille M&A** | RSS + Alerts | 0€ |
| **Données financières** | INPI + APIs | 0€ |
| **IA/LLM** | Ollama local | 0€ |
| **Email** | Gmail API | 0€ |
| **Stockage** | Drive 15GB | 0€ |
| **Workflows** | n8n self-hosted | 0€ |
| **Base de données** | Supabase 500MB | 0€ |

**Total mensuel: 0€**

---

*Largo 2.0 — Free Tools Directory*
