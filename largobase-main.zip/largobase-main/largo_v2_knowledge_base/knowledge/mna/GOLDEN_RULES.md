# GOLDEN RULES — Règles d'Or M&A France

> **Version**: 2.0 — Principes Fondamentaux  
> **Last Updated**: 2026-03-18

---

## 🏆 LES 10 RÈGLES D'OR

### RÈGLE 1: La Confiance est la Base

```
❌ Ne jamais cacher d'information matérielle
✅ Transparence totale dès le début
✅ Documenter toutes les communications

Pourquoi:
- Un passif caché = procès + réputation détruite
- La confiance perdue ne se reconstruit pas
- Les acquéreurs professionnels détectent les omissions
```

### RÈGLE 2: Le Prix n'est pas Tout

```
❌ Se focaliser uniquement sur le prix
✅ Considérer la structure globale
✅ Évaluer les garanties, l'earn-out, la transition

Éléments clés:
├── Structure de paiement (cash, actions, différé)
├── Garanties (durée, plafond, seuil)
├── Earn-out (objectifs réalistes, gouvernance)
├── Transition (accompagnement, non-concurrence)
└── Fiscalité (optimisation, report)
```

### RÈGLE 3: La Due Diligence est Sacrée

```
❌ Sauter ou accélérer la DD
✅ Investir le temps nécessaire
✅ Faire appel à des experts

Checklist DD:
├── Financière (3 ans minimum)
├── Juridique (contrats, litiges, IP)
├── Commerciale (clients, marché, concurrence)
├── Sociale (effectifs, accords, syndicats)
├── Fiscale (impôts, contrôles, redressements)
├── Environnementale (permis, risques)
└── IT (systèmes, sécurité, data)
```

### RÈGLE 4: Les Synergies sont Surévaluées

```
❌ Compter 100% des synergies annoncées
✅ Appliquer un facteur de réduction (30-50%)
✅ Valider la faisabilité opérationnelle

Types de synergies:
├── Coûts (réalistes à 70-80%)
│   ├── Redondances
│   ├── Achats groupés
│   └── Optimisations
└── Revenus (réalistes à 30-50%)
    ├── Cross-selling
    ├── Nouveaux marchés
    └── Pricing power
```

### RÈGLE 5: L'Intégration est aussi Importante que l'Acquisition

```
❌ Négliger la phase post-closing
✅ Préparer l'intégration dès la DD
✅ Communiquer rapidement et clairement

Plan d'intégration:
├── Jour J: Annonce, communication
├── Semaine 1: Réunions équipes, Q&A
├── Mois 1: Alignement process, systèmes
├── Mois 3: Premiers résultats, ajustements
└── Mois 6-12: Culture, synergies
```

### RÈGLE 6: Le Management est Clé

```
❌ Sous-estimer l'importance des dirigeants
✅ Évaluer la qualité de l'équipe
✅ Prévoir un plan de transition

Évaluation management:
├── Compétences techniques
├── Leadership et vision
├── Connaissance du marché
├── Relations clients/fournisseurs
└── Motivation post-acquisition
```

### RÈGLE 7: La Concentration Client est un Risque Majeur

```
❌ Ignorer la dépendance à un client
✅ Analyser la répartition du CA
✅ Sécuriser les contrats clés

Seuils d'alerte:
🔴 Client unique > 30% du CA = RISQUE MAJEUR
🟡 Top 3 clients > 50% du CA = RISQUE ÉLEVÉ
🟢 Top 5 clients < 50% du CA = ACCEPTABLE

Actions:
├── Diversification active
├── Contrats cadres long terme
├── Réduction prix = augmentation dépendance
└── Clauses de non-concurrence
```

### RÈGLE 8: Le BFR est Souvent Sous-estimé

```
❌ Négliger l'impact du BFR
✅ Analyser la saisonnalité
✅ Prévoir les besoins de financement

Calcul BFR:
BFR = Actif circulant d'exploitation - Passif circulant d'exploitation
    = (Stocks + Créances clients) - (Dettes fournisseurs + Dettes fiscales/social)

Impact acquisition:
├── BFR négatif = Génération de cash
├── BFR positif = Besoin de financement
└── Variation BFR = Ajustement prix
```

### RÈGLE 9: La Fiscalité peut Tout Changer

```
❌ Négliger l'optimisation fiscale
✅ Structurer l'opération en amont
✅ Consulter des experts fiscaux

Optimisations possibles:
├── Régime holding (exonération PV)
├── Déduction intérêts (LBO)
├── Amortissement goodwill
├── Report déficits
└── CIR, CICE, JEI
```

### RÈGLE 10: Le Timing est Essentiel

```
❌ Se précipiter ou trop attendre
✅ Identifier le bon moment
✅ Préparer l'entreprise

Facteurs de timing:
├── Cycle économique
├── Cycle sectoriel
├── Cycle entreprise (croissance, maturité)
├── Cycle de vie dirigeant
├── Contexte fiscal
└── Disponibilité financements
```

---

## ⚠️ CAVEATS — Points de Vigilance

### Caveat 1: Les Projections sont des Hypothèses

```
❌ "Le business plan est garanti"
✅ "Le business plan repose sur des hypothèses"

Analyse des hypothèses:
├── Réalisme du marché adressable
├── Compétition future
├── Capacité d'exécution
├── Dépendance à des facteurs externes
└── Scénarios de sensibilité
```

### Caveat 2: Les Audits ne Découvrent pas Tout

```
❌ "La DD est exhaustive"
✅ "La DD réduit les risques, ne les élimine pas"

Limites DD:
├── Passif caché (contentieux futurs)
├── Dégradation post-closing
├── Fraude non détectée
├── Changement réglementaire
└── Perte clients clés

Protection:
├── Garanties étendues
├── Retention price (10-20%)
├── Assurance warranty & indemnity
└── Clauses de price adjustment
```

### Caveat 3: Les Émotions Faussent le Jugement

```
❌ "J'ai un bon feeling"
✅ "Les données confirment l'intuition"

Biais cognitifs:
├── Confirmation (chercher preuves positives)
├── Ancrage (prix initial comme référence)
├── Surconfiance (surestimer ses capacités)
├── Peur de manquer (FOMO)
└── Endowment effect (surestimer ce qu'on possède)

Contre-mesures:
├── Process structuré
├── Comité d'investissement
├── Due diligence indépendante
├── Délai de réflexion
└── Devil's advocate
```

### Caveat 4: La Culture d'Entreprise est Sous-estimée

```
❌ "Les synergies sont uniquement financières"
✅ "80% des échecs M&A sont culturels"

Éléments culturels:
├── Valeurs et mission
├── Style de management
├── Processus décisionnaires
├── Communication interne
├── Rémunération et motivation
└── Relations sociales

Évaluation:
├── Interviews management
├── Survey employés
├── Analyse turnover
├── Revue documents internes
└── Observation réunions
```

### Caveat 5: Les Coûts Cachés existent Toujours

```
❌ "Le prix d'acquisition est le coût total"
✅ "Le coût total = Prix + Intégration + Opportunité"

Coûts additionnels:
├── Frais de transaction (2-5% du prix)
│   ├── Conseil financier
│   ├── Avocats
│   ├── Due diligence
│   └── Notaires
├── Coûts d'intégration (5-15% du prix)
│   ├── Systèmes IT
│   ├── Formation
│   ├── Communication
│   └── Redondances
└── Coût d'opportunité
    └── Capital engagé ailleurs
```

---

## 📋 CHECKLIST PRÉ-ACQUISITION

### Phase 1: Stratégie (Mois -6)

- [ ] Alignement stratégique validé
- [ ] Budget acquisition approuvé
- [ ] Équipe projet désignée
- [ ] Conseils externes sélectionnés
- [ ] Critères de cible définis

### Phase 2: Cible (Mois -4)

- [ ] Liste cibles établie
- [ ] Premiers contacts réalisés
- [ ] Teaser envoyé (si cédant)
- [ ] NDA signé
- [ ] IM reçu/analysé

### Phase 3: Offre (Mois -3)

- [ ] LOI rédigée
- [ ] Prix indicatif calculé
- [ ] Structure proposée
- [ ] Exclusivité négociée
- [ ] Calendrier convenu

### Phase 4: Due Diligence (Mois -2 à -1)

- [ ] DD financière complète
- [ ] DD juridique complète
- [ ] DD commerciale complète
- [ ] DD sociale complète
- [ ] DD fiscale complète
- [ ] Rapports DD reçus
- [ ] Issues identifiées et quantifiées

### Phase 5: Négociation (Mois -1)

- [ ] Prix final négocié
- [ ] Garanties définies
- [ ] Earn-out structuré (si applicable)
- [ ] SPA rédigé
- [ ] Pacte d'actionnaires rédigé

### Phase 6: Closing (Mois 0)

- [ ] Conditions suspensives levées
- [ ] Financement confirmé
- [ ] Autorisations réglementaires obtenues
- [ ] Documents signés
- [ ] Paiement effectué

---

## 🔢 MULTIPLES SECTORIELS — RÈGLES PRATIQUES

### Fourchettes 2024 (Small-Mid Cap France)

| Secteur | EV/EBITDA | Règle d'Or |
|---------|-----------|------------|
| **Industrie** | 4.5x - 6.5x | Capex élevé = multiple bas |
| **Services** | 5.0x - 8.0x | Récurrent = premium |
| **Tech/SaaS** | 6.0x - 15.0x | Growth > 30% = premium |
| **Distribution** | 4.0x - 6.0x | Marge faible = multiple bas |
| **BTP** | 3.5x - 5.5x | Risque élevé = multiple bas |
| **Santé** | 5.5x - 8.0x | Réglementé = stabilité |
| **Tourisme** | 5.0x - 8.0x | Saisonnalité = risque |

### Ajustements

| Facteur | Impact | Application |
|---------|--------|-------------|
| **Croissance > 20%/an** | +0.5x à +1.5x | Vérifier durabilité |
| **Marge > 20%** | +0.5x à +1.0x | Benchmark sectoriel |
| **Client unique > 30%** | -0.5x à -1.5x | Risque majeur |
| **Dette/EBITDA > 3x** | -0.5x à -1.0x | Risque financier |
| **Management faible** | -0.5x à -1.0x | Risque exécution |

---

*Largo 2.0 — Golden Rules M&A France*
