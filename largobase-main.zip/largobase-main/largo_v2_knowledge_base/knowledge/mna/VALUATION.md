# VALORISATION M&A — Guide Complet

> **Version**: 2.0 — Méthodes de valorisation pour Small-Mid Cap France  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce document définit les méthodes de valorisation utilisées par Largo pour évaluer des entreprises dans le cadre de transactions M&A en France.

### Approche Largo

1. **Multiples sectoriels** — Méthode privilégiée pour small-mid cap
2. **DCF simplifié** — Si projections fiables disponibles
3. **Actif net corrigé** — Pour holdings ou situations spécifiques
4. **Fourchette indicative** — Toujours donner une fourchette, jamais un prix fixe

---

## 📊 MULTIPLES SECTORIELS

### Tableau Récapitulatif

| Secteur | Code NAF | EV/EBITDA | EV/EBE | EV/CA | Remarques |
|---------|----------|-----------|--------|-------|-----------|
| **Industrie générale** | 10-33 | 4.5x - 6.5x | 5.0x - 7.0x | 0.8x - 1.5x | Dépend capex |
| **Industrie alimentaire** | 10-11 | 5.0x - 7.0x | 5.5x - 7.5x | 0.6x - 1.2x | Marque = premium |
| **Services informatique** | 62 | 6.0x - 9.0x | 7.0x - 11.0x | 1.0x - 2.0x | SaaS = premium |
| **Services conseil** | 70-71 | 5.0x - 8.0x | 6.0x - 10.0x | 0.8x - 1.5x | Dépend récurrence |
| **Distribution alimentaire** | 47.11 | 4.0x - 6.0x | 4.5x - 6.5x | 0.15x - 0.30x | Faible marge |
| **Distribution spécialisée** | 47.4-47.7 | 4.5x - 6.5x | 5.0x - 7.0x | 0.4x - 0.8x | |
| **BTP Gros œuvre** | 41-42 | 3.5x - 5.0x | 4.0x - 5.5x | 0.15x - 0.25x | Risque élevé |
| **BTP Second œuvre** | 43 | 4.0x - 5.5x | 4.5x - 6.0x | 0.20x - 0.35x | |
| **Hôtellerie** | 55 | 5.0x - 7.0x | 6.0x - 8.0x | 1.5x - 3.0x | Localisation clé |
| **Restauration** | 56 | 4.0x - 6.0x | 4.5x - 6.5x | 0.5x - 1.0x | |
| **Transport** | 49 | 4.0x - 5.5x | 4.5x - 6.0x | 0.4x - 0.7x | |
| **Logistique** | 52 | 4.5x - 6.0x | 5.0x - 6.5x | 0.5x - 0.8x | |
| **Santé humaine** | 86-87 | 5.5x - 8.0x | 6.5x - 10.0x | 0.8x - 1.5x | |
| **Édition / Média** | 58-60 | 4.5x - 6.5x | 5.0x - 7.5x | 0.8x - 1.5x | Transition digitale |
| **Immobilier** | 68 | 8.0x - 12.0x | 10.0x - 15.0x | 2.0x - 4.0x | Patrimoine |

### Ajustements de Multiple

#### Facteurs Augmentant le Multiple (+0.5x à +2.0x)

| Facteur | Impact | Justification |
|---------|--------|---------------|
| Croissance CA > 15%/an | +0.5x à +1.0x | Premium croissance |
| EBITDA margin > 20% | +0.5x à +1.0x | Qualité de profit |
| Clientèle récurrente | +0.5x | Visibilité |
| Barrières à l'entrée | +0.5x à +1.0x | Positionnement |
| Management fort | +0.5x | Facteur humain |
| Marque reconnue | +0.5x à +1.0x | Intangible |
| Diversification clients | +0.5x | Réduction risque |

#### Facteurs Diminuant le Multiple (-0.5x à -2.0x)

| Facteur | Impact | Justification |
|---------|--------|---------------|
| Dépendance client unique > 30% | -0.5x à -1.0x | Risque client |
| Dette nette / EBITDA > 3x | -0.5x à -1.0x | Risque financier |
| BFR négatif structurel | -0.5x | Besoin de financement |
| Contentieux majeur | -0.5x à -1.5x | Risque juridique |
| Dépendance dirigeant | -0.5x à -1.0x | Risque clé homme |
| Marché en déclin | -0.5x à -1.0x | Risque sectoriel |

---

## 🧮 MÉTHODE DES MULTIPLES

### Formule

```
Enterprise Value (EV) = EBITDA × Multiple

Equity Value = EV - Dette Nette

Dette Nette = Dettes financières - Trésorerie
```

### Calcul EBE/EBITDA

```
EBE (Excédent Brut d'Exploitation) =
  Valeur Ajoutée
  - Charges de personnel
  - Impôts et taxes
  = EBITDA en France

EBITDA =
  Résultat d'exploitation (EBIT)
  + Dotations aux amortissements
  + Dotations aux provisions
```

### Script Valorisation (Largo)

```python
from scripts.mna.valuation import ValuationEngine

# Initialiser moteur
engine = ValuationEngine()

# Valorisation par multiples
valuation = engine.valuate_by_multiples(
    ebitda=500000,  # 500k€
    sector="services_informatique",
    adjustments={
        "growth_rate": 0.15,      # +15%/an
        "margin": 0.22,           # 22% EBITDA margin
        "client_concentration": 0.25,  # Top client = 25%
        "debt_ebitda": 1.5        # Dette/EBITDA = 1.5x
    }
)

# Résultat
print(f"Fourchette: {valuation['range_low']}€ - {valuation['range_high']}€")
print(f"Multiple appliqué: {valuation['multiple_applied']}x")
print(f"Hypothèses: {valuation['assumptions']}")
```

---

## 💰 MÉTHODE DCF (DISCOUNTED CASH FLOW)

### Quand l'utiliser ?

✅ Projections fiables (3-5 ans)  
✅ Business model stable  
✅ Données historiques disponibles  

### Formule

```
Enterprise Value = Σ (FCF_t / (1 + WACC)^t) + Terminal Value / (1 + WACC)^n

Où:
- FCF_t = Free Cash Flow année t
- WACC = Weighted Average Cost of Capital
- Terminal Value = FCF_n × (1 + g) / (WACC - g)
- g = taux de croissance perpétuelle (2-3%)
```

### WACC Typique Small-Mid Cap France

| Composant | Valeur |
|-----------|--------|
| Coût des fonds propres (Ke) | 12-18% |
| Coût de la dette (Kd) | 4-6% |
| Taux d'imposition | 25% |
| Structure cible (D/V) | 30-50% |
| **WACC** | **10-14%** |

### Script DCF (Largo)

```python
from scripts.mna.valuation import DCFValuation

# Projections FCF
projections = {
    "year_1": {"revenue": 5000000, "ebitda_margin": 0.15, "capex": 200000},
    "year_2": {"revenue": 5750000, "ebitda_margin": 0.16, "capex": 250000},
    "year_3": {"revenue": 6500000, "ebitda_margin": 0.17, "capex": 300000},
    "year_4": {"revenue": 7150000, "ebitda_margin": 0.17, "capex": 300000},
    "year_5": {"revenue": 7800000, "ebitda_margin": 0.18, "capex": 350000},
}

dcf = DCFValuation(
    projections=projections,
    wacc=0.12,           # 12%
    terminal_growth=0.025,  # 2.5%
    net_debt=800000      # 800k€
)

result = dcf.calculate()
print(f"Enterprise Value: {result['ev']}€")
print(f"Equity Value: {result['equity_value']}€")
print(f"Sensibilité: {result['sensitivity']}")
```

---

## 📊 ACTIF NET CORRIGÉ

### Quand l'utiliser ?

✅ Holdings patrimoniales  
✅ Sociétés d'investissement  
✅ Actifs immobiliers importants  
✅ Liquidation  

### Formule

```
Actif Net Corrigé =
  Actif réévalué
  - Passif exigible
  - Provisions risques
  ± Ajustements
```

### Ajustements Courants

| Élément | Ajustement |
|---------|------------|
| Immobilier | Réévaluation au marché |
| Stocks | Vérification obsolescence |
| Créances | Provision débiteurs douteux |
| Participations | Valorisation sous-jacent |
| Dettes fiscales | Provision redressement |

---

## 📈 FOURCHETTES DE VALORISATION

### Par Taille d'Entreprise

| CA | Fourchette Multiple | Remarques |
|----|---------------------|-----------|
| < 1M€ | 3.0x - 5.0x EBE | Micro-entreprise, risque élevé |
| 1M€ - 5M€ | 4.0x - 6.5x EBE | Small cap, standard |
| 5M€ - 15M€ | 5.0x - 7.5x EBE | Mid cap, premium qualité |
| 15M€ - 50M€ | 5.5x - 8.0x EBE | Upper mid cap, premium |

### Par Type d'Investisseur

| Acquéreur | Multiple Typique | Motivation |
|-----------|------------------|------------|
| **Stratégique** | +0.5x à +1.5x | Synergies opérationnelles |
| **Financier (LBO)** | Marché | Retour investissement |
| **Management (MBO)** | -0.5x à -1.0x | Financement limité |
| **Family Office** | Marché | Diversification |

---

## 🔧 OUTILS LARGO

### Calculatrice Valorisation

```bash
# Valorisation rapide
python3 scripts/mna/valuation.py --ebitda 500000 --sector services --pretty

# Fourchette
python3 scripts/mna/valuation.py --ebitda 500000 --multiple-range 5-7 --pretty

# DCF
python3 scripts/mna/valuation.py --dcf --projections projections.json --wacc 0.12 --pretty
```

### Génération Rapport

```python
from scripts.mna.valuation import generate_valuation_report

report = generate_valuation_report(
    company_name="Société X",
    siren="123456789",
    ebitda=500000,
    sector="services",
    output_format="pptx",
    output_path="/tmp/valuation_report.pptx"
)
```

---

## 📚 RÉFÉRENCES

- [MULTIPLES.md](MULTIPLES.md) — Multiples sectoriels détaillés
- [FRAMEWORK.md](FRAMEWORK.md) — Processus M&A
- [DUE_DILIGENCE.md](DUE_DILIGENCE.md) — Due diligence

---

*Largo 2.0 — Valorisation M&A France*
