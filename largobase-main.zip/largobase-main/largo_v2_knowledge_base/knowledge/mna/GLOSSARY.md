# GLOSSAIRE M&A — Terminologie Française

> **Version**: 2.0 — Lexique M&A France  
> **Last Updated**: 2026-03-18

---

## 📖 A

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Actif net comptable** | Total actif - Total passif | Net book value |
| **Actif net corrigé** | Actif net comptable réévalué | Adjusted net asset value |
| **Apport en nature** | Contribution en biens (pas cash) | Contribution in kind |
| **Apport partiel d'actif (APA)** | Transfert branche d'activité | Partial business transfer |
| **Asset deal** | Acquisition d'actifs (pas actions) | Asset purchase |

## 📖 B

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Back-stop** | Engagement ferme d'achat | Firm commitment |
| **BFR (Besoin en Fonds de Roulement)** | Actif circulant - Passif circulant | Working capital |
| **Bilan** | État patrimonial | Balance sheet |
| **Blind pool** | Fonds sans cible identifiée | Blind pool |
| **Break-up fee** | Indemnité de rupture | Termination fee |
| **Burn rate** | Taux de consommation cash | Burn rate |
| **Business plan** | Plan de développement | Business plan |

## 📖 C

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **CAB (Corporate Advisory Board)** | Conseil en stratégie | Advisory board |
| **CAPEX** | Dépenses en capital | Capital expenditure |
| **Capital-investissement** | Private equity | Private equity |
| **Cash flow** | Flux de trésorerie | Cash flow |
| **Cash-free / Debt-free** | Prix sans cash ni dette | Cash-free / Debt-free |
| **Cession** | Vente d'entreprise | Divestiture / Sale |
| **Classement** | Étoiles hôtellerie | Hotel rating |
| **Clause de non-concurrence** | Interdiction concurrence | Non-compete clause |
| **Closing** | Finalisation transaction | Closing |
| **Club deal** | LBO multi-investisseurs | Club deal |
| **Comparable** | Entreprise similaire | Comparable |
| **Compte de résultat** | État des résultats | Income statement |
| **Compte d'exploitation** | Résultat d'exploitation | Operating statement |
| **Confidentialité** | Secret des informations | Confidentiality |
| **Conglomérat** | Groupe diversifié | Conglomerate |
| **Consolidation** | Intégration comptable | Consolidation |
| **Contrôle** | Détention majoritaire | Control |
| **Corporate** | Grande entreprise | Corporate |
| **Cotation** | Cours en bourse | Listing |
| **Croissance externe** | Croissance par acquisition | External growth |
| **Croissance interne** | Croissance organique | Organic growth |

## 📖 D

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **DAP (Dotations aux Amortissements et Provisions)** | Charges non décaissées | Depreciation & provisions |
| **Data room** | Espace virtuel documents | Data room |
| **DCF (Discounted Cash Flow)** | Flux actualisés | DCF |
| **DD (Due Diligence)** | Audit pré-acquisition | Due diligence |
| **Deal** | Transaction | Deal |
| **Deal flow** | Flux d'opportunités | Deal flow |
| **Dette financière** | Emprunts | Financial debt |
| **Dette nette** | Dette - Trésorerie | Net debt |
| **Dilution** | Réduction participation | Dilution |
| **Dirigeant** | Exécutif | Executive |
| **Discount** | Réduction de prix | Discount |
| **Disruption** | Rupture technologique | Disruption |
| **Distribution** | Commerce de détail | Distribution |
| **Dividende** | Répartition bénéfice | Dividend |
| **Drag-along** | Droit d'entraînement | Drag-along right |
| **Due diligence** | Audit complet | Due diligence |

## 📖 E

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **EBE (Excédent Brut d'Exploitation)** | VA - Charges personnel - Impôts | Gross operating surplus |
| **EBIT** | Résultat d'exploitation | Operating profit |
| **EBITDA** | Résultat avant DAP | EBITDA |
| **EBITDA margin** | EBITDA / CA | EBITDA margin |
| **Échéancier** | Calendrier paiements | Payment schedule |
| **Économies d'échelle** | Réduction coûts volume | Economies of scale |
| **Émission** | Émission titres | Issuance |
| **Engagement** | Obligation contractuelle | Commitment |
| **Enterprise Value (EV)** | Valeur d'entreprise | Enterprise value |
| **EPS (Earnings Per Share)** | Résultat par action | EPS |
| **Equity** | Capitaux propres | Equity |
| **Equity Value** | Valeur des capitaux propres | Equity value |
| **ESG** | Environnement, Social, Gouvernance | ESG |
| **ETI (Entreprise de Taille Intermédiaire)** | 250-5000 salariés | Mid-cap |
| **EV/EBITDA** | Multiple valorisation | EV/EBITDA |
| **Exclusivité** | Pas de négociation tiers | Exclusivity |
| **Exit** | Sortie d'investissement | Exit |
| **Expertise** | Évaluation par expert | Appraisal |

## 📖 F

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Fairness opinion** | Opinion d'équité | Fairness opinion |
| **FCPR (Fonds Commun de Placement à Risques)** | Fonds capital-risque | VC fund |
| **FCPI (Fonds Commun de Placement dans l'Innovation)** | Fonds innovation | Innovation fund |
| **Fonds de roulement** | Ressources à court terme | Working capital |
| **Fonds propres** | Capital + Réserves | Shareholders' equity |
| **Forward** | Contrat à terme | Forward |
| **Franchise** | Réseau en franchise | Franchise |
| **Franchiseur** | Donneur de licence | Franchisor |
| **Franchisé** | Preneur de licence | Franchisee |
| **Fusion** | Union de sociétés | Merger |
| **Fusion-absorption** | Une société absorbée | Merger |
| **Fusion-croisement** | Nouvelle société | Cross-merger |

## 📖 G

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Goodwill** | Écart d'acquisition | Goodwill |
| **Gouvernance** | Organisation dirigeante | Governance |
| **Greenfield** | Investissement nouveau | Greenfield |
| **Groupe** | Ensemble sociétés | Group |
| **Growth** | Croissance | Growth |

## 📖 H

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Holding** | Société de participation | Holding company |
| **Hostile takeover** | OPA hostile | Hostile takeover |
| **Hurdle rate** | Taux de rentabilité minimum | Hurdle rate |

## 📖 I

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **IM (Information Memorandum)** | Document de présentation | Information memorandum |
| **Indemnité** | Compensation | Indemnity |
| **Intangible** | Actif incorporel | Intangible asset |
| **Intégration** | Fusion opérationnelle | Integration |
| **Intérêts** | Charges financières | Interest |
| **IRR (Internal Rate of Return)** | Taux de rentabilité interne | IRR |
| **IS (Impôt sur les Sociétés)** | Impôt sociétés | Corporate tax |

## 📖 J

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Joint-venture** | Coentreprise | Joint venture |
| **Junk bond** | Obligation à haut risque | Junk bond |

## 📖 K

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Kbis** | Extrait registre commerce | Company registration |

## 📖 L

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **LBO (Leveraged Buy-Out)** | Rachat endetté | LBO |
| **Levier** | Endettement | Leverage |
| **Leverage** | Ratio dette/fonds propres | Leverage |
| **Licence** | Autorisation d'exploitation | License |
| **Liquidation** | Cessation activité | Liquidation |
| **Liquidité** | Capacité à payer | Liquidity |
| **LLC** | Société à responsabilité limitée (US) | LLC |
| **Locked box** | Prix fixe à date de référence | Locked box |
| **LOI (Letter of Intent)** | Lettre d'intention | Letter of intent |

## 📖 M

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **M&A (Mergers & Acquisitions)** | Fusions et acquisitions | M&A |
| **Management** | Direction | Management |
| **Mandat** | Mission confiée | Mandate |
| **Marge brute** | CA - Coûts directs | Gross margin |
| **Marge nette** | Résultat net / CA | Net margin |
| **Market cap** | Capitalisation boursière | Market capitalization |
| **MBO (Management Buy-Out)** | Rachat par management | MBO |
| **MBI (Management Buy-In)** | Rachat avec nouveau management | MBI |
| **Mezzanine** | Dette subordonnée | Mezzanine debt |
| **Minoritaire** | Actionnaire non contrôlant | Minority shareholder |
| **Mixte** | Dette + Fonds propres | Mixed |
| **Multiple** | Ratio de valorisation | Multiple |

## 📖 N

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **NDA (Non-Disclosure Agreement)** | Accord confidentialité | NDA |
| **Net debt** | Dette - Cash | Net debt |
| **NOM (Nouvelles Orientations Managériales)** | Changement stratégie | Strategic shift |
| **NPV (Net Present Value)** | Valeur actuelle nette | NPV |

## 📖 O

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **OPA (Offre Publique d'Achat)** | Takeover bid | Takeover bid |
| **OPAS (Offre Publique d'Achat Simplifiée)** | OPA simplifiée | Simplified takeover bid |
| **OPRA (Offre Publique de Rachat d'Actions)** | Rachat actions | Share buyback |
| **Option** | Droit d'achat/vente | Option |
| **Ordre du jour** | Points à traiter | Agenda |

## 📖 P

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Pacte d'actionnaires** | Accord entre actionnaires | Shareholders' agreement |
| **Passif** | Dettes et capitaux | Liabilities |
| **Patrimoine** | Ensemble biens | Assets |
| **Payback** | Délai de récupération | Payback period |
| **PIPE (Private Investment in Public Equity)** | Investissement privé dans public | PIPE |
| **PME** | Petite et Moyenne Entreprise | SME |
| **Portage salarial** | Statut indépendant protégé | Portage |
| **Portefeuille** | Ensemble investissements | Portfolio |
| **Post-money** | Valorisation après investissement | Post-money |
| **Pre-money** | Valorisation avant investissement | Pre-money |
| **Préemption** | Droit de préférence | Preemption right |
| **Private equity** | Capital-investissement | Private equity |
| **Pro forma** | État prévisionnel | Pro forma |
| **Promesse de vente** | Engagement de vente | Promise to sell |

## 📖 Q

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Quorum** | Minimum présent pour valider | Quorum |

## 📖 R

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Rachat** | Achat d'entreprise | Buyout |
| **Ratchet** | Ajustement participation | Ratchet |
| **R&D** | Recherche et Développement | R&D |
| **Recurring revenue** | Revenu récurrent | Recurring revenue |
| **Restructuring** | Réorganisation | Restructuring |
| **ROE (Return on Equity)** | Rentabilité capitaux propres | ROE |
| **ROI (Return on Investment)** | Retour sur investissement | ROI |
| **Round** | Levée de fonds | Funding round |
| **Run rate** | Taux annualisé | Run rate |

## 📖 S

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **SaaS** | Software as a Service | SaaS |
| **SAS (Société par Actions Simplifiée)** | Forme société flexible | SAS |
| **SARL (Société à Responsabilité Limitée)** | Forme société classique | SARL |
| **Scission** | Division société | Spin-off |
| **Sectoriel** | Relatif à un secteur | Sector-specific |
| **Share deal** | Achat d'actions | Share purchase |
| **SIREN** | Numéro entreprise 9 chiffres | Business ID |
| **SIRET** | Numéro établissement 14 chiffres | Establishment ID |
| **SPA (Sale and Purchase Agreement)** | Contrat de vente | SPA |
| **Spin-off** | Scission | Spin-off |
| **Sponsor** | Investisseur principal | Sponsor |
| **Spread** | Écart prix | Spread |
| **Start-up** | Jeune entreprise innovante | Start-up |
| **Stock options** | Options sur actions | Stock options |
| **Stratégique** | Acquéreur industriel | Strategic buyer |
| **Subscription** | Souscription | Subscription |
| **Synergies** | Gains de combinaison | Synergies |

## 📖 T

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Tag-along** | Droit de sortie conjointe | Tag-along right |
| **Takeover** | Prise de contrôle | Takeover |
| **Target** | Entreprise cible | Target |
| **Teaser** | Document anonymisé | Teaser |
| **Ticket** | Montant investissement | Ticket size |
| **Tracking stock** | Action filiale cotée | Tracking stock |
| **Tranche** | Partie d'emprunt | Tranche |
| **Treasury** | Trésorerie | Treasury |
| **Turnaround** | Redressement | Turnaround |

## 📖 U

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Underwriting** | Garantie de placement | Underwriting |
| **Upside** | Potentiel de hausse | Upside |

## 📖 V

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **VA (Valeur Ajoutée)** | CA - Consommations | Value added |
| **Valorisation** | Évaluation entreprise | Valuation |
| **Vendor due diligence** | DD réalisée par vendeur | Vendor DD |
| **Vendor loan** | Prêt vendeur | Vendor loan |
| **Venture capital** | Capital-risque | Venture capital |
| **Vesting** | Acquisition progressive droits | Vesting |
| **Veto** | Droit de blocage | Veto right |

## 📖 W

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **WACC (Weighted Average Cost of Capital)** | Coût moyen pondéré du capital | WACC |
| **Warranties** | Garanties | Warranties |
| **Waterfall** | Répartition cash | Waterfall |
| **Working capital** | Fonds de roulement | Working capital |

## 📖 Y

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Yield** | Rendement | Yield |

## 📖 Z

| Terme | Définition | Équivalent Anglais |
|-------|------------|-------------------|
| **Zone franche** | Zone fiscalement avantageuse | Free zone |

---

*Largo 2.0 — Glossaire M&A France*
