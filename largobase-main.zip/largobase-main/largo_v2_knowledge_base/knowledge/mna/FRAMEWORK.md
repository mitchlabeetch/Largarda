# M&A FRAMEWORK — Méthodologie Fusion-Acquisition

> **Version**: 2.0 — Framework M&A pour Largo  
> **Zone**: France / Francophone  
> **Segment**: Small-Mid Cap (1-50M€ CA)  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce document définit la méthodologie M&A utilisée par Largo pour accompagner Christophe dans ses missions de conseil en fusion-acquisition.

### Spécialisation Alecia

| Paramètre | Valeur |
|-----------|--------|
| **Zone géographique** | France métropolitaine + DOM-TOM |
| **Langue** | Français (natif) |
| **Segment** | Small-Mid Cap |
| **CA cible** | 1M€ — 50M€ |
| **Position** | Cédants ET Investisseurs |
| **Secteurs** | Multi-sectoriel |

---

## 📊 PROCESSUS M&A

### Vue d'Ensemble des Phases

```
┌─────────────────────────────────────────────────────────────────┐
│                    PROCESSUS M&A COMPLET                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  PHASE 1          PHASE 2          PHASE 3          PHASE 4     │
│  APPROCHE   →    LOI/NDA    →     DUE DILIGENCE  →  CLOSING   │
│                                                                  │
│  • Cible          • Lettre        • Financière     • SPA       │
│  • Contact        • d'intention   • Juridique      • Closing   │
│  • Teaser         • NDA           • Commercial     • Intégration│
│                   • Exclusivité   • Social                      │
│                                                                  │
│  Durée: 2-4s    Durée: 4-8s     Durée: 4-12s    Durée: 2-4s   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## PHASE 1: APPROCHE

### 1.1 Identification des Cibles

**Pour Cédants**:
- Profil d'acquéreur idéal
- Stratégie de cible (stratégique, financier, management)
- Mapping des acquéreurs potentiels

**Pour Investisseurs**:
- Critères de cible (secteur, taille, localisation)
- Prospection active
- Deal sourcing

### 1.2 Documents Clés

| Document | Usage | Public |
|----------|-------|--------|
| **Teaser** | Première approche | Anonymisé |
| **IM (Information Memorandum)** | Process structuré | Court-liste |
| **Process Letter** | Modalités du process | Acquéreurs qualifiés |

### 1.3 Script Recherche Cibles (Largo)

```python
# Recherche par secteur + localisation
from scripts.mna.france_mna import FranceMNAResearcher

researcher = FranceMNAResearcher()

# Ex: Imprimeries dans les Alpes-Maritimes
results = researcher.search_by_naf_location(
    naf_code="1813Z",  # Imprimerie
    departement="06",   # Alpes-Maritimes
    min_ca=1000000,     # CA > 1M€
    max_ca=10000000     # CA < 10M€
)
```

---

## PHASE 2: LOI & NEGOCIATION

### 2.1 Lettre d'Intention (LOI)

**Contenu standard**:
- Prix indicatif (fourchette)
- Structure de transaction (cash, actions, earn-out)
- Conditions suspensives
- Exclusivité
- Calendrier

### 2.2 NDA (Non-Disclosure Agreement)

**Points clés**:
- Confidentialité stricte
- Durée (généralement 2-3 ans)
- Retour des documents
- Sanctions

### 2.3 Exclusivité

| Type | Durée | Usage |
|------|-------|-------|
| **Exclusivité totale** | 8-12 semaines | DD complète |
| **Exclusivité partielle** | 4-6 semaines | DD préliminaire |
| **No-shop** | 2-4 semaines | Négociation SPA |

---

## PHASE 3: DUE DILIGENCE

### 3.1 Types de DD

```
┌─────────────────────────────────────────────────────────────┐
│                    DUE DILIGENCE                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  FINANCIÈRE  │  │  JURIDIQUE   │  │  COMMERCIALE │      │
│  │              │  │              │  │              │      │
│  │ • Comptes    │  │ • Statuts    │  │ • Marché     │      │
│  │ • Audit      │  │ • Contrats   │  │ • Clients    │      │
│  │ • Trésorerie │  │ • Litiges    │  │ • Concurrence│      │
│  │ • Dettes     │  │ • IP         │  │ • Pipeline   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │    SOCIALE   │  │   FISCALE    │  │  ENVIRONNEMENT│      │
│  │              │  │              │  │              │      │
│  │ • Effectifs  │  │ • Impôts     │  │ • Réglement. │      │
│  │ • Rémunér.   │  │ • Redresse.  │  │ • Risques    │      │
│  │ • Accords    │  │ • TVA        │  │ • Audit      │      │
│  │ • Syndicats  │  │ • CICE       │  │ • Permis     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 DD Financière — Checklist

#### Comptes Annuel
- [ ] Bilans (N, N-1, N-2)
- [ ] Comptes de résultat
- [ ] Annexes
- [ ] Rapports des commissaires aux comptes

#### Analyse Financière
- [ ] Évolution CA
- [ ] Rentabilité (EBITDA, EBIT, RN)
- [ ] Besoin en fonds de roulement
- [ ] Trésorerie
- [ ] Dettes et engagements

#### Projections
- [ ] Business plan (3-5 ans)
- [ ] Hypothèses clés
- [ ] Sensibilités

### 3.3 DD Juridique — Checklist

#### Structure
- [ ] Kbis récent
- [ ] Statuts
- [ ] PV AGE/AGO (3 dernières années)
- [ ] Registre des actionnaires

#### Contrats
- [ ] Contrats clients majeurs
- [ ] Contrats fournisseurs
- [ ] Contrats de crédit-bail
- [ ] Contrats de travail dirigeants

#### Litiges
- [ ] Litiges en cours
- [ ] Procédures collectives
- [ ] Contentieux sociaux
- [ ] Contentieux fiscaux

### 3.4 DD Commerciale — Checklist

#### Marché
- [ ] Taille du marché (TAM/SAM/SOM)
- [ ] Tendances
- [ ] Réglementation sectorielle

#### Clients
- [ ] Top 10 clients (% CA)
- [ ] Concentration client
- [ ] Contrats cadres
- [ ] Satisfaction client

#### Concurrence
- [ ] Liste concurrents
- [ ] Positionnement
- [ ] Avantages concurrentiels

### 3.5 Script DD (Largo)

```python
from scripts.mna.due_diligence import DueDiligenceChecklist

dd = DueDiligenceChecklist(siren="123456789")

# Lancer DD complète
report = dd.run_full_dd(
    financial=True,
    legal=True,
    commercial=True,
    social=True
)

# Générer rapport
report.generate_pdf("/tmp/dd_report.pdf")
```

---

## PHASE 4: CLOSING

### 4.1 SPA (Sale and Purchase Agreement)

**Clauses clés**:
- Prix et ajustements
- Garanties (warranties)
- Indemnités
- Conditions suspensives
- Non-concurrence
- Confidentialité post-closing

### 4.2 Ajustements de Prix

| Type | Formule | Usage |
|------|---------|-------|
| **Cash-free / Debt-free** | Prix = EV - Dette nette | Standard LBO |
| **Locked box** | Prix fixe à date de référence | Deal rapide |
| **Completion accounts** | Ajustement post-closing | Deal complexe |

### 4.3 Garanties (Warranties)

**Catégories**:
- Capitalisation
- Comptes
- Juridique
- Fiscal
- Social
- Environnemental

**Limitations**:
- Plafond: 10-30% du prix
- Durée: 12-36 mois
- Seuil (basket): 0.5-1% du prix

---

## 📈 VALORISATION

### Méthodes de Valorisation

Voir [VALUATION.md](VALUATION.md) pour le détail complet.

| Méthode | Usage | Avantage |
|---------|-------|----------|
| **Multiples** | Small-mid cap | Simple, comparable |
| **DCF** | Projets fiables | Valeur intrinsèque |
| **Actif net** | Holdings | Valeur de liquidation |
| **Venture Capital** | Startups | Croissance future |

### Multiples Sectoriels France

| Secteur | EV/EBITDA | EV/EBE |
|---------|-----------|--------|
| Industrie | 4.5x - 6.5x | 5.0x - 7.0x |
| Services | 5.0x - 7.5x | 6.0x - 9.0x |
| Distribution | 4.0x - 6.0x | 4.5x - 6.5x |
| BTP | 3.5x - 5.5x | 4.0x - 6.0x |
| Tech/SaaS | 6.0x - 10.0x | 8.0x - 15.0x |
| Santé | 5.5x - 8.0x | 6.5x - 10.0x |

---

## 📋 DOCUMENTS M&A

### Documents par Phase

| Phase | Document | Template |
|-------|----------|----------|
| Approche | Teaser | [templates/docs/teaser.docx](templates/docs/teaser.docx) |
| Approche | IM | [templates/docs/im_template.docx](templates/docs/im_template.docx) |
| LOI | Lettre d'intention | [templates/docs/loi_template.docx](templates/docs/loi_template.docx) |
| NDA | Accord confidentialité | [templates/docs/nda_template.docx](templates/docs/nda_template.docx) |
| DD | Checklist DD | [templates/excel/dd_checklist.xlsx](templates/excel/dd_checklist.xlsx) |
| Closing | SPA | (Externe — cabinet juridique) |

### Génération Documents (Largo)

```python
from scripts.documents.pptx_generator import generate_teaser
from scripts.documents.word_generator import generate_loi

# Générer Teaser
generate_teaser(
    company_data={...},
    anonymized=True,
    output="/tmp/teaser.pptx"
)

# Générer LOI
generate_loi(
    buyer="Acquéreur SA",
    target="Cible SARL",
    indicative_price="2.5M€ - 3.5M€",
    exclusivity_weeks=10,
    output="/tmp/loi.docx"
)
```

---

## 🔗 RÉFÉRENCES

- [RESEARCH.md](RESEARCH.md) — Recherche entreprises
- [VALUATION.md](VALUATION.md) — Valorisation
- [DUE_DILIGENCE.md](DUE_DILIGENCE.md) — Due diligence détaillée
- [PLAYBOOKS.md](PLAYBOOKS.md) — Playbooks par type de deal
- [MULTIPLES.md](MULTIPLES.md) — Multiples sectoriels

---

*Largo 2.0 — Framework M&A France Small-Mid Cap*
