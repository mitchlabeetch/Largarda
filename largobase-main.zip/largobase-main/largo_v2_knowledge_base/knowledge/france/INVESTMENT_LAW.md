# DROIT DES INVESTISSEMENTS & M&A — France

> **Version**: 2.0 — Cadre juridique M&A  
> **Juridiction**: France métropolitaine  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce document couvre le cadre juridique des opérations de fusion-acquisition en France : structures, contrats, réglementations sectorielles, et contrôle des concentrations.

---

## 📋 STRUCTURES JURIDIQUES D'ACQUISITION

### 1. Acquisition d'Actions

#### Achat d'Actions (Share Deal)

```
Avantages:
├── Continuité juridique (contrats, licences)
├── Pas de formalités spécifiques
└── Déduction déficits fiscaux

Inconvénients:
├── Reprise passif caché
├── Pas d'amortissement goodwill
└── Responsabilité successorale
```

#### Clause de Garantie (Warranties)

| Type de garantie | Durée | Plafond |
|------------------|-------|---------|
| **Capitalisation** | Illimitée | Prix d'achat |
| **Comptes** | 12-24 mois | 10-30% prix |
| **Juridique** | 12-36 mois | 10-30% prix |
| **Fiscal** | Jusqu'à prescription | 10-30% prix |
| **Environnemental** | 24-60 mois | 10-30% prix |

### 2. Acquisition d'Actifs (Asset Deal)

```
Avantages:
├── Pas de reprise passif
├── Amortissement goodwill
└── Sélection actifs

Inconvénients:
├── Formalités (transfert contrats, licences)
├── TVA (20%)
├── Droits d'enregistrement (5%)
└── Perte déficits fiscaux
```

### 3. Fusion (Merger)

```
Conditions:
├── Même forme juridique (généralement)
├── Approbation AGE des deux sociétés
└── Information salariés

Avantages fiscaux:
├── Exonération plus-values
├── Report déficits
└── Neutralité fiscale
```

### 4. Apport Partiel d'Actif (APA)

```
Caractéristiques:
├── Transfert branche d'activité
├── Conservation société cédante
└── Démembrement possible

Fiscalité:
├── Exonération plus-values si conditions
├── TVA selon cas
└── Droits d'enregistrement réduits
```

### 5. Scission (Spin-off)

```
Types:
├── Scission-absorption (une partie absorbée)
├── Scission-constitution (nouvelle société)
└── Scission-subsistance (société continue)

Fiscalité:
├── Neutralité si conditions remplies
└── Report déficits proportionnel
```

---

## 📄 CONTRATS M&A

### 1. Lettre d'Intention (LOI)

#### Contenu Standard

```
1. Objet de la transaction
2. Prix indicatif (fourchette)
3. Structure (cash, actions, earn-out)
4. Conditions suspensives
5. Exclusivité
6. Confidentialité
7. Calendrier
8. Engagement des parties
```

#### Clauses Clés

| Clause | Description | Durée |
|--------|-------------|-------|
| **Exclusivité** | Pas de négociation avec tiers | 8-12 semaines |
| **Confidentialité** | Secret des informations | 2-3 ans |
| **Break-up fee** | Indemnité rupture | 1-3% prix |
| **Good faith** | Négociation de bonne foi | - |

### 2. Contrat de Vente (SPA)

#### Structure Standard

```
1. Préambule (contexte)
2. Définitions
3. Objet de la vente
4. Prix et ajustements
5. Conditions suspensives
6. Garanties (warranties)
7. Indemnités
8. Clauses de non-concurrence
9. Confidentialité
10. Droit applicable et juridiction
```

#### Ajustements de Prix

| Type | Formule | Usage |
|------|---------|-------|
| **Cash-free / Debt-free** | Prix = EV - Dette nette | Standard |
| **Locked box** | Prix fixe à date de référence | Deal rapide |
| **Completion accounts** | Ajustement post-closing | Deal complexe |
| **Earn-out** | Prix lié à performance future | Incertitude |

#### Earn-out Structure

```
Exemple:
├── Prix de base: 10M€
├── Earn-out année 1: 20% de l'EBITDA > 2M€
├── Earn-out année 2: 20% de l'EBITDA > 2.2M€
├── Plafond total earn-out: 3M€
└── Gouvernance: Acquéreur contrôle, ancien dirigeant consultant
```

### 3. Accord de Confidentialité (NDA)

#### Types

| Type | Usage | Durée |
|------|-------|-------|
| **Unilatéral** | Vendeur divulgue | 2-3 ans |
| **Bilatéral** | Échange mutuel | 2-3 ans |
| **Multilatéral** | Plusieurs parties | 2-3 ans |

#### Clauses Clés

```
1. Définition informations confidentielles
2. Obligations du receveur
3. Exceptions (publiquement disponible)
4. Durée
5. Restitution documents
6. Sanctions
7. Droit applicable
```

### 4. Pacte d'Actionnaires

#### Contenu Standard

```
1. Gouvernance
   ├── Composition conseil
   ├── Droits de vote
   └── Quorums

2. Droits des actionnaires
   ├── Tag-along (sortie conjointe)
   ├── Drag-along (entraînement)
   ├── Préemption
   └── Droit d'information

3. Sortie
   ├── IPO
   ├── Vente à tiers
   └── Rachat

4. Clause de non-concurrence

5. Règlement des litiges
```

#### Tag-along vs Drag-along

| Clause | Déclencheur | Effet |
|--------|-------------|-------|
| **Tag-along** | Majoritaire vend | Minoritaires peuvent vendre |
| **Drag-along** | Majoritaire vend | Minoritaires doivent vendre |

---

## ⚖️ CONTRÔLE DES CONCENTRATIONS

### Seuils de Déclaration

| Seuil | Condition | Obligation |
|-------|-----------|------------|
| **150M€** | CA mondial cumulé | Déclaration obligatoire |
| **150M€ FR** | CA France cumulé | Déclaration obligatoire |
| **2x 50M€** | 2 parties > 50M€ en FR | Autorisation préalable |

### Procédure

```
Étapes:
1. Notification à l'Autorité de la Concurrence
2. Phase I (25 jours ouvrables)
   ├── Autorisation
   ├── Engagements
   └── Phase II
3. Phase II (65 jours ouvrables)
   ├── Autorisation avec engagements
   └── Interdiction
```

### Engagements Possibles

| Type | Description |
|------|-------------|
| **Cessions d'actifs** | Vente filiales, marques |
| **Licences** | Accès propriété intellectuelle |
| **Non-discrimination** | Conditions égales pour tous |
| **Transparence** | Publication tarifs, conditions |

---

## 🏛️ RÉGLEMENTATIONS SECTORIELLES

### 1. Secteur Bancaire (ACPR)

| Opération | Autorisation |
|-----------|--------------|
| Acquisition > 10% | ACPR |
| Acquisition > 20% | ACPR + ECB |
| Contrôle | ACPR + ECB + CE |

### 2. Secteur Assurance (ACPR)

| Opération | Autorisation |
|-----------|--------------|
| Acquisition > 10% | ACPR |
| Contrôle | ACPR + CE |

### 3. Secteur de la Santé (ANSM, ARS)

| Opération | Autorisation |
|-----------|--------------|
| Clinique | ARS |
| Laboratoire | ANSM |
| EHPAD | ARS |

### 4. Secteur de l'Énergie (CRE)

| Opération | Autorisation |
|-----------|--------------|
| Production > 100MW | Ministère |
| Réseaux | CRE |

### 5. Secteur des Télécoms (ARCEP)

| Opération | Autorisation |
|-----------|--------------|
| Fréquences | ARCEP |
| Contrôle | ARCEP + Autorité Concurrence |

### 6. Secteur de la Défense (DGA, DGSI)

| Opération | Autorisation |
|-----------|--------------|
| Contrôle | DGA (vigilance) |
| Technologies sensibles | DGSI |

---

## 🌐 INVESTISSEMENTS ÉTRANGERS

### Contrôle des Investissements Étrangers (CIE)

#### Secteurs Sensibles

| Secteur | Seuil |
|---------|-------|
| **Infrastructure critique** | 10% |
| **Technologies sensibles** | 10% |
| **Défense** | Tout seuil |
| **Recherche/Énergie** | 25% |

#### Procédure

```
1. Déclaration au Ministère de l'Économie
2. Examen (30 jours)
3. Décision:
   ├── Autorisation
   ├── Autorisation avec conditions
   └── Opposition
```

#### Pays Concernés

| Statut | Pays |
|--------|------|
| **UE/EEE** | Exempté |
| **Autres** | Soumis à déclaration |

---

## 📋 FORMALITÉS POST-ACQUISITION

### 1. Publication

| Formalité | Délai | Support |
|-----------|-------|---------|
| **BODACC** | 1 mois | Bulletin officiel |
| **RCS** | 1 mois | Registre du commerce |
| **Journal d'annonces légales** | 1 mois | JAL local |

### 2. Information

| Destinataire | Délai | Contenu |
|--------------|-------|---------|
| **Salariés** | Immédiat | Changement contrôle |
| **Clients** | Selon contrats | Notification |
| **Fournisseurs** | Selon contrats | Notification |
| **Banques** | Immédiat | Nouveaux signataires |

### 3. Transferts

| Élément | Formalité |
|---------|-----------|
| **Contrats** | Notification cessionnaire |
| **Licences** | Accord autorité |
| **Brevets** | INPI |
| **Marques** | INPI |
| **Immobilier** | Conservation hypothèques |

---

## 🔗 RÉFÉRENCES LÉGALES

### Codes Applicables

| Code | Articles | Usage |
|------|----------|-------|
| **Code civil** | 1101 et s. | Contrats |
| **Code de commerce** | L225-1 et s. | Sociétés |
| **Code monétaire** | L511-1 et s. | Bancaire |
| **Code des assurances** | L310-1 et s. | Assurance |
| **Code de la défense** | L2331-1 et s. | Défense |

### Autorités

| Autorité | Rôle | Contact |
|----------|------|---------|
| **Autorité de la Concurrence** | Contrôle concentrations | www.autoritedelaconcurrence.fr |
| **AMF** | Marchés financiers | www.amf-france.org |
| **ACPR** | Banque/Assurance | www.acpr.banque-france.fr |
| **Ministère Économie** | CIE | www.tresor.economie.gouv.fr |

---

*Largo 2.0 — Droit des Investissements M&A*
