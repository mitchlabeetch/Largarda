# FISCALITÉ M&A — France

> **Version**: 2.0 — Cadre fiscal des opérations M&A  
> **Juridiction**: France métropolitaine  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce document couvre l'ensemble des aspects fiscaux des opérations de fusion-acquisition en France : plus-values, structuration, optimisation, et reporting.

---

## 💰 PLUS-VALUES DE CESSION

### 1. Régime Général

#### Plus-Values Professionnelles (Article 39 du CGI)

| Situation | Taux | Conditions |
|-----------|------|------------|
| **Plus-value à court terme** | 12.8% IR + 17.2% PS | < 2 ans de détention |
| **Plus-value à long terme** | 12.8% IR + 17.2% PS | > 2 ans de détention |
| **Abattement durée** | 50% à 85% | > 2 ans, < 8 ans |

#### Calcul Abattement Durée

```
Détention 2-4 ans:  50% abattement
Détention 4-6 ans:  65% abattement
Détention 6-8 ans:  85% abattement
Détention > 8 ans:  Exonération 100%
```

### 2. Régime des Holdings (Article 151-8 du CGI)

#### Conditions d'Application

```
1. Société détenue > 2 ans
2. Participation > 25% des droits de vote
3. Activité commerciale/industrielle
4. Société holding détient > 5% de la filiale
```

#### Avantages

| Avantage | Description |
|----------|-------------|
| **Exonération PV** | 100% exonéré si conditions |
| **Déduction frais** | Frais de cession déductibles |
| **Report déficits** | Conservation déficits filiale |

### 3. Régime du Porteur de Parts (Flat Tax)

#### Taux Forfaitaire

| Élément | Taux |
|---------|------|
| **Prélèvement forfaitaire unique (PFU)** | 30% (12.8% IR + 17.2% PS) |
| **Option barème progressif** | Selon tranche |

#### Option au Barème

```
Avantages option barème:
├── Abattement 40% (parts sociales > 3 ans)
├── Déduction CSG (6.8%)
└── Quotient familial
```

### 4. Plus-Values Immobilières

| Situation | Taux | Abattement |
|-----------|------|------------|
| **Plus-value immobilière** | 19% IR + 17.2% PS | 10%/an après 5 ans |
| **Exonération** | 0% | > 22 ans (IR), > 30 ans (PS) |

---

## 🏢 IMPÔT SUR LES SOCIÉTÉS (IS)

### Taux d'Imposition

| Tranche | Taux | Plafond |
|---------|------|---------|
| **IS réduit** | 15% | 42,500€ de bénéfices |
| **IS normal** | 25% | Au-delà |

### Déduction des Charges Financières

#### Règle des Thin Capitalization

```
Déduction intérêts limitée à:
├── 25% de l'EBITDA fiscal
├── Ou montant des intérêts perçus × 1.25
└── Plafond global
```

#### Règle Anti-Hybrid (ATAD)

```
Non-déduction si:
├── Revenus non imposables dans l'État du bénéficiaire
└── Ou déduction double (pays du débiteur et du bénéficiaire)
```

### Amortissement Goodwill

| Méthode | Durée | Usage |
|---------|-------|-------|
| **Amortissement linéaire** | 5-20 ans | Asset deal |
| **Amortissement dégressif** | 5-10 ans | Biens corporels |

---

## 🎯 STRUCTURATION FISCALE

### 1. LBO (Leveraged Buy-Out)

#### Structure Type

```
HoldCo (Holding de financement)
├── Dette senior (banques)
├── Dette mezzanine (fonds)
└── Fonds propres (sponsors)
    └──
        OpCo (Opérationnelle)
        └── Cible
```

#### Avantages Fiscaux

| Avantage | Mécanisme | Économie |
|----------|-----------|----------|
| **Déduction intérêts** | Charges financières | 25% de la dette |
| **Amortissement goodwill** | Sur 5-20 ans | Réduction IS |
| **Déficit reportable** | Jusqu'à -1M€ | Économie IS |

#### Règles Anti-Abus

```
Conditions pour déduction intérêts:
├── Taux d'intérêt = marché
├── Dette remboursable en 5-7 ans
├── Ratio dette/EBITDA < 6x
└── Pas de recharche (back-to-back)
```

### 2. Holding de Participation

#### Structure

```
Holding (SAS/SASU)
├── Détention participations
├── Centralisation trésorerie
└── Gestion participations
```

#### Régime des Mères-Filles

| Condition | Application |
|-----------|-------------|
| **Détention** | > 5% du capital |
| **Durée** | > 2 ans (engagement) |
| **Exonération** | 95% des dividendes |
| **Frais** | 5% forfaitaire |

### 3. Apport Partiel d'Actif (APA)

#### Fiscalité

| Élément | Traitement |
|---------|------------|
| **Plus-value** | Exonérée si conditions |
| **TVA** | Exonérée (transfert universel) |
| **Droits d'enregistrement** | 0.715% (branche complète) |

#### Conditions d'Exonération

```
1. Apport branche complète d'activité
2. Conservation 3 ans
3. Maintien emplois 3 ans
4. Société bénéficiaire soumise à IS
```

### 4. Fusion-Absorption

#### Neutralité Fiscale

| Élément | Traitement |
|---------|------------|
| **Plus-value** | Reportée |
| **Déficits** | Reportés (sous conditions) |
| **Amortissements** | Continuité |

#### Conditions

```
1. Même forme juridique (généralement)
2. Apport universel de patrimoine
3. Attribution actions société absorbante
4. Information salariés
```

---

## 📊 OPTIMISATION FISCALE

### 1. Déficits Reportables

| Type | Durée | Plafond |
|------|-------|---------|
| **Déficits N** | Illimitée | - |
| **Déficits N-1 à N-10** | Report arrière | 1M€ |
| **Déficits reportés** | Report avant | - |

### 2. Crédit Impôt Recherche (CIR)

| Dépense | Taux |
|---------|------|
| **Personnel recherche** | 30% (jusqu'à 100M€) |
| **Dépenses opérationnelles** | 30% |
| **Immobilisations** | 30% |

### 3. Crédit Impôt Compétitivité Emploi (CICE)

```
Base: Masse salariale brute
Taux: 6%
Plafond: 2.5 × SMIC par salarié
Utilisation: IS, ISF, dette sociale
```

### 4. Jeunes Entreprises Innovantes (JEI)

| Avantage | Détail |
|----------|--------|
| **Exonération IS** | 100% (année 1), 50% (année 2) |
| **Exonération CFE** | 100% (2 ans) |
| **Crédit impôt recherche** | Majoré |

#### Conditions

```
1. < 8 ans d'existence
2. < 50 salariés
3. R&D > 15% dépenses
4. Capital détenu > 50% par personnes physiques
```

---

## 🌍 FISCALITÉ INTERNATIONALE

### 1. Conventions Fiscales

#### Méthodes d'Élimination Double Imposition

| Méthode | Description | Pays |
|---------|-------------|------|
| **Exonération** | Revenu étranger exonéré | Luxembourg, Belgique |
| **Crédit d'impôt** | Crédit égal à l'impôt étranger | USA, UK |
| **Déduction** | Impôt étranger déductible | - |

### 2. Prix de Transfert

#### Documentation Obligatoire

| Entreprise | Obligation |
|------------|------------|
| **CA consolidé > 150M€** | Master File + Local File |
| **CA > 50M€** | Local File |
| **Opérations > 5M€** | Déclaration 2257-SD |

#### Méthodes Acceptées

| Méthode | Usage |
|---------|-------|
| **Prix comparable** | Transactions indépendantes |
| **Marge comparable** | Marge nette |
| **Partage bénéfices** | Contributions respectives |
| **Prix de réalisation** | Prix de revente moins marge |

### 3. CFC Rules (Sociétés Étrangères Contrôlées)

```
Imposition en France si:
├── Contrôle > 50%
├── Imposition étrangère < 50% du taux français
└── Revenus passifs (dividendes, intérêts, royalties)
```

---

## 📋 FORMALITÉS FISCALES

### 1. Déclarations

| Déclaration | Délai | Contenu |
|-------------|-------|---------|
| **2065** | 15/05 | Résultat société |
| **2257-SD** | 15/05 | Prix de transfert |
| **275** | 15/05 | Déclaration CFE |
| **2033** | 15/05 | Déclaration TVA |

### 2. Retenues à la Source

| Élément | Taux | Obligation |
|---------|------|------------|
| **Dividendes** | 12.8% | Prélèvement forfaitaire |
| **Intérêts** | 12.8% | Prélèvement forfaitaire |
| **Revenus fonciers** | 12.8% | Prélèvement forfaitaire |

### 3. TVA

| Opération | TVA | Récupération |
|-----------|-----|--------------|
| **Vente actions** | Exonérée | - |
| **Vente fonds de commerce** | 20% | Oui |
| **Apport actif** | 20% | Oui |
| **Fusion** | Exonérée | - |

---

## 🔗 RÉFÉRENCES

### Textes Légaux

| Texte | Référence | Usage |
|-------|-----------|-------|
| **CGI Art. 39** | Plus-values professionnelles | Cession |
| **CGI Art. 151-8** | Régime holding | Exonération |
| **CGI Art. 209** | IS | Imposition sociétés |
| **CGI Art. 212** | Déduction charges | Intérêts |
| **CGI Art. 223 A** | Groupe intégré | Consolidation |

### Autorités

| Autorité | Rôle | Contact |
|----------|------|---------|
| **DGFiP** | IS, TVA | www.impots.gouv.fr |
| **BOFiP** | Doctrine fiscale | bofip.impots.gouv.fr |
| **OCDE** | Prix de transfert | www.oecd.org |

---

*Largo 2.0 — Fiscalité M&A France*
