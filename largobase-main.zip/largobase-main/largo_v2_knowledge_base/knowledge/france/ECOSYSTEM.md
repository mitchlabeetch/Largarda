# ÉCOSYSTÈME FRANCE — Guide Complet

> **Version**: 2.0 — Écosystème M&A Français  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

Ce document décrit l'écosystème M&A en France : acteurs, réglementation, sources de données, et spécificités du marché français.

### Spécificités du Marché Français M&A

| Aspect | Caractéristique |
|--------|-----------------|
| **Volume annuel** | ~3,500 transactions |
| **Valeur totale** | ~150-200 Mds€ |
| **Segment dominant** | Small-mid cap (< 50M€) |
| **Acteurs principaux** | CAB, Big4, Boutiques |
| **Réglementation** | AMF, DGCCRF, Autorités de concurrence |

---

## 🏛️ ACTEURS M&A EN FRANCE

### Cabinets de Conseil (CAB)

| Cabinet | Spécialisation | Taille typique |
|---------|---------------|----------------|
| **Rothschild & Co** | Large cap, cross-border | > 500M€ |
| **Lazard** | Large cap, restructuring | > 500M€ |
| **Bryan Garnier** | Mid cap, tech | 50-500M€ |
| **DC Advisory** | Mid cap | 50-500M€ |
| **Cambon Partners** | Mid cap, family offices | 20-200M€ |
| **EY-Parthenon** | Multi-sectoriel | Toutes tailles |
| **KPMG Corporate Finance** | Multi-sectoriel | Toutes tailles |
| **Livingstone** | Small-mid cap | 10-100M€ |
| **Siparex** | Small cap, LBO | 5-50M€ |

### Investisseurs Financiers

| Type | Acteurs | Focus |
|------|---------|-------|
| **Capital Développement** | Eurazeo, Wendel, Bpifrance | Croissance |
| **LBO Mid Cap** | PAI Partners, EQT, Ardian | 100M€ - 1Md€ |
| **LBO Small Cap** | Siparex, Capzanine, ArchiMed | 10-100M€ |
| **Family Offices** | Decaux, Dassault, Mulliez | Patrimonial |
| **Fonds Souverains** | Bpifrance, CDC | Stratégique |

### Investisseurs Stratégiques

| Secteur | Acteurs majeurs |
|---------|-----------------|
| **Agroalimentaire** | Lactalis, Danone, Nestlé FR |
| **Industrie** | Safran, Thalès, Michelin |
| **Services** | Capgemini, Sodexo, Edenred |
| **Distribution** | Carrefour, Casino, Les Mousquetaires |
| **Tech** | Dassault Systèmes, Sopra Steria |

---

## 📊 SOURCES DE DEALS

### Plateformes de Deal Flow

| Plateforme | Type | Accès |
|------------|------|-------|
| **Cian** | Marketplace M&A | Professionnels |
| **Eloquens** | Templates M&A | Public |
| **MergerMarket** | Intelligence M&A | Payant |
| **CFNews** | Actualité M&A | Professionnels |
| **Capital Finance** | Actualité M&A | Professionnels |

### Réseaux Professionnels

| Réseau | Usage |
|--------|-------|
| **France Digitale** | Tech/Startup |
| **MEDEF** | Grandes entreprises |
| **CGPME** | PME |
| **France Angels** | Business Angels |
| **France Invest** | Capital Investissement |

---

## 📈 STATISTIQUES M&A FRANCE

### Volume par Secteur (2024)

| Secteur | % du Volume | Multiple médian |
|---------|-------------|-----------------|
| **Industrie** | 28% | 6.2x EBITDA |
| **Services** | 24% | 7.5x EBITDA |
| **Tech/Digital** | 18% | 9.0x EBITDA |
| **Distribution** | 15% | 5.5x EBITDA |
| **Santé** | 8% | 8.0x EBITDA |
| **Autres** | 7% | 6.0x EBITDA |

### Volume par Région

| Région | % des Transactions |
|--------|-------------------|
| **Île-de-France** | 42% |
| **Auvergne-Rhône-Alpes** | 12% |
| **PACA** | 9% |
| **Occitanie** | 8% |
| **Nouvelle-Aquitaine** | 7% |
| **Hauts-de-France** | 6% |
| **Autres** | 16% |

---

## 🔍 SOURCES DE DONNÉES

### APIs Publiques Gratuites

| API | Données | Coût |
|-----|---------|------|
| **recherche-entreprises.api.gouv.fr** | SIREN, SIRET, NAF, adresse | **GRATUIT** |
| **api.insee.fr (SIRENE)** | Données détaillées | **GRATUIT** (token) |
| **entreprise.api.gouv.fr** | Bilans, mandataires | **GRATUIT** (token) |
| **data.economie.gouv.fr** | Données économiques | **GRATUIT** |

### Sources Payantes

| Source | Données | Coût |
|--------|---------|------|
| **Pappers** | Données complètes, scoring | ~€50-200/mois |
| **Societe.com** | Données entreprises | ~€30-100/mois |
| **Infogreffe** | Kbis, actes | ~€10-50/document |
| **Bodacc** | Annonces légales | **GRATUIT** |
| **AMF** | Information financière | **GRATUIT** |

---

## ⚖️ RÉGLEMENTATION

### Autorités de Contrôle

| Autorité | Rôle |
|----------|------|
| **AMF** | Marchés financiers, OPAs |
| **DGCCRF** | Concurrence, consommation |
| **Autorité de la Concurrence** | Contrôle concentrations |
| **ACPR** | Banque, assurance |
| **CNIL** | Protection données |

### Seuils de Déclaration

| Type | Seuil | Délai |
|------|-------|-------|
| **Déclaration concentration** | CA combiné > 150M€ en FR | Pré-closing |
| **Autorisation concentration** | CA combiné > 150M€ en FR + 2 parties > 50M€ | 25 jours |
| **OPA obligatoire** | > 30% du capital | 10 jours |

---

## 🗺️ SPÉCIFICITÉS RÉGIONALES

### PACA (Région Christophe)

| Caractéristique | Détail |
|-----------------|--------|
| **Poids économique** | 4ème région française |
| **Secteurs clés** | Tourisme, Tech, Biotech, Aéronautique |
| **Clusters** | Sophia Antipolis (tech), Eurobiomed (santé) |
| **Investisseurs locaux** | Bpifrance Méditerranée, PACA Investissement |

### Clusters d'Excellence PACA

| Cluster | Secteur | Entreprises |
|---------|---------|-------------|
| **Sophia Antipolis** | Tech/Digital | 2,500+ |
| **Eurobiomed** | Santé/Biotech | 350+ |
| **Pôle Mer** | Maritime | 200+ |
| **Aerospace Valley** | Aéronautique | 150+ |

---

## 💼 SPÉCIFICITÉS JURIDIQUES

### Formes Juridiques Courantes

| Forme | Usage | Caractéristiques |
|-------|-------|------------------|
| **SAS** | Startups, PME | Flexible, pas de capital minimum |
| **SASU** | Entrepreneur solo | SAS à associé unique |
| **SARL** | PME familiales | Gérance, capital minimum 1€ |
| **SA** | Grandes entreprises | Conseil d'administration |
| **SCI** | Immobilier | Gestion patrimoniale |

### Mécanismes Spécifiques

| Mécanisme | Description |
|-----------|-------------|
| **Pacte d'actionnaires** | Contrôle gouvernance |
| **Clause de non-concurrence** | Protection acquéreur |
| **Earn-out** | Ajustement prix sur performance |
| **Levier fiscal** | Déduction intérêts (LBO) |
| **CICE** | Crédit impôt compétitivité |

---

## 📰 VIEILLE M&A

### Sources d'Actualité

| Source | Type | Fréquence |
|--------|------|-----------|
| **Les Echos** | Généraliste | Quotidien |
| **CFNews** | Spécialisé M&A | Hebdomadaire |
| **Capital Finance** | Spécialisé M&A | Mensuel |
| **Agefi** | Finance | Quotidien |
| **Boursorama** | Bourse | Temps réel |

### Flux RSS Recommandés

```
Les Echos M&A: https://www.lesechos.fr/rss/flux-m-a.xml
CFNews: https://www.cfnews.net/rss
Capital Finance: https://www.capitalfinance.fr/rss
```

---

## 🔗 RÉFÉRENCES

- [APIS.md](APIS.md) — APIs françaises détaillées
- [REGULATIONS.md](REGULATIONS.md) — Réglementation complète
- [SECTORS.md](SECTORS.md) — Secteurs d'activité
- [REGIONS.md](REGIONS.md) — Régions françaises

---

*Largo 2.0 — Écosystème M&A France*
