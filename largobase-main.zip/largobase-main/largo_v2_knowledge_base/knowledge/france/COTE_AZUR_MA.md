# M&A CÔTE D'AZUR — Écosystème Complet

> **Version**: 2.0 — M&A PACA Focus  
> **Zone**: Alpes-Maritimes (06), Var (83), Monaco  
> **Last Updated**: 2026-03-18

---

## 🎯 Vue d'Ensemble

La Côte d'Azur est un écosystème M&A dynamique avec des spécificités sectorielles fortes : tourisme haut de gamme, biotech, tech, aéronautique, et immobilier de luxe.

### Chiffres Clés PACA

| Indicateur | Valeur |
|------------|--------|
| **Entreprises** | 180,000+ |
| **PME** | 95% des entreprises |
| **ETI** | ~350 entreprises |
| **CA moyen PME** | 2.5M€ |
| **Transactions M&A/an** | ~400 |
| **Valeur moyenne transaction** | 8M€ |

---

## 🏢 ÉCOSYSTÈME M&A CÔTE D'AZUR

### Acteurs Clés

#### Cabinets de Conseil

| Cabinet | Spécialisation | Contact |
|---------|---------------|---------|
| **Alecia M&A** | Small-mid cap, multi-sectoriel | christophe@alecia.fr |
| **Cambon Partners** | Mid cap, family offices | Nice office |
| **Livingstone** | Small cap, PME | Paris/Nice |
| **Siparex** | LBO small cap | Lyon/Nice |
| **EY Parthenon** | Multi-sectoriel | Sophia Antipolis |

#### Investisseurs Locaux

| Investisseur | Focus | Ticket |
|--------------|-------|--------|
| **Bpifrance Méditerranée** | Innovation, croissance | 500k€ - 5M€ |
| **PACA Investissement** | PME régionales | 200k€ - 2M€ |
| **Sofimac Innovation** | Tech, biotech | 1M€ - 10M€ |
| **Elaia Partners** | Deep tech | 2M€ - 15M€ |
| **Monaco Investment Fund** | Diversifié | 5M€+ |

#### Family Offices Côte d'Azur

| Family Office | Secteurs | Approche |
|---------------|----------|----------|
| **Famille Pastor** | Immobilier, services | Patrimonial |
| **Famille Dassault** | Tech, aéronautique | Stratégique |
| **Famille Bouygues** | Construction, média | Stratégique |
| **Family Office Monaco** | Diversifié | International |

---

## 🏭 SECTEURS CLÉS CÔTE D'AZUR

### 1. Tourisme & Hôtellerie de Luxe

| Segment | Caractéristiques | Multiples |
|---------|------------------|-----------|
| **Palaces** | CA > 20M€, marge 25-35% | 10-15x EBITDA |
| **Hôtels 5* ** | CA 5-20M€, marge 20-30% | 8-12x EBITDA |
| **Résidences de luxe** | CA 2-10M€, marge 15-25% | 6-10x EBITDA |
| **Conciergerie** | CA 1-5M€, marge 30-50% | 5-8x CA |

**Acteurs majeurs**: Four Seasons, Airelles, Cheval Blanc, Oetker Collection

### 2. Biotech & Santé (Sophia Antipolis)

| Segment | Caractéristiques | Valorisation |
|---------|------------------|--------------|
| **Biotech** | R&D intensive, pas de revenus | VC method, DCF |
| **Medtech** | Prototypes, premiers clients | 3-8x CA |
| **E-santé** | SaaS, récurrence | 5-12x CA |
| **Services santé** | Rentable, croissance | 6-10x EBITDA |

**Clusters**: Eurobiomed, OncoSentine, Institut Pasteur

### 3. Tech & Digital (Sophia Antipolis)

| Segment | Caractéristiques | Multiples |
|---------|------------------|-----------|
| **SaaS B2B** | Récurrent, sticky | 5-15x CA |
| **Cybersécurité** | Forte croissance | 8-20x CA |
| **IA/Data** | Talent intensive | 6-15x CA |
| **EdTech** | Marché en croissance | 4-10x CA |

**Entreprises clés**: Amadeus, Dassault Systèmes, SAP Labs, Intel

### 4. Aéronautique

| Segment | Caractéristiques | Multiples |
|---------|------------------|-----------|
| **Sous-traitance** | Dépendance Airbus | 5-8x EBITDA |
| **MRO** | Services, récurrent | 6-10x EBITDA |
| **Composants** | Spécialisé | 7-12x EBITDA |

**Acteurs**: Thalès Alenia Space, Safran, Airbus Helicopters

### 5. Immobilier de Luxe

| Segment | Caractéristiques | Valorisation |
|---------|------------------|--------------|
| **Promotion** | Projets > 50M€ | Actif net + marge |
| **Agences** | Commission 3-5% | 3-6x CA |
| **Conciergerie** | Services haut de gamme | 4-8x CA |
| **Gestion locative** | Récurrent | 6-10x EBITDA |

---

## 📊 PME/ETI CÔTE D'AZUR

### Profil Type PME (06)

```
CA: 2M€ - 10M€
Effectif: 10 - 50 salariés
Secteur: Services (40%), Commerce (25%), Industrie (20%), BTP (15%)
Forme juridique: SAS (60%), SARL (30%), SA (10%)
Rentabilité: EBITDA margin 8-15%
Croissance: 5-15%/an
```

### Profil Type ETI (06)

```
CA: 50M€ - 500M€
Effectif: 250 - 2000 salariés
Secteur: Tech (30%), Industrie (25%), Services (25%), Tourisme (20%)
International: 40% du CA à l'export
Rentabilité: EBITDA margin 10-18%
```

### Top ETI Côte d'Azur (2024)

| Rang | Entreprise | Secteur | CA | Effectif |
|------|------------|---------|-----|----------|
| 1 | Amadeus | Tech | 5.6Md€ | 19,000 |
| 2 | Thalès Alenia Space | Aéronautique | 2.1Md€ | 8,000 |
| 3 | Dassault Systèmes | Software | 6.0Md€ | 25,000 |
| 4 | SAP Labs France | Software | 450M€ | 2,500 |
| 5 | Pierre & Vacances | Tourisme | 800M€ | 8,000 |

---

## 🏛️ CLUSTERS & ZONES

### Sophia Antipolis

| Caractéristique | Détail |
|-----------------|--------|
| **Entreprises** | 2,500+ |
| **Salariés** | 38,000 |
| **Nationalités** | 60+ |
| **Secteurs** | Tech, Biotech, Énergie |
| **Sorties** | 50+ startups/an |

**Acteurs M&A**: Elaia Partners, Sofimac, Bpifrance

### Nice Eco-Vallée

| Caractéristique | Détail |
|-----------------|--------|
| **Focus** | Éco-technologie |
| **Entreprises** | 200+ |
| **Projets** | Smart city, énergie |

### Monaco Tech

| Caractéristique | Détail |
|-----------------|--------|
| **Focus** | Fintech, Greentech |
| **Startups** | 50+ |
| **Avantages** | Fiscalité, réseau |

---

## 💰 INVESTISSEMENT & TAXATION M&A

### Structures d'Investissement

#### 1. Fonds Propres

| Structure | Avantages | Inconvénients |
|-----------|-----------|---------------|
| **Apport en numéraire** | Simple, rapide | Dilution |
| **Apport en nature** | Pas de cash | Évaluation complexe |
| **Conversion créances** | Pas de cash | Négociation |

#### 2. Dette

| Type | Taux | Usage |
|------|------|-------|
| **Prêt bancaire** | 3-6% | LBO, acquisition |
| **Obligations** | 4-7% | Grande entreprise |
| **Dette mezzanine** | 10-15% | Complément LBO |
| **Vendor loan** | 5-8% | Vendeur financeur |

#### 3. LBO (Leveraged Buy-Out)

```
Structure typique LBO small cap:
├── Fonds propres: 30-50%
├── Dette senior: 40-60%
├── Detre mezzanine: 10-20%
└── Vendor loan: 0-20%
```

### Fiscalité M&A France

#### Impôts sur les Plus-Values

| Situation | Taux | Conditions |
|-----------|------|------------|
| **Plus-value professionnelle** | 12.8% IR + 17.2% PS | Moins de 10% détenus |
| **Plus-value de cession** | 30% (flat tax) | Particuliers |
| **Abattement durée** | 50% à 85% | > 2 ans, < 8 ans |
| **Exonération** | 100% | Holding > 25%, > 2 ans |

#### Optimisation Fiscale

| Mécanisme | Description | Économie |
|-----------|-------------|----------|
| **Déduction intérêts** | Charges financières déductibles | 25% de la dette |
| **Amortissement goodwill** | Sur 5-20 ans | Réduction IS |
| **Déficit reportable** | Jusqu'à -1M€ | Économie IS |
| **CICE** | Crédit impôt compétitivité | 6% masse salariale |

#### Holding de Financement

```
Avantages:
├── Déduction intérêts (jusqu'à 25% EBITDA)
├── Amortissement goodwill
├── Déficit reportable
└── Exonération plus-values (holding > 2 ans)
```

---

## 📋 DUE DILIGENCE SPÉCIFIQUE CÔTE D'AZUR

### Points d'Attention

#### 1. Immobilier

| Élément | Vérification |
|---------|--------------|
| **Bail commercial** | Durée, loyer, indexation |
| **Droit au bail** | Valeur, renouvellement |
| **Promesse de vente** | Conditions suspensives |
| **Permis de construire** | Conformité, recours |

#### 2. Tourisme

| Élément | Vérification |
|---------|--------------|
| **Classement** | Étoiles, labels |
| **Saisonnalité** | CA haute/basse saison |
| **OTA** | Commissions Booking, Expedia |
| **Réputation** | Avis en ligne, notation |

#### 3. Biotech

| Élément | Vérification |
|---------|--------------|
| **Brevets** | Validité, périmètre |
| **Regulatory** | FDA, EMA, ANSM |
| **Clinical trials** | Phases, résultats |
| **Partenariats** | Licensing, co-développement |

#### 4. Tech

| Élément | Vérification |
|---------|--------------|
| **IP** | Brevets, copyright, trade secrets |
| **Open source** | Licences GPL, MIT, etc. |
| **Data privacy** | GDPR, CNIL |
| **Sécurité** | ISO 27001, SOC 2 |

---

## 🤝 RÉSEAUX & ÉVÉNEMENTS

### Réseaux Professionnels

| Réseau | Focus | Fréquence |
|--------|-------|-----------|
| **MEDEF Côte d'Azur** | Grandes entreprises | Mensuel |
| **CJD PACA** | Jeunes dirigeants | Mensuel |
| **France Digitale** | Tech | Trimestriel |
| **Eurobiomed** | Biotech | Mensuel |
| **Sophia Business Angels** | Investissement | Mensuel |

### Événements M&A

| Événement | Date | Lieu |
|-----------|------|------|
| **M&A Forum Nice** | Mars | Nice |
| **Sophia Summit** | Juin | Sophia Antipolis |
| **Monaco Private Equity** | Octobre | Monaco |
| **Biotech Forum** | Novembre | Nice |

---

## 📞 CONTACTS UTILES

### Institutions

| Institution | Contact | Usage |
|-------------|---------|-------|
| **CCI Nice Côte d'Azur** | 04 97 03 80 00 | Info entreprises |
| **Bpifrance Méditerranée** | 04 91 91 30 00 | Financement |
| **PACA Investissement** | 04 91 91 30 00 | Capital |
| **Direction Générale des Finances Publiques** | 0809 401 401 | Fiscalité |

### Cabinets d'Avocats M&A

| Cabinet | Spécialisation | Contact |
|---------|---------------|---------|
| **Gide Loyrette Nouel** | M&A international | Nice |
| **Latham & Watkins** | Private equity | Paris/Monaco |
| **Bryan Cave Leighton Paisner** | Mid cap | Paris |
| **FTPA** | PME/ETI | Nice |
| **August & Debouzy** | Tech M&A | Paris |

### Commissaires aux Comptes

| Cabinet | Spécialisation | Contact |
|---------|---------------|---------|
| **Deloitte** | Audit, due diligence | Nice |
| **EY** | Transaction services | Sophia Antipolis |
| **KPMG** | Financial due diligence | Nice |
| **PwC** | M&A advisory | Monaco |
| **Exco** | PME | Nice |

---

*Largo 2.0 — M&A Côte d'Azur Ecosystem*
