# LARGO 2.0 — Guide Complet Flowise (100% Free Tier)

> **Version**: 2.0-Flowise  
> **Budget**: 0€ (100% free tiers)  
> **Date**: 18 Mars 2026  
> **Status**: ✅ Complete

---

## 🎯 Objectif

Ce guide vous permet de configurer **Largo entièrement avec des services gratuits**, sans dépenser un centime.

---

## 📦 Ce qui est inclus

### 1. Fichiers Uploadables (`flowise_kb/`)

| Catégorie | Nombre | Description |
|-----------|--------|-------------|
| **Prompts** | 1 | System prompt complet pour Largo |
| **Tools** | 11 | Custom Tools JSON pour M&A |
| **Agentflows** | 6 | Configurations agents spécialisés |
| **Documents** | 4 | Configs loaders et structure KB |
| **Memory** | 4 | Configs mémoire (buffer, Zep, vector) |
| **Total** | **26** | Fichiers prêts à uploader |

### 2. Guides Détaillés (`flowise_guides/`)

| Guide | Description | Temps |
|-------|-------------|-------|
| [01. Installation](flowise_guides/setup/01_INSTALLATION.md) | Installer Flowise | 30-45 min |
| [02. Main Chatflow](flowise_guides/setup/02_MAIN_CHATFLOW.md) | Créer l'agent principal | 20-30 min |
| [03. Custom Tools](flowise_guides/setup/03_CUSTOM_TOOLS.md) | Créer les 11 tools | 45-60 min |
| [04. RAG Setup](flowise_guides/setup/04_RAG_SETUP.md) | Configurer le RAG | 30-45 min |
| [05. Memory Setup](flowise_guides/setup/05_MEMORY_SETUP.md) | Configurer la mémoire | 20-30 min |
| [06. Agentflows](flowise_guides/setup/06_AGENTFLOWS.md) | Créer les agents | 30-45 min |
| [07. Upload Handling](flowise_guides/setup/07_UPLOAD_HANDLING.md) | Gérer les uploads | 20-30 min |
| [08. Cron Jobs](flowise_guides/setup/08_CRON_JOBS.md) | Automatiser | 15-25 min |
| [09. Configuration Complète](flowise_guides/setup/09_COMPLETE_CONFIGURATION.md) | **Tous les free tiers** | 2-3h |
| [Free Tiers Cheatsheet](flowise_guides/FREE_TIERS_CHEATSHEET.md) | **Référence rapide** | 5 min |

---

## 🚀 Démarrage Rapide (5 minutes)

### Option 1 : Configuration Cloud Rapide (Recommandée)

```bash
# 1. Installer Flowise
cd ~/flowise
docker-compose up -d

# 2. Générer les API keys (gratuites)
# → Groq: https://console.groq.com (1M tokens/jour)
# → HuggingFace: https://huggingface.co/settings/tokens (30K req/jour)
# → Pinecone: https://app.pinecone.io (100K vecteurs)

# 3. Configurer dans Flowise
# → Credentials → Add Credential pour chaque service

# 4. Importer les tools
# → Tools → Import → flowise_kb/tools/*.json

# 5. Créer le chatflow
# → Copier flowise_kb/prompts/SYSTEM_PROMPT.md
# → Configurer Chat Model (Groq → llama-3.3-70b)
# → Ajouter les tools
# → Tester
```

**Coût**: 0€  
**Limite**: 1M tokens/jour, 100K vecteurs  
**Setup**: 5 minutes

---

### Option 2 : Configuration 100% Locale (Privée)

```bash
# 1. Installer Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. Pull les modèles
ollama pull llama3.2:70b
ollama pull nomic-embed-text

# 3. Démarrer Chroma
docker run -d -p 8000:8000 chromadb/chroma:latest

# 4. Configurer Flowise
# → Chat Model: Ollama (llama3.2:70b)
# → Embeddings: Ollama (nomic-embed-text)
# → Vector Store: Chroma (localhost:8000)
```

**Coût**: 0€  
**Limite**: Illimité (limité par hardware)  
**Setup**: 30 minutes

---

## 📋 Récapitulatif des Free Tiers

### Chat Models (LLM)

| Provider | Modèle | Free Tier | Setup |
|----------|--------|-----------|-------|
| **Groq** ⭐ | Llama 3.3 70B | 1M tokens/jour | [console.groq.com](https://console.groq.com) |
| **Ollama** | Llama/Mistral | Illimité (local) | `ollama pull llama3.2:70b` |
| **OpenRouter** | Claude 3.5 | 200 req/jour | [openrouter.ai](https://openrouter.ai) |
| **Kimi** | Kimi K2 | 1M tokens | [platform.moonshot.cn](https://platform.moonshot.cn) |
| **Google** | Gemini Pro | 60 req/min | [aistudio.google.com](https://aistudio.google.com) |

### Vector Stores

| Provider | Free Tier | Setup |
|----------|-----------|-------|
| **Chroma** ⭐ | Illimité (local) | Docker |
| **Pinecone** | 100K vecteurs | [pinecone.io](https://pinecone.io) |
| **Qdrant** | Illimité (local) | Docker |

### Embeddings

| Provider | Modèle | Free Tier | Setup |
|----------|--------|-----------|-------|
| **Ollama** | nomic-embed-text | Illimité | `ollama pull nomic-embed-text` |
| **HuggingFace** | all-MiniLM-L6-v2 | 30K req/jour | [huggingface.co](https://huggingface.co) |

### Web Search

| Provider | Free Tier | Setup |
|----------|-----------|-------|
| **DuckDuckGo** ⭐ | Illimité | Aucune |
| **Brave Search** | 2000 req/mois | [brave.com/search/api](https://brave.com/search/api) |

---

## 🏗️ Architecture Complète

```
┌─────────────────────────────────────────────────────────────────┐
│                        LARGO 2.0 — FLOWISE                       │
│                         (100% Free Tier)                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   LARGO MAIN AGENT                       │   │
│   │                                                          │   │
│   │   ┌─────────┐  ┌─────────┐  ┌─────────────────────┐     │   │
│   │   │ System  │→ │  LLM    │→ │     TOOLS (11)      │     │   │
│   │   │ Prompt  │  │ (Groq/  │  │  • search_company   │     │   │
│   │   │         │  │ Ollama) │  │  • get_valuation    │     │   │
│   │   └─────────┘  └─────────┘  │  • web_search       │     │   │
│   │          ↑                  │  • query_rag        │     │   │
│   │   ┌──────┴──────┐           │  • save_memory      │     │   │
│   │   │Buffer Memory│           └─────────────────────┘     │   │
│   │   │  (k=10)     │                                        │   │
│   │   └─────────────┘                                        │   │
│   └─────────────────────────────────────────────────────────┘   │
│                              │                                   │
│           ┌──────────────────┼──────────────────┐              │
│           ↓                  ↓                  ↓              │
│   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐      │
│   │Document Agent│   │Research Agent│   │Meeting Agent │      │
│   └──────────────┘   └──────────────┘   └──────────────┘      │
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   INFRASTRUCTURE (Free)                  │   │
│   │                                                          │   │
│   │   ┌──────────┐  ┌──────────┐  ┌─────────────────────┐   │   │
│   │   │ Chroma/  │  │  Zep     │  │     PostgreSQL      │   │   │
│   │   │Pinecone  │  │ (Memory) │  │  (Conversations)    │   │   │
│   │   │  (RAG)   │  │          │  │                     │   │   │
│   │   └──────────┘  └──────────┘  └─────────────────────┘   │   │
│   │                                                          │   │
│   │   ┌──────────┐  ┌──────────┐  ┌─────────────────────┐   │   │
│   │   │ Ollama   │  │ Hugging  │  │   DuckDuckGo        │   │   │
│   │   │  (LLM)   │  │ (Embed.) │  │   (Web Search)      │   │   │
│   │   └──────────┘  └──────────┘  └─────────────────────┘   │   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Comparaison des Configurations

| Configuration | Coût | Setup | Vitesse | Privé | Limite |
|--------------|------|-------|---------|-------|--------|
| **Cloud (Groq)** | 0€ | 5 min | ⭐⭐⭐ | ❌ | 1M tokens/jour |
| **Local (Ollama)** | 0€ | 30 min | ⭐⭐ | ✅ | Hardware |
| **Premium (OpenRouter)** | 0€ | 10 min | ⭐⭐⭐ | ❌ | 200 req/jour |

---

## 🔧 Fichiers Clés

### Pour commencer rapidement

1. **[Free Tiers Cheatsheet](flowise_guides/FREE_TIERS_CHEATSHEET.md)** — Référence rapide
2. **[Configuration Complète](flowise_guides/setup/09_COMPLETE_CONFIGURATION.md)** — Guide détaillé
3. **[flowise_kb/prompts/SYSTEM_PROMPT.md](flowise_kb/prompts/SYSTEM_PROMPT.md)** — Prompt principal

### Pour importer dans Flowise

1. **[flowise_kb/tools/](flowise_kb/tools/)** — 11 Custom Tools JSON
2. **[flowise_kb/agentflows/](flowise_kb/agentflows/)** — 6 Agents JSON

---

## ✅ Checklist de Configuration

### Phase 1 : Infrastructure (15 min)
- [ ] Installer Docker
- [ ] Lancer Flowise (`docker-compose up -d`)
- [ ] Vérifier l'accès (`http://localhost:3000`)

### Phase 2 : API Keys (10 min)
- [ ] Groq API key ([console.groq.com](https://console.groq.com))
- [ ] HuggingFace token ([huggingface.co](https://huggingface.co/settings/tokens))
- [ ] Pinecone API key ([pinecone.io](https://app.pinecone.io)) — optionnel si Chroma

### Phase 3 : Flowise (30 min)
- [ ] Créer les credentials
- [ ] Importer les 11 tools
- [ ] Créer le chatflow principal
- [ ] Copier le system prompt
- [ ] Configurer le modèle (Groq/Ollama)
- [ ] Ajouter la mémoire
- [ ] Configurer le RAG

### Phase 4 : Test (5 min)
- [ ] Tester : "Salut Largo, recherche SIREN 123456789"
- [ ] Vérifier que les tools sont invoqués
- [ ] Vérifier la mémoire

---

## 📞 Support

En cas de problème :

1. Consulter [le guide de configuration complète](flowise_guides/setup/09_COMPLETE_CONFIGURATION.md)
2. Vérifier les [logs Flowise](flowise_guides/setup/01_INSTALLATION.md#logs)
3. Consulter le [troubleshooting](flowise_guides/README.md#troubleshooting)

---

## 📈 Prochaines Étapes

1. **Configurer les agents spécialisés** → [06. Agentflows](flowise_guides/setup/06_AGENTFLOWS.md)
2. **Mettre en place les cron jobs** → [08. Cron Jobs](flowise_guides/setup/08_CRON_JOBS.md)
3. **Intégrer WhatsApp** → [knowledge/communication/WHATSAPP.md](knowledge/communication/WHATSAPP.md)

---

*Largo 2.0 — Guide Complet Flowise (100% Gratuit)*

**Fichiers créés** : 38 (26 dans flowise_kb + 12 dans flowise_guides)  
**Taille totale** : ~232KB  
**Coût** : 0€  
**Statut** : ✅ Prêt pour déploiement
