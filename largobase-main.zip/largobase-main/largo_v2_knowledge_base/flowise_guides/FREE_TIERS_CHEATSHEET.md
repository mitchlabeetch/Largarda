# Free Tiers Cheatsheet — Largo Flowise

> **Objectif** : Référence rapide des options gratuites pour chaque composant  
> **Budget** : 0€

---

## 🎯 Configurations Recommandées

### Option A : 100% Local (0€, privé, illimité)

| Composant | Solution | Setup |
|-----------|----------|-------|
| LLM | Ollama (Llama 3.3 70B) | `ollama pull llama3.2:70b` |
| Embeddings | Ollama (nomic-embed-text) | `ollama pull nomic-embed-text` |
| Vector Store | Chroma (local) | Docker |
| Web Search | DuckDuckGo | Aucune config |

**Avantages** : 100% privé, aucun coût, aucune limite  
**Inconvénients** : Nécessite un bon GPU/CPU, setup plus complexe

---

### Option B : Cloud Rapide (0€, 5 min setup)

| Composant | Solution | Free Tier |
|-----------|----------|-----------|
| LLM | Groq (Llama 3.3 70B) | 1M tokens/jour |
| Embeddings | HuggingFace | 30K req/jour |
| Vector Store | Pinecone | 100K vecteurs |
| Web Search | DuckDuckGo | Illimité |

**Avantages** : Ultra-rapide, setup simple, pas de hardware  
**Inconvénients** : Dépendance cloud, limites quotidiennes

---

### Option C : Haute Qualité (0€, modèles premium)

| Composant | Solution | Free Tier |
|-----------|----------|-----------|
| LLM | OpenRouter (Claude 3.5) | 200 req/jour |
| Embeddings | HuggingFace (bge-large) | 30K req/jour |
| Vector Store | Chroma (local) | Illimité |
| Web Search | Brave Search | 2000 req/mois |

**Avantages** : Meilleure qualité (Claude), rapide  
**Inconvénients** : Limite de requêtes/jour

---

## 📋 Tableau Complet des Free Tiers

### Chat Models (LLM)

| Provider | Modèle | Free Tier | Limite | Setup |
|----------|--------|-----------|--------|-------|
| **Groq** ⭐ | Llama 3.3 70B | 1M tokens/jour | 20 req/min | [console.groq.com](https://console.groq.com) |
| **Ollama** ⭐ | Llama/Mistral | Illimité | Hardware | Local |
| **OpenRouter** | Claude 3.5 | 200 req/jour | - | [openrouter.ai](https://openrouter.ai) |
| **Kimi** | Kimi K2 | 1M tokens | - | [platform.moonshot.cn](https://platform.moonshot.cn) |
| **Google** | Gemini Pro | 60 req/min | - | [aistudio.google.com](https://aistudio.google.com) |

### Embeddings

| Provider | Modèle | Free Tier | Dimensions | Setup |
|----------|--------|-----------|------------|-------|
| **Ollama** ⭐ | nomic-embed-text | Illimité | 768 | `ollama pull nomic-embed-text` |
| **HuggingFace** | all-MiniLM-L6-v2 | 30K req/jour | 384 | [huggingface.co](https://huggingface.co) |
| **HuggingFace** | bge-large-en-v1.5 | 30K req/jour | 1024 | [huggingface.co](https://huggingface.co) |
| **Google** | embedding-001 | 60 req/min | 768 | [aistudio.google.com](https://aistudio.google.com) |

### Vector Stores

| Provider | Free Tier | Limite | Setup |
|----------|-----------|--------|-------|
| **Chroma** ⭐ | Illimité | Disque | Docker local |
| **Pinecone** | 100K vecteurs | 2GB | [pinecone.io](https://pinecone.io) |
| **Qdrant** | Illimité | Disque | Docker local |

### Web Search

| Provider | Free Tier | Setup |
|----------|-----------|-------|
| **DuckDuckGo** ⭐ | Illimité | Aucune |
| **Brave Search** | 2000 req/mois | [brave.com/search/api](https://brave.com/search/api) |
| **SerpAPI** | 100 req/mois | [serpapi.com](https://serpapi.com) |

---

## 🔑 API Keys à Générer

### Obligatoires (selon config)

```bash
# Groq (Option B)
# → https://console.groq.com
GROQ_API_KEY=gsk_...

# HuggingFace (Option B/C)
# → https://huggingface.co/settings/tokens
HUGGINGFACE_API_KEY=hf_...

# Pinecone (Option B)
# → https://app.pinecone.io
PINECONE_API_KEY=pcsk_...

# OpenRouter (Option C)
# → https://openrouter.ai/keys
OPENROUTER_API_KEY=sk-or-v1-...

# Brave Search (Option C)
# → https://api.search.brave.com/app/keys
BRAVE_API_KEY=BS...
```

### Optionnels

```bash
# Kimi (alternative LLM)
# → https://platform.moonshot.cn
MOONSHOT_API_KEY=sk-...

# Google (alternative LLM + embeddings)
# → https://aistudio.google.com/app/apikey
GOOGLE_API_KEY=AIza...

# SerpAPI (alternative web search)
# → https://serpapi.com/manage-api-key
SERPAPI_KEY=...
```

---

## 🚀 Quick Start — 5 Minutes

### Étape 1 : Choisir la configuration

```bash
# Option A (Local) → Si vous avez un bon GPU/CPU
# Option B (Cloud) → Si vous voulez du rapide sans hardware
# Option C (Premium) → Si vous voulez la meilleure qualité
```

### Étape 2 : Générer les API keys

```bash
# Minimum pour Option B (recommandé)
# 1. Groq : https://console.groq.com → Create API Key
# 2. HuggingFace : https://huggingface.co/settings/tokens → New Token
# 3. Pinecone : https://app.pinecone.io → Create Index (starter)
```

### Étape 3 : Configurer Flowise

```bash
# Dans Flowise → Credentials → Add Credential

# 1. Groq API
#    - Credential Type: Groq API
#    - API Key: gsk_votre_cle

# 2. HuggingFace API
#    - Credential Type: HuggingFace API
#    - API Token: hf_votre_token

# 3. Pinecone API
#    - Credential Type: Pinecone API
#    - API Key: pcsk_votre_cle
#    - Environment: us-east-1-aws
```

### Étape 4 : Créer le Chatflow

```bash
# 1. Chatflows → Add New → "Largo Main"
# 2. Add Nodes:
#    - Start
#    - System Message (copier SYSTEM_PROMPT.md)
#    - Chat Model (Groq → llama-3.3-70b)
#    - Buffer Memory (k=10)
#    - Vector Store Retriever (Pinecone)
#    - Tools (importer les 11 JSON)
#    - End
# 3. Connecter les nodes
# 4. Save & Test
```

---

## 💡 Astuces

### Rotation des Providers

Si vous atteignez les limites :

```javascript
// Dans le chatflow, ajouter une logique de fallback
const models = [
  { provider: 'groq', model: 'llama-3.3-70b' },
  { provider: 'openrouter', model: 'anthropic/claude-3.5-sonnet' },
  { provider: 'ollama', model: 'llama3.2:70b' }
];

// Essayer chaque modèle jusqu'à succès
```

### Monitoring des Limites

```bash
# Groq - vérifier l'utilisation
curl https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer $GROQ_API_KEY"

# HuggingFace - vérifier le rate limit
curl https://api-inference.huggingface.co/status
```

### Cache pour Économiser

```json
// Dans Flowise, activer le cache
{
  "cache": true,
  "cacheTTL": 3600
}
```

---

## 🆘 Dépannage

| Problème | Cause | Solution |
|----------|-------|----------|
| "Rate limit exceeded" | Limite atteinte | Attendre 1 min ou changer de provider |
| "Invalid API key" | Clé incorrecte | Régénérer la clé |
| "Model not found" | Modèle indisponible | Changer de modèle |
| "Timeout" | Trop lent | Utiliser Groq ou réduire maxTokens |
| "Out of memory" | Ollama | Réduire la taille du modèle |

---

## 📊 Comparaison Rapide

| Critère | Option A (Local) | Option B (Cloud) | Option C (Premium) |
|---------|------------------|------------------|-------------------|
| **Coût** | 0€ | 0€ | 0€ |
| **Setup** | 30 min | 5 min | 10 min |
| **Vitesse** | Dépend hardware | Ultra-rapide | Rapide |
| **Qualité** | Bonne | Bonne | Excellente |
| **Privé** | ✅ 100% | ❌ Non | ❌ Non |
| **Limite** | Hardware | 1M tokens/jour | 200 req/jour |
| **Meilleur pour** | Confidentialité | Rapidité | Qualité |

---

## 🎯 Recommandation Finale

**Pour commencer rapidement** : Option B (Groq + HuggingFace + Pinecone)  
**Pour la confidentialité** : Option A (Ollama + Chroma local)  
**Pour la qualité** : Option C (OpenRouter Claude + HuggingFace)

---

*Free Tiers Cheatsheet for Largo Flowise — 100% Gratuit*
