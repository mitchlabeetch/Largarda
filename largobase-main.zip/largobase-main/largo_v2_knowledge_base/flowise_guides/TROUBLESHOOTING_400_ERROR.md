# Résolution Erreur 400 "Provider returned error" dans Flowise

> **Erreur** : `400 Provider returned error`  
> **Contexte** : L'agent Largo répond mais échoue lors de l'appel au provider LLM

---

## 🔍 Causes Possibles et Solutions

### 1. CLÉ API INVALIDE OU EXPIRÉE (Cause la plus fréquente)

#### Symptômes
- Erreur 400 apparaît systématiquement
- Le chat démarre mais échoue à la première réponse

#### Diagnostic
```bash
# Tester votre clé API Groq
curl https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer gsk_VOTRE_CLE"

# Réponse attendue : liste des modèles
# Réponse erreur : {"error": {"message": "Invalid API key"}}
```

#### Solution

**Étape 1 : Vérifier la clé dans Flowise**
1. Flowise → **Credentials**
2. Trouver votre credential (ex: `groq-api`)
3. Cliquer sur **Edit** (icône crayon)
4. Vérifier que la clé est complète et sans espaces

**Étape 2 : Régénérer la clé si nécessaire**
1. Aller sur [console.groq.com/keys](https://console.groq.com/keys)
2. Cliquer sur **Create API Key**
3. Copier la nouvelle clé
4. La coller dans Flowise

**Étape 3 : Tester**
1. Sauvegarder le credential
2. Retourner dans le chatflow
3. Tester à nouveau

---

### 2. MODÈLE NON DISPONIBLE OU INCORRECT

#### Symptômes
- Erreur 400 intermittente
- Message mentionne le modèle

#### Diagnostic
Dans votre Chat Model node, vérifier :

| Champ | Valeur correcte |
|-------|-----------------|
| **Credential** | Le bon credential (ex: `groq-api`) |
| **Model Name** | Un modèle disponible pour ce provider |

#### Modèles disponibles par provider

**Groq** (gratuit) :
- ✅ `llama-3.3-70b-versatile`
- ✅ `llama-3.1-8b-instant`
- ✅ `mixtral-8x7b-32768`
- ✅ `gemma-2-9b-it`

**Google Gemini** (gratuit) :
- ✅ `gemini-1.5-pro-latest`
- ✅ `gemini-1.5-flash-latest`
- ✅ `gemini-pro`

**OpenRouter** (gratuit) :
- ✅ `anthropic/claude-3.5-sonnet`
- ✅ `meta-llama/llama-3.3-70b-instruct`

#### Solution

1. Dans le node **Chat Model**
2. Vérifier que **Model Name** correspond à un modèle disponible
3. Si vous utilisez Groq, essayer avec `llama-3.3-70b-versatile`
4. Sauvegarder et tester

---

### 3. PARAMÈTRES INVALIDES

#### Symptômes
- Erreur 400 avec message sur les paramètres
- Temperature ou maxTokens hors limites

#### Paramètres valides

| Paramètre | Valeur min | Valeur max | Recommandé |
|-----------|------------|------------|------------|
| **Temperature** | 0 | 2 | 0.7 |
| **Max Tokens** | 1 | 8192 | 4096 |
| **Top P** | 0 | 1 | 0.9 |

#### Solution

Dans le node **Chat Model** :

```json
{
  "temperature": 0.7,
  "maxTokens": 4096,
  "topP": 0.9
}
```

**⚠️ Ne pas dépasser les limites du provider !**

---

### 4. QUOTA DÉPASSÉ

#### Symptômes
- Erreur 400 après plusieurs utilisations
- Message mentionne "rate limit" ou "quota"

#### Vérifier son quota

**Groq** :
```bash
curl https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer gsk_VOTRE_CLE"

# Vérifier l'en-tête X-RateLimit-Remaining
```

**Google AI Studio** :
- Aller sur [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
- Vérifier l'utilisation

#### Solutions

| Option | Description |
|--------|-------------|
| **Attendre** | Les quotas se réinitialisent quotidiennement |
| **Changer de provider** | Passer à un autre provider gratuit |
| **Utiliser Ollama** | 100% gratuit, pas de quota |

---

### 5. CREDENTIAL NON SÉLECTIONNÉ

#### Symptômes
- Erreur 400 immédiate
- Le node Chat Model n'a pas de credential associé

#### Vérification

Dans le node **Chat Model** :

1. Vérifier que **Credential** n'est pas vide
2. Vérifier que c'est le bon credential
3. Si vide, cliquer sur **Add Credential**

#### Configuration correcte

```
Chat Model Node:
├── Credential: groq-api (ou votre credential)
├── Model Name: llama-3.3-70b-versatile
├── Temperature: 0.7
├── Max Tokens: 4096
└── Streaming: true
```

---

### 6. PROBLÈME DE CONNECTIVITÉ

#### Symptômes
- Erreur 400 ou timeout
- Pas de réponse du provider

#### Diagnostic

```bash
# Tester la connectivité
ping api.groq.com

# Tester l'API
curl -I https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer gsk_VOTRE_CLE"
```

#### Solutions

| Problème | Solution |
|----------|----------|
| Firewall | Ouvrir le port 443 (HTTPS) |
| Proxy | Configurer les variables d'environnement |
| DNS | Utiliser 8.8.8.8 ou 1.1.1.1 |

---

## ✅ CHECKLIST DE RÉSOLUTION

### Étape 1 : Vérifier les bases
- [ ] Le credential est-il sélectionné dans le Chat Model ?
- [ ] La clé API est-elle valide et non expirée ?
- [ ] Le modèle est-il disponible pour ce provider ?

### Étape 2 : Tester le credential
- [ ] Aller dans **Credentials**
- [ ] Cliquer **Edit** sur le credential concerné
- [ ] Vérifier que la clé est complète
- [ ] Tester avec la commande curl ci-dessus

### Étape 3 : Vérifier les paramètres
- [ ] Temperature entre 0 et 2
- [ ] Max Tokens entre 1 et 8192
- [ ] Model Name correct

### Étape 4 : Tester avec un provider alternatif
Si Groq ne fonctionne pas, essayer :
- [ ] Google Gemini (gratuit)
- [ ] OpenRouter (gratuit)
- [ ] Ollama (local, 100% gratuit)

---

## 🔧 CONFIGURATION DE SECOURS (100% Fonctionnelle)

Si vous continuez à avoir des erreurs, utiliser cette configuration garantie :

### Option 1 : Google Gemini (Gratuit)

1. **Créer un credential Google**
   - Aller sur [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
   - Créer une API key
   - Dans Flowise : Credentials → Add Credential
   - **Credential Type** : `Google Generative AI`
   - **Name** : `google-gemini`
   - **API Key** : `AIza...`

2. **Configurer le Chat Model**
   - **Credential** : `google-gemini`
   - **Model Name** : `gemini-1.5-pro-latest`
   - **Temperature** : `0.7`
   - **Max Tokens** : `4096`

### Option 2 : Ollama (100% Gratuit, Local)

1. **Installer Ollama**
   ```bash
   curl -fsSL https://ollama.com/install.sh | sh
   ollama pull llama3.2
   ollama serve
   ```

2. **Configurer dans Flowise**
   - **Credential** : Aucun (local)
   - **Base URL** : `http://localhost:11434`
   - **Model Name** : `llama3.2`
   - **Temperature** : `0.7`

---

## 📊 TABLEAU RÉCAPITULATIF DES ERREURS

| Code | Message | Cause | Solution |
|------|---------|-------|----------|
| 400 | `Provider returned error` | Clé API invalide | Régénérer la clé |
| 400 | `Invalid model` | Modèle inexistant | Changer de modèle |
| 401 | `Unauthorized` | Clé API invalide | Vérifier la clé |
| 429 | `Rate limit exceeded` | Quota dépassé | Attendre ou changer provider |
| 500 | `Internal server error` | Problème provider | Réessayer plus tard |

---

## 🆘 SI RIEN NE FONCTIONNE

### Dernière solution : Configuration minimale

1. **Créer un nouveau chatflow**
   - Chatflows → Add New → "Largo Test"

2. **Configuration minimale**
   ```
   Nodes:
   ├── Start
   ├── System Message (votre prompt)
   ├── Chat Model (Google Gemini)
   └── End
   ```

3. **Sans tools, sans memory** — juste tester le LLM

4. **Si ça fonctionne**, ajouter progressivement :
   - Buffer Memory
   - Tools un par un
   - Vector Store

---

## 💬 EXEMPLE DE CONVERSATION FONCTIONNELLE

```
User: Salut Largo
Largo: Salut Christophe ! Je suis ravi de faire ta connaissance...

User: Recherche l'entreprise SIREN 123456789
Largo: Je vais rechercher cette entreprise pour toi...
[Tool: search_company invoked]
Largo: Voici ce que j'ai trouvé : [résultat]
```

Si vous voyez ce flux sans erreur 400, c'est que tout fonctionne !

---

*Guide de dépannage pour erreur 400 dans Flowise*
