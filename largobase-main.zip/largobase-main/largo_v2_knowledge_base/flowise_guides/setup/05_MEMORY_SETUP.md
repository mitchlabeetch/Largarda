# Configuration de la Mémoire pour Largo

> **Objectif** : Mettre en place la mémoire conversationnelle et persistante  
> **Temps estimé** : 20-30 minutes  
> **Fichiers de référence** : `flowise_kb/memory/*.json`

---

## Vue d'ensemble

Largo utilise trois types de mémoire :

1. **Buffer Memory** : Court terme, session uniquement
2. **Zep Memory** : Long terme, persistante avec résumés
3. **Vector Memory** : Stockage structuré des préférences et faits

---

## Étape 1 : Buffer Memory (Court Terme)

### Configuration dans le Chatflow

1. Ajouter un node **Buffer Window Memory**
2. Configuration :
   ```json
   {
     "memoryKey": "chat_history",
     "inputKey": "input",
     "outputKey": "output",
     "k": 10,
     "returnMessages": true
   }
   ```

### Explication

- `k: 10` → Conserve les 10 derniers échanges
- `returnMessages: true` → Retourne les messages formatés
- Scope : Session uniquement (perdu au redémarrage)

---

## Étape 2 : Zep Memory (Long Terme)

### 2.1 Installation de Zep

```yaml
# docker-compose.yml
services:
  zep:
    image: zepai/zep:latest
    ports:
      - "8000:8000"
    environment:
      - ZEP_STORE_TYPE=postgres
      - ZEP_STORE_POSTGRES_DSN=postgres://zep:zep@postgres:5432/zep?sslmode=disable
      - ZEP_OPENAI_API_KEY=${OPENAI_API_KEY}
      - ZEP_AUTH_SECRET=votre_secret
    depends_on:
      - postgres
```

### 2.2 Configuration dans Flowise

1. Créer un credential **Zep Memory**
2. API URL : `http://localhost:8000`
3. API Key : (laisser vide si pas d'auth)

### 2.3 Ajouter au Chatflow

1. Node **Zep Memory**
2. Configuration :
   ```json
   {
     "baseURL": "http://localhost:8000",
     "sessionId": "{{sessionId}}",
     "memoryKey": "chat_history",
     "returnMessages": true,
     "autoSummary": true
   }
   ```

### 2.4 Fonctionnalités de Zep

- **Résumés automatiques** : Compresse l'historique
- **Extraction d'entités** : Identifie les personnes, entreprises
- **Classification d'intentions** : Comprend les objectifs
- **Recherche sémantique** : Trouve des conversations passées

---

## Étape 3 : Vector Memory (Préférences et Faits)

### 3.1 Structure des données

```json
{
  "preferences": {
    "communication_style": "jovial",
    "preferred_name": "Chris",
    "reporting_time": "08:00",
    "sectors_of_interest": ["tech", "industrie"]
  },
  "deals": {
    "deal_001": {
      "company": "TechCorp",
      "status": "due_diligence",
      "last_contact": "2026-03-15"
    }
  },
  "contacts": {
    "contact_001": {
      "name": "Jean Dupont",
      "company": "InvestCorp",
      "role": "Investment Director"
    }
  }
}
```

### 3.2 Configuration du Vector Store

1. Créer un index dédié : `largo-memory`
2. Namespace : `user_preferences`

### 3.3 Tools de mémoire

Créer les tools `save_memory` et `get_memory` (voir guide 03)

---

## Étape 4 : Intégration dans le System Prompt

Ajouter au system prompt :

```markdown
## Mémoire
Tu as accès à trois types de mémoire :

1. **Mémoire de session** : Les échanges récents de cette conversation
2. **Mémoire persistante** : L'historique complet avec Zep
3. **Mémoire vectorielle** : Les préférences et faits importants

Quand Christophe exprime une préférence :
- Utilise save_memory pour l'enregistrer
- Confirme : "C'est noté, j'appliquerai ça"
- Applique-la automatiquement par la suite

Quand tu as besoin d'informations passées :
- Utilise get_memory pour récupérer les données
- Cite la source si pertinent
```

---

## Étape 5 : Exemples d'utilisation

### Sauvegarder une préférence

**Christophe** : "Appelle-moi Chris à partir de maintenant"

**Largo** :
1. Invoque `save_memory`
   ```json
   {
     "key": "preferred_name",
     "value": "Chris",
     "category": "preference",
     "context": "Christophe préfère être appelé Chris"
   }
   ```
2. Répond : "C'est noté Chris ! Je m'en souviendrai."

### Récupérer une information

**Christophe** : "Quel était le statut du deal TechCorp ?"

**Largo** :
1. Invoque `get_memory`
   ```json
   {
     "query": "deal TechCorp status"
   }
   ```
2. Répond : "Le deal TechCorp est en phase de due diligence. Dernier contact le 15 mars."

---

## Étape 6 : Stockage des Conversations

### 6.1 Table PostgreSQL

```sql
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id VARCHAR(100),
    user_id VARCHAR(100) DEFAULT 'christophe.berthon',
    message_role VARCHAR(20),
    message_content TEXT,
    tools_used JSONB,
    rag_sources JSONB,
    timestamp TIMESTAMP DEFAULT NOW(),
    metadata JSONB
);

CREATE INDEX idx_conversations_user ON conversations(user_id);
CREATE INDEX idx_conversations_session ON conversations(session_id);
CREATE INDEX idx_conversations_timestamp ON conversations(timestamp);
```

### 6.2 Callback pour sauvegarder

Dans le Chatflow, ajouter un callback :

```javascript
{
  "name": "onChainEnd",
  "handler": `
    const { Pool } = require('pg');
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    await pool.query(
      'INSERT INTO conversations (session_id, message_role, message_content) VALUES ($1, $2, $3)',
      [sessionId, 'assistant', output]
    );
  `
}
```

---

## Étape 7 : Test de la Mémoire

### Test 1 : Préférence

1. **Christophe** : "Appelle-moi Chris"
2. **Largo** : "C'est noté Chris !"
3. **Christophe** : (nouvelle conversation) "Salut Largo"
4. **Largo** : "Salut Chris !" (doit utiliser le prénom préféré)

### Test 2 : Deal

1. **Christophe** : "Note que le deal TechCorp passe en DD"
2. **Largo** : Sauvegarde en mémoire
3. (Plus tard) **Christophe** : "Où en est le deal TechCorp ?"
4. **Largo** : Récupère et répond avec le statut

### Test 3 : Contexte conversationnel

1. **Christophe** : "Parle-moi de l'entreprise SIREN 123"
2. **Largo** : Fournit les infos
3. **Christophe** : "Et sa valorisation ?"
4. **Largo** : Doit comprendre qu'il parle de la même entreprise

---

## Troubleshooting

| Problème | Solution |
|----------|----------|
| Mémoire non persistante | Vérifier que Zep est bien configuré |
| Préférences oubliées | Vérifier le tool save_memory |
| Contexte perdu | Augmenter k dans Buffer Memory |
| Zep ne démarre pas | Vérifier la connexion PostgreSQL |

---

*Guide de configuration de la mémoire pour Largo*
