# Gestion des Uploads de Documents

> **Objectif** : Permettre à Largo de recevoir et traiter des documents uploadés  
> **Temps estimé** : 20-30 minutes

---

## Vue d'ensemble

Largo doit pouvoir recevoir des documents via :
- Interface chat (drag & drop)
- API directe
- WhatsApp (photos de documents)
- Email (pièces jointes)

---

## Étape 1 : Configuration du File Upload dans Flowise

### 1.1 Node File Upload

Dans le chatflow, ajouter un node **File Upload** :

```
[File Upload] → [Document Parser] → [Vector Store] → [Response]
```

Configuration :
- **Accepted Types** : `.pdf`, `.docx`, `.xlsx`, `.csv`, `.txt`, `.png`, `.jpg`
- **Max Size** : `20MB`
- **Multiple Files** : `true`

### 1.2 Node Document Parser

Créer un tool `parse_document` :

```javascript
const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

const parseDocument = async (file_path, file_type) => {
    const form = new FormData();
    form.append('file', fs.createReadStream(file_path));
    form.append('file_type', file_type);
    
    const response = await fetch('http://localhost:8004/api/parse', {
        method: 'POST',
        body: form
    });
    
    return await response.json();
};

const result = await parseDocument($file_path, $file_type);
return JSON.stringify(result);
```

---

## Étape 2 : Traitement selon le Type de Document

### 2.1 PDF (Information Memorandum, Rapports)

**Use case** : Christophe upload un IM pour analyse

```javascript
const processPDF = async (file) => {
    // 1. Parser le PDF
    const parsed = await parseDocument(file.path, 'pdf');
    
    // 2. Extraire les informations clés
    const extraction = await extractKeyInfo(parsed.text);
    
    // 3. Sauvegarder dans le vector store (optionnel)
    await upsertToVectorStore(parsed.text, {
        source: file.name,
        category: 'im',
        deal_id: extractDealId(file.name)
    });
    
    // 4. Retourner la synthèse
    return {
        document_type: 'IM',
        company_name: extraction.company_name,
        revenue: extraction.revenue,
        ebitda: extraction.ebitda,
        sector: extraction.sector,
        summary: extraction.summary,
        key_points: extraction.key_points,
        questions: extraction.questions_to_ask
    };
};
```

### 2.2 Excel (Listes de prospects, Données financières)

```javascript
const processExcel = async (file) => {
    const parsed = await parseDocument(file.path, 'xlsx');
    
    // Analyser la structure
    const analysis = {
        sheets: parsed.sheets,
        row_count: parsed.row_count,
        columns: parsed.columns,
        data_type: inferDataType(parsed)
    };
    
    // Si liste de prospects
    if (analysis.data_type === 'prospect_list') {
        const prospects = extractProspects(parsed);
        return {
            type: 'prospect_list',
            count: prospects.length,
            prospects: prospects,
            action: 'Enrichir ces prospects ?'
        };
    }
    
    // Si données financières
    if (analysis.data_type === 'financial_data') {
        const financials = extractFinancials(parsed);
        return {
            type: 'financial_data',
            years: financials.years,
            metrics: financials.metrics,
            action: 'Analyser ces données ?'
        };
    }
};
```

### 2.3 Images (OCR de documents)

```javascript
const processImage = async (file) => {
    // OCR via le document-parser
    const parsed = await parseDocument(file.path, 'image');
    
    return {
        text_extracted: parsed.text,
        confidence: parsed.ocr_confidence,
        language: parsed.language,
        summary: parsed.text.substring(0, 500) + '...'
    };
};
```

---

## Étape 3 : Intégration dans le Chatflow

### 3.1 Modifier le System Prompt

```markdown
## Gestion des Documents Uploadés

Quand Christophe upload un document :

1. Identifier le type de document
2. Parser et extraire le contenu
3. Analyser selon le type :
   - PDF : Extraire infos clés, proposer analyse
   - Excel : Identifier le type de données, proposer action
   - Image : OCR, extraire le texte
4. Demander confirmation avant d'indexer dans le RAG
5. Proposer les prochaines étapes

Exemples de réponses :
- "J'ai reçu un IM pour TechCorp. CA: 5M€, EBITDA: 1M€. Veux-tu que je l'analyse en détail ?"
- "Liste de 45 prospects reçue. Je peux les enrichir automatiquement."
- "Document scanné traité. J'ai extrait le texte avec 95% de confiance."
```

### 3.2 Ajouter le File Upload Node

Dans le chatflow principal :

```
[Start] → [System Message] → [Chat Model] → [Tools]
                ↑
         [File Upload] → [Document Parser]
```

Connecter le File Upload au Chat Model pour que l'agent soit informé des uploads.

---

## Étape 4 : API pour Upload Externe

### 4.1 Endpoint d'upload

```javascript
// Express.js endpoint
app.post('/api/upload', async (req, res) => {
    const { file, metadata } = req.body;
    
    // Forward to Flowise
    const flowiseResponse = await fetch(
        'http://localhost:3000/api/v1/chatflows/largo-main/predict',
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question: `Document uploadé: ${metadata.filename}`,
                overrideConfig: {
                    uploads: [{
                        data: file,
                        name: metadata.filename,
                        type: metadata.mimetype
                    }]
                }
            })
        }
    );
    
    const result = await flowiseResponse.json();
    res.json(result);
});
```

### 4.2 Webhook WhatsApp

```javascript
// Quand une image est reçue sur WhatsApp
app.post('/webhook/whatsapp', async (req, res) => {
    const { message, media_url } = req.body;
    
    if (media_url) {
        // Télécharger l'image
        const image = await downloadImage(media_url);
        
        // Forward à Flowise
        await forwardToFlowise(image, {
            source: 'whatsapp',
            caption: message.caption
        });
    }
});
```

---

## Étape 5 : Stockage des Documents

### 5.1 Structure de stockage

```
/largo_uploads/
├── 2026/
│   ├── 03/
│   │   ├── 18/
│   │   │   ├── im_techcorp_20260318.pdf
│   │   │   ├── prospects_q1.xlsx
│   │   │   └── scan_contrat.jpg
│   │   └── 19/
│   └── 04/
└── index.json  # Index des documents
```

### 5.2 Métadonnées

```json
{
  "document_id": "doc_123",
  "filename": "im_techcorp.pdf",
  "original_name": "IM TechCorp v2.pdf",
  "uploaded_at": "2026-03-18T10:30:00Z",
  "uploaded_by": "christophe.berthon",
  "source": "chat",
  "size_bytes": 2457600,
  "mime_type": "application/pdf",
  "parsed": true,
  "indexed_in_rag": false,
  "tags": ["im", "techcorp", "deal_001"],
  "extracted_data": {
    "company_name": "TechCorp",
    "revenue": "5M€",
    "ebitda": "1M€"
  }
}
```

---

## Étape 6 : Workflows d'Upload

### Workflow 1 : IM Uploadé

1. Christophe upload un IM
2. Largo parse le PDF
3. Extrait les données clés
4. Propose : "Veux-tu que je crée une fiche entreprise ?"
5. Si oui → Délègue à Document Agent
6. Sauvegarde dans le deal tracker

### Workflow 2 : Liste de Prospects

1. Christophe upload un Excel
2. Largo identifie comme liste de prospects
3. Compte les lignes
4. Propose : "Je peux enrichir ces X prospects. Lancer ?"
5. Si oui → Délègue à Prospect Agent
6. Envoie notification quand terminé

### Workflow 3 : Document Scanné

1. Christophe envoie une photo via WhatsApp
2. Largo fait l'OCR
3. Affiche le texte extrait
4. Demande : "Veux-tu que je l'indexe dans le RAG ?"
5. Si oui → Upsert dans le vector store

---

*Guide de gestion des uploads pour Largo*
