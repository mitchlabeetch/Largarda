# Guide d'Installation Flowise pour Largo

> **Objectif** : Installer et configurer Flowise pour Largo 2.0  
> **Temps estimé** : 30-45 minutes  
> **Prérequis** : Docker, Node.js 18+

---

## 1. Installation de Flowise

### Option A : Via Docker (Recommandé)

```bash
# Créer le répertoire
mkdir -p ~/flowise && cd ~/flowise

# Créer le docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  flowise:
    image: flowiseai/flowise:latest
    restart: always
    environment:
      - PORT=3000
      - FLOWISE_USERNAME=admin
      - FLOWISE_PASSWORD=changeme
      - DATABASE_PATH=/root/.flowise
      - APIKEY_PATH=/root/.flowise
      - LOG_PATH=/root/.flowise/logs
      - BLOB_STORAGE_PATH=/root/.flowise/storage
    ports:
      - "3000:3000"
    volumes:
      - ~/.flowise:/root/.flowise
    networks:
      - flowise-network

  # Base de données pour les conversations
  postgres:
    image: postgres:15-alpine
    restart: always
    environment:
      - POSTGRES_USER=flowise
      - POSTGRES_PASSWORD=flowise_password
      - POSTGRES_DB=flowise_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    networks:
      - flowise-network

  # Vector Store (optionnel - peut utiliser Pinecone en cloud)
  # pinecone-local:
  #   image: ...

volumes:
  postgres_data:

networks:
  flowise-network:
    driver: bridge
EOF

# Lancer Flowise
docker-compose up -d

# Vérifier l'installation
curl http://localhost:3000/api/v1/health
```

### Option B : Via NPM

```bash
# Installer globalement
npm install -g flowise

# Lancer
npx flowise start

# Ou avec options
npx flowise start --PORT=3000 --FLOWISE_USERNAME=admin --FLOWISE_PASSWORD=changeme
```

---

## 2. Configuration Initiale

### 2.1 Premier accès

1. Ouvrir `http://localhost:3000`
2. Se connecter avec les credentials définis
3. Changer le mot de passe immédiatement

### 2.2 Configuration des Credentials

Dans Flowise, aller dans **Credentials** et ajouter :

| Credential | Type | Description |
|------------|------|-------------|
| `openai` | Chat Model | GPT-4 / GPT-4o |
| `anthropic` | Chat Model | Claude 3.5 Sonnet |
| `moonshot` | Chat Model | Kimi API |
| `pinecone` | Vector Store | Base de connaissances |
| `zep` | Memory | Mémoire persistante |

---

## 3. Structure des Répertoires

```
~/flowise/
├── docker-compose.yml
├── .env                    # Variables d'environnement
├── data/
│   ├── flows/             # Export des flows
│   ├── tools/             # Custom tools
│   ├── documents/         # Documents uploadés
│   └── backups/           # Sauvegardes
├── services/              # Microservices Largo
│   ├── mna-research/
│   ├── document-generator/
│   ├── memory-service/
│   └── notification-service/
└── logs/
```

---

## 4. Configuration des Variables d'Environnement

Créer le fichier `.env` :

```bash
# Flowise
PORT=3000
FLOWISE_USERNAME=admin
FLOWISE_PASSWORD=votre_mot_de_passe_securise

# Base de données
DATABASE_PATH=/root/.flowise
DATABASE_TYPE=postgres
DATABASE_HOST=postgres
DATABASE_PORT=5432
DATABASE_NAME=flowise_db
DATABASE_USER=flowise
DATABASE_PASSWORD=flowise_password

# API Keys
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
MOONSHOT_API_KEY=...
PINECONE_API_KEY=...
PINECONE_INDEX_NAME=largo-kb
ZEP_API_KEY=...

# Microservices
MNA_RESEARCH_URL=http://localhost:8001
DOCUMENT_GENERATOR_URL=http://localhost:8002
MEMORY_SERVICE_URL=http://localhost:8006
NOTIFICATION_SERVICE_URL=http://localhost:8008

# Sécurité
JWT_SECRET=votre_secret_jwt
ENCRYPTION_KEY=votre_cle_chiffrement
```

---

## 5. Vérification de l'Installation

### Test de santé

```bash
# Test API
curl http://localhost:3000/api/v1/ping

# Test auth
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"votre_mot_de_passe"}'
```

### Logs

```bash
# Voir les logs
docker-compose logs -f flowise

# Logs spécifiques
docker-compose logs -f flowise 2>&1 | grep ERROR
```

---

## 6. Mise à jour

```bash
cd ~/flowise

# Arrêter les services
docker-compose down

# Mettre à jour l'image
docker pull flowiseai/flowise:latest

# Redémarrer
docker-compose up -d
```

---

## 7. Sauvegarde et Restauration

### Sauvegarde

```bash
# Sauvegarder les flows
curl http://localhost:3000/api/v1/flows/export > backup_flows.json

# Sauvegarder la base de données
docker exec flowise_postgres_1 pg_dump -U flowise flowise_db > backup_db.sql

# Sauvegarder les credentials
cp ~/.flowise/credentials backup_credentials/
```

### Restauration

```bash
# Restaurer les flows
curl -X POST http://localhost:3000/api/v1/flows/import \
  -H "Content-Type: application/json" \
  -d @backup_flows.json

# Restaurer la base de données
docker exec -i flowise_postgres_1 psql -U flowise flowise_db < backup_db.sql
```

---

## Prochaines étapes

1. [Créer le Chatflow principal](02_MAIN_CHATFLOW.md)
2. [Configurer les Custom Tools](03_CUSTOM_TOOLS.md)
3. [Mettre en place le RAG](04_RAG_SETUP.md)
4. [Configurer la mémoire](05_MEMORY_SETUP.md)

---

*Guide d'installation Flowise pour Largo 2.0*
