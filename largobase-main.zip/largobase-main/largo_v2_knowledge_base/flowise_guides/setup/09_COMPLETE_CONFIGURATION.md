# Configuration Complète de Largo dans Flowise

> **Objectif** : Configurer tous les composants Flowise avec les free tiers les plus généreux  
> **Budget cible** : 0€ (100% free tier)  
> **Temps estimé** : 2-3 heures

---

## 📋 Vue d'ensemble des Composants

```
Flowise Configuration
├── 1. Chat Models (LLM)
├── 2. Vector Stores (RAG)
├── 3. Document Loaders
├── 4. Tools (Custom + Built-in)
├── 5. Memory
├── 6. Embeddings
├── 7. Cache
└── 8. Credentials
```

---

## 1. CHAT MODELS (LLM)

### Option 1 : Groq (RECOMMANDÉ - Free Tier Généreux)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT |
| **Limite** | 20 requêtes/minute, 1M tokens/jour |
| **Modèles** | Llama 3.3 70B, Mixtral 8x7B, Gemma 2 |
| **Latence** | Ultra-rapide (< 100ms) |

#### Setup API Groq

1. Créer un compte : [console.groq.com](https://console.groq.com)
2. Générer une API key
3. Dans Flowise : **Credentials** → **Add Credential**
   - Credential Type : `Groq API`
   - API Key : `gsk_votre_cle_ici`

#### Configuration dans Flowise

```json
{
  "modelName": "llama-3.3-70b-versatile",
  "temperature": 0.7,
  "maxTokens": 4096,
  "topP": 0.9,
  "apiKey": "{{groqApiKey}}"
}
```

#### Modèles disponibles (Free Tier)

| Modèle | Contexte | Use Case |
|--------|----------|----------|
| `llama-3.3-70b-versatile` | 128K | Général, recommandé |
| `mixtral-8x7b-32768` | 32K | Rapide, économique |
| `gemma-2-9b-it` | 8K | Tâches simples |
| `llama-3.1-8b-instant` | 128K | Ultra-rapide |

---

### Option 2 : Ollama (100% Gratuit - Local)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT (local) |
| **Limite** | Aucune (limitée par votre hardware) |
| **Modèles** | Llama, Mistral, CodeLlama, etc. |
| **Latence** | Dépend du GPU/CPU |

#### Setup Ollama

```bash
# 1. Installer Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. Démarrer le serveur
ollama serve

# 3. Pull les modèles
ollama pull llama3.2:70b
ollama pull mistral:7b
ollama pull codellama:13b

# 4. Vérifier
ollama list
```

#### Configuration dans Flowise

```json
{
  "baseUrl": "http://localhost:11434",
  "modelName": "llama3.2:70b",
  "temperature": 0.7,
  "numPredict": 4096
}
```

#### Modèles recommandés pour M&A

| Modèle | Taille | RAM nécessaire | Use Case |
|--------|--------|----------------|----------|
| `llama3.2:70b` | 70B | 48GB | Recommandé |
| `mistral:7b` | 7B | 8GB | Rapide, économique |
| `codellama:13b` | 13B | 12GB | Analyse financière |
| `mixtral:8x7b` | 47B | 32GB | Haute qualité |

---

### Option 3 : OpenRouter (Free Tier)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT (limite généreuse) |
| **Limite** | 200 requêtes/jour |
| **Modèles** | 100+ modèles (Claude, GPT, Llama, etc.) |

#### Setup API OpenRouter

1. Créer un compte : [openrouter.ai](https://openrouter.ai)
2. Générer une API key
3. Dans Flowise : **Credentials** → **Add Credential**
   - Credential Type : `OpenRouter API`
   - API Key : `sk-or-v1-votre_cle_ici`

#### Configuration dans Flowise

```json
{
  "modelName": "anthropic/claude-3.5-sonnet",
  "temperature": 0.7,
  "maxTokens": 4096,
  "apiKey": "{{openrouterApiKey}}"
}
```

#### Modèles gratuits recommandés

| Modèle | Provider | Contexte |
|--------|----------|----------|
| `anthropic/claude-3.5-sonnet` | Anthropic | 200K |
| `meta-llama/llama-3.3-70b-instruct` | Meta | 128K |
| `google/gemini-pro` | Google | 32K |
| `mistralai/mixtral-8x7b-instruct` | Mistral | 32K |

---

### Option 4 : Kimi (Moonshot) - Free Tier

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT (crédits de démarrage) |
| **Limite** | 1M tokens gratuits |
| **Modèles** | Kimi K2 (2M contexte !) |

#### Setup API Kimi

1. Créer un compte : [platform.moonshot.cn](https://platform.moonshot.cn)
2. Générer une API key
3. Dans Flowise : **Credentials** → **Add Credential**
   - Credential Type : `Moonshot API`
   - API Key : `sk-votre_cle_ici`

#### Configuration dans Flowise

```json
{
  "modelName": "kimi-k2-07132k-preview",
  "temperature": 0.7,
  "maxTokens": 4096,
  "apiKey": "{{moonshotApiKey}}"
}
```

---

### Option 5 : Google AI Studio (Free Tier)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT |
| **Limite** | 60 requêtes/minute |
| **Modèles** | Gemini Pro, Flash |

#### Setup API Google

1. Créer un compte : [aistudio.google.com](https://aistudio.google.com)
2. Générer une API key
3. Dans Flowise : **Credentials** → **Add Credential**
   - Credential Type : `Google Generative AI`
   - API Key : `AIza...votre_cle_ici`

#### Configuration dans Flowise

```json
{
  "modelName": "gemini-1.5-pro-latest",
  "temperature": 0.7,
  "maxOutputTokens": 4096,
  "apiKey": "{{googleApiKey}}"
}
```

---

## 2. VECTOR STORES (RAG)

### Option 1 : Chroma (100% Gratuit - Self-hosted)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT |
| **Hébergement** | Local/Docker |
| **Limite** | Aucune (limitée par disque) |

#### Setup Chroma

```yaml
# docker-compose.yml
services:
  chroma:
    image: chromadb/chroma:latest
    ports:
      - "8000:8000"
    volumes:
      - chroma_data:/chroma/chroma
    environment:
      - IS_PERSISTENT=TRUE
      - PERSIST_DIRECTORY=/chroma/chroma
      - ANONYMIZED_TELEMETRY=FALSE

volumes:
  chroma_data:
```

```bash
# Démarrer
docker-compose up -d chroma

# Vérifier
curl http://localhost:8000/api/v1/heartbeat
```

#### Configuration dans Flowise

```json
{
  "vectorStoreType": "chroma",
  "chromaMetadata": {
    "collectionName": "largo-knowledge-base",
    "url": "http://localhost:8000"
  }
}
```

---

### Option 2 : Pinecone (Free Tier)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT |
| **Limite** | 1 index, 100K vecteurs, 2GB stockage |
| **Durée** | Illimitée (pas de time limit) |

#### Setup Pinecone

1. Créer un compte : [pinecone.io](https://pinecone.io)
2. Générer une API key
3. Créer un index :
   - Name : `largo-kb`
   - Dimensions : `3072` (pour text-embedding-3-large)
   - Metric : `cosine`
   - Pod Type : `starter` (gratuit)

#### Configuration dans Flowise

```json
{
  "vectorStoreType": "pinecone",
  "pineconeIndex": "largo-kb",
  "pineconeNamespace": "",
  "pineconeApiKey": "{{pineconeApiKey}}",
  "pineconeEnvironment": "us-east-1-aws"
}
```

---

### Option 3 : Qdrant (Self-hosted - Gratuit)

```yaml
# docker-compose.yml
services:
  qdrant:
    image: qdrant/qdrant:latest
    ports:
      - "6333:6333"
    volumes:
      - qdrant_data:/qdrant/storage

volumes:
  qdrant_data:
```

#### Configuration dans Flowise

```json
{
  "vectorStoreType": "qdrant",
  "qdrantUrl": "http://localhost:6333",
  "qdrantCollection": "largo-kb"
}
```

---

## 3. EMBEDDINGS

### Option 1 : Ollama Embeddings (100% Gratuit)

```bash
# Pull un modèle d'embedding
ollama pull nomic-embed-text
ollama pull mxbai-embed-large
```

#### Configuration dans Flowise

```json
{
  "embeddingType": "ollama",
  "ollamaBaseUrl": "http://localhost:11434",
  "ollamaModel": "nomic-embed-text"
}
```

**Dimensions** : 768 (nomic) ou 1024 (mxbai)

---

### Option 2 : HuggingFace (Free Tier)

| Caractéristique | Valeur |
|-----------------|--------|
| **Prix** | GRATUIT |
| **Limite** | 30K requêtes/jour |

#### Setup HuggingFace

1. Créer un compte : [huggingface.co](https://huggingface.co)
2. Générer un token : Settings → Access Tokens
3. Dans Flowise : **Credentials** → **Add Credential**

#### Configuration dans Flowise

```json
{
  "embeddingType": "huggingface",
  "model": "sentence-transformers/all-MiniLM-L6-v2",
  "apiKey": "{{huggingfaceApiKey}}"
}
```

**Modèles recommandés** :
- `sentence-transformers/all-MiniLM-L6-v2` (384 dim, rapide)
- `sentence-transformers/all-mpnet-base-v2` (768 dim, meilleure qualité)
- `BAAI/bge-large-en-v1.5` (1024 dim, haute qualité)

---

### Option 3 : Google Embeddings (Free Tier)

```json
{
  "embeddingType": "google",
  "model": "models/embedding-001",
  "apiKey": "{{googleApiKey}}"
}
```

---

## 4. DOCUMENT LOADERS

### Configuration PDF Loader

```json
{
  "loaderType": "pdfFile",
  "pdfUsage": "perFile",
  "metadata": {
    "source": "{{fileName}}",
    "category": "{{category}}",
    "uploaded_at": "{{timestamp}}"
  }
}
```

### Configuration DOCX Loader

```json
{
  "loaderType": "docxFile",
  "metadata": {
    "source": "{{fileName}}",
    "category": "{{category}}"
  }
}
```

### Configuration CSV Loader

```json
{
  "loaderType": "csvFile",
  "csvColumnName": "content",
  "metadata": {
    "source": "{{fileName}}",
    "type": "prospect_list"
  }
}
```

---

## 5. TEXT SPLITTERS

### Recursive Character Text Splitter (Recommandé)

```json
{
  "splitterType": "recursive",
  "chunkSize": 1000,
  "chunkOverlap": 200,
  "separators": ["\n\n", "\n", ".", "!", "?", " ", ""]
}
```

### Token Text Splitter

```json
{
  "splitterType": "token",
  "chunkSize": 500,
  "chunkOverlap": 50,
  "encodingName": "cl100k_base"
}
```

---

## 6. MEMORY

### Buffer Window Memory

```json
{
  "memoryType": "bufferWindow",
  "memoryKey": "chat_history",
  "k": 10,
  "inputKey": "input",
  "outputKey": "output",
  "returnMessages": true
}
```

### Zep Memory (Self-hosted - Gratuit)

```yaml
# docker-compose.yml
services:
  zep:
    image: zepai/zep:latest
    ports:
      - "8000:8000"
    environment:
      - ZEP_STORE_TYPE=postgres
      - ZEP_STORE_POSTGRES_DSN=postgres://zep:zep@postgres:5432/zep?sslmode=disable
      - ZEP_OPENAI_API_KEY=${OPENAI_API_KEY}
      - ZEP_AUTH_SECRET=votre_secret
```

```json
{
  "memoryType": "zep",
  "baseURL": "http://localhost:8000",
  "sessionId": "{{sessionId}}",
  "memoryKey": "chat_history",
  "returnMessages": true,
  "autoSummary": true
}
```

---

## 7. TOOLS BUILT-IN (Free)

### Web Search

| Provider | Free Tier | Setup |
|----------|-----------|-------|
| **DuckDuckGo** | Illimité | Aucune API key |
| **SerpAPI** | 100 requêtes/mois | API key gratuite |
| **Brave Search** | 2000 requêtes/mois | API key gratuite |

#### Configuration DuckDuckGo

```json
{
  "toolName": "web_search",
  "provider": "duckduckgo",
  "maxResults": 5
}
```

#### Configuration Brave Search

1. Créer un compte : [brave.com/search/api](https://brave.com/search/api)
2. Générer une API key (2000 requêtes/mois gratuites)

```json
{
  "toolName": "web_search",
  "provider": "brave",
  "apiKey": "{{braveApiKey}}",
  "maxResults": 5
}
```

---

### Calculator

```json
{
  "toolName": "calculator",
  "description": "Effectue des calculs mathématiques pour les valorisations"
}
```

---

### Custom Tools (à créer)

Voir le fichier `flowise_kb/tools/` pour les 11 tools M&A personnalisés.

---

## 8. CREDENTIALS - Récapitulatif

### Credentials à créer dans Flowise

| Nom | Type | Provider | Free Tier |
|-----|------|----------|-----------|
| `groqApi` | Chat Model | Groq | 1M tokens/jour |
| `ollamaApi` | Chat Model | Ollama | Illimité (local) |
| `openrouterApi` | Chat Model | OpenRouter | 200 req/jour |
| `moonshotApi` | Chat Model | Kimi | 1M tokens |
| `googleApi` | Chat Model | Google | 60 req/min |
| `pineconeApi` | Vector Store | Pinecone | 100K vecteurs |
| `huggingfaceApi` | Embeddings | HuggingFace | 30K req/jour |
| `braveApi` | Web Search | Brave | 2000 req/mois |
| `zepApi` | Memory | Zep | Self-hosted |

---

## 9. CHATFLOW COMPLET - Configuration Finale

### Node 1 : Start

Type : `Start`  
Configuration : Défaut

### Node 2 : System Message

Type : `SystemMessage`  
Contenu : Copier depuis `flowise_kb/prompts/SYSTEM_PROMPT.md`

### Node 3 : Chat Model

Type : `ChatModel`  
Configuration :
```json
{
  "modelName": "llama-3.3-70b-versatile",
  "temperature": 0.7,
  "maxTokens": 4096,
  "credential": "groqApi"
}
```

### Node 4 : Buffer Memory

Type : `BufferWindowMemory`  
Configuration :
```json
{
  "memoryKey": "chat_history",
  "k": 10,
  "returnMessages": true
}
```

### Node 5 : Vector Store Retriever

Type : `VectorStoreRetriever`  
Configuration :
```json
{
  "vectorStoreType": "chroma",
  "chromaUrl": "http://localhost:8000",
  "collectionName": "largo-kb",
  "topK": 5
}
```

### Node 6 : Tools

Type : `ToolNode`  
Tools à ajouter :
- search_company
- get_valuation
- web_search
- save_memory
- get_memory
- query_rag
- generate_document
- send_notification

### Node 7 : End

Type : `End`  
Configuration : Défaut

---

## 10. DOCKER COMPOSE COMPLET

```yaml
version: '3.8'

services:
  # Flowise
  flowise:
    image: flowiseai/flowise:latest
    ports:
      - "3000:3000"
    environment:
      - PORT=3000
      - FLOWISE_USERNAME=admin
      - FLOWISE_PASSWORD=changeme
      - DATABASE_PATH=/root/.flowise
      - APIKEY_PATH=/root/.flowise
    volumes:
      - ~/.flowise:/root/.flowise
    depends_on:
      - postgres
      - chroma
    networks:
      - largo-network

  # PostgreSQL
  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_USER=flowise
      - POSTGRES_PASSWORD=flowise_password
      - POSTGRES_DB=flowise_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - largo-network

  # Chroma (Vector Store - Gratuit)
  chroma:
    image: chromadb/chroma:latest
    ports:
      - "8000:8000"
    volumes:
      - chroma_data:/chroma/chroma
    environment:
      - IS_PERSISTENT=TRUE
      - ANONYMIZED_TELEMETRY=FALSE
    networks:
      - largo-network

  # Ollama (LLM Local - Gratuit)
  ollama:
    image: ollama/ollama:latest
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    networks:
      - largo-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]

  # Microservices Largo
  mna-research:
    build: ./services/mna-research
    ports:
      - "8001:8000"
    networks:
      - largo-network

  pptx-generator:
    build: ./services/pptx-generator
    ports:
      - "8002:8000"
    networks:
      - largo-network

  document-parser:
    build: ./services/document-parser
    ports:
      - "8004:8000"
    networks:
      - largo-network

volumes:
  postgres_data:
  chroma_data:
  ollama_data:

networks:
  largo-network:
    driver: bridge
```

---

## 11. ENVIRONMENT VARIABLES

Créer un fichier `.env` :

```bash
# Flowise
FLOWISE_USERNAME=admin
FLOWISE_PASSWORD=votre_mot_de_passe_securise

# APIs (Free Tiers)
GROQ_API_KEY=gsk_votre_cle_groq
OPENROUTER_API_KEY=sk-or-v1-votre_cle_openrouter
MOONSHOT_API_KEY=sk-votre_cle_moonshot
GOOGLE_API_KEY=AIza...votre_cle_google
HUGGINGFACE_API_KEY=hf_votre_token
BRAVE_API_KEY=BS...votre_cle_brave

# Vector Store (optionnel si Chroma local)
PINECONE_API_KEY=pcsk_votre_cle_pinecone
PINECONE_INDEX=largo-kb

# Database
DATABASE_URL=postgresql://flowise:flowise_password@localhost:5432/flowise_db

# Microservices
MNA_RESEARCH_URL=http://localhost:8001
PPTX_GENERATOR_URL=http://localhost:8002
DOCUMENT_PARSER_URL=http://localhost:8004
```

---

## 12. COMMANDES DE DÉMARRAGE

```bash
# 1. Démarrer tous les services
docker-compose up -d

# 2. Pull les modèles Ollama
docker-compose exec ollama ollama pull llama3.2:70b
docker-compose exec ollama ollama pull nomic-embed-text

# 3. Vérifier les services
curl http://localhost:3000/api/v1/health
curl http://localhost:8000/api/v1/heartbeat
curl http://localhost:11434/api/tags

# 4. Ouvrir Flowise
open http://localhost:3000
```

---

## 13. RÉCAPITULATIF DES FREE TIERS

| Service | Free Tier | Limite | Durée |
|---------|-----------|--------|-------|
| **Groq** | 1M tokens/jour | 20 req/min | Illimité |
| **Ollama** | Illimité | Hardware | Illimité |
| **OpenRouter** | 200 req/jour | - | Illimité |
| **Kimi** | 1M tokens | - | Illimité |
| **Google AI** | 60 req/min | - | Illimité |
| **Chroma** | Illimité | Disque | Illimité |
| **Pinecone** | 100K vecteurs | 2GB | Illimité |
| **HuggingFace** | 30K req/jour | - | Illimité |
| **DuckDuckGo** | Illimité | - | Illimité |
| **Brave Search** | 2000 req/mois | - | Illimité |

---

## 14. RECOMMANDATIONS PAR USE CASE

### Configuration Économique (0€)

| Composant | Solution |
|-----------|----------|
| LLM | Ollama (local) |
| Embeddings | Ollama (nomic-embed-text) |
| Vector Store | Chroma (local) |
| Web Search | DuckDuckGo |
| **Total** | **0€/mois** |

### Configuration Rapide (0€)

| Composant | Solution |
|-----------|----------|
| LLM | Groq (llama-3.3-70b) |
| Embeddings | HuggingFace |
| Vector Store | Pinecone (free) |
| Web Search | DuckDuckGo |
| **Total** | **0€/mois** |

### Configuration Haute Qualité (0€)

| Composant | Solution |
|-----------|----------|
| LLM | OpenRouter (Claude 3.5) |
| Embeddings | HuggingFace (bge-large) |
| Vector Store | Chroma (local) |
| Web Search | Brave Search |
| **Total** | **0€/mois** |

---

*Configuration complète Flowise pour Largo 2.0 — 100% Free Tier*
