# Configuration du RAG (Retrieval Augmented Generation)

> **Objectif** : Mettre en place la base de connaissances vectorielle pour Largo  
> **Temps estimé** : 30-45 minutes  
> **Fichiers de référence** : `flowise_kb/documents/knowledge_base_structure.json`

---

## Vue d'ensemble

Le RAG permet à Largo de :
- Rechercher dans les playbooks M&A
- Accéder aux mémos de deals
- Consulter la réglementation
- Retrouver les templates de documents

---

## Étape 1 : Choisir le Vector Store

### Option A : Pinecone (Recommandé - Cloud)

**Avantages** :
- Géré, pas de maintenance
- Performant
- Facile à scaler

**Inconvénients** :
- Coût (~70€/mois pour usage intensif)
- Dépendance externe

**Configuration** :

1. Créer un compte sur [pinecone.io](https://pinecone.io)
2. Créer un index :
   - Name : `largo-kb`
   - Dimensions : `3072` (pour text-embedding-3-large)
   - Metric : `cosine`
3. Copier la API key

### Option B : Chroma (Self-hosted)

**Avantages** :
- Gratuit
- Local, pas de dépendance externe

**Inconvénients** :
- À maintenir
- Moins performant à grande échelle

**Configuration avec Docker** :

```yaml
# docker-compose.yml
services:
  chroma:
    image: chromadb/chroma:latest
    ports:
      - "8000:8000"
    volumes:
      - chroma_data:/chroma/chroma
    environment:
      - IS_PERSISTENT=TRUE
```

### Option C : Qdrant (Self-hosted)

```yaml
services:
  qdrant:
    image: qdrant/qdrant:latest
    ports:
      - "6333:6333"
    volumes:
      - qdrant_data:/qdrant/storage
```

---

## Étape 2 : Configurer le Document Loader

### 2.1 Créer un Upsert Flow

1. Dans Flowise, créer un nouveau **"Upsert"** flow
2. Nommer : `Largo Knowledge Base Ingestion`

### 2.2 Ajouter les nodes

```
[File Loader] → [Text Splitter] → [Embedding] → [Vector Store]
```

#### Node File Loader

- Type : **File Loader**
- Supported Types : `pdf`, `docx`, `txt`, `csv`
- Multiple Files : `true`

#### Node Text Splitter

- Type : **Recursive Character Text Splitter**
- Chunk Size : `1000`
- Chunk Overlap : `200`
- Separators : `["\n\n", "\n", ".", "!", "?", " ", ""]`

#### Node Embedding

- Type : **OpenAI Embeddings**
- Model : `text-embedding-3-large`
- Dimensions : `3072`

#### Node Vector Store

- Type : **Pinecone** (ou Chroma/Qdrant)
- Index Name : `largo-kb`
- Namespace : (optionnel, pour organiser)

---

## Étape 3 : Organiser les Documents

### Structure recommandée

```
largo_kb/
├── 01_playbooks/
│   ├── playbook_cession.pdf
│   ├── playbook_acquisition.pdf
│   ├── playbook_lbo.pdf
│   └── guide_due_diligence.pdf
├── 02_multiples/
│   ├── multiples_tech_saas.pdf
│   ├── multiples_industrie.pdf
│   └── multiples_services.pdf
├── 03_regulatory/
│   ├── droit_investissements.pdf
│   ├── fiscalite_ma.pdf
│   └── controle_concentrations.pdf
├── 04_templates/
│   ├── template_teaser.docx
│   ├── template_im.docx
│   └── template_nda.docx
├── 05_glossary/
│   └── glossaire_ma.pdf
└── 06_deals/
    └── (ajoutés dynamiquement)
```

### Métadonnées importantes

Pour chaque document, ajouter des métadonnées :

```json
{
  "source": "playbook_cession.pdf",
  "category": "playbook",
  "deal_type": "cession",
  "language": "fr",
  "uploaded_at": "2026-03-18",
  "version": "2.0"
}
```

---

## Étape 4 : Uploader les Documents

### Méthode 1 : Via l'interface Flowise

1. Aller dans **"Document Stores"**
2. Créer un nouveau store : `largo-kb`
3. Uploader les fichiers
4. Cliquer sur **"Upsert"**

### Méthode 2 : Via API

```bash
# Uploader un document
curl -X POST http://localhost:3000/api/v1/document-store/upsert \
  -H "Content-Type: multipart/form-data" \
  -F "files=@playbook_cession.pdf" \
  -F "metadata={\"category\":\"playbook\"}"
```

### Méthode 3 : Script Python

```python
import requests
from pathlib import Path

FLOWISE_URL = "http://localhost:3000"
API_KEY = "votre_api_key"

def upload_document(file_path: Path, metadata: dict):
    with open(file_path, 'rb') as f:
        files = {'files': f}
        data = {'metadata': str(metadata)}
        
        response = requests.post(
            f"{FLOWISE_URL}/api/v1/document-store/upsert",
            headers={"Authorization": f"Bearer {API_KEY}"},
            files=files,
            data=data
        )
        
        return response.json()

# Upload batch
kb_dir = Path("~/largo_kb")
for pdf_file in kb_dir.glob("**/*.pdf"):
    category = pdf_file.parent.name
    upload_document(pdf_file, {"category": category})
```

---

## Étape 5 : Configurer le Retriever dans le Chatflow

### 5.1 Ajouter le node Vector Store Retriever

Dans le chatflow principal :

1. Ajouter un node **Vector Store Retriever**
2. Configuration :
   - Vector Store : `Pinecone`
   - Index Name : `largo-kb`
   - Top K : `5`
   - Search Type : `Similarity`

### 5.2 Connecter au Chat Model

```
Vector Store Retriever → Chat Model (via context)
```

### 5.3 Configurer le prompt pour utiliser le RAG

Dans le System Message, ajouter :

```markdown
## Base de connaissances
Tu as accès à une base de connaissances M&A via l'outil query_rag.
Utilise-la pour :
- Consulter les playbooks méthodologiques
- Retrouver des informations sur les deals passés
- Accéder aux templates de documents
- Vérifier la réglementation

Lorsque tu utilises le RAG, cite toujours la source du document.
```

---

## Étape 6 : Test du RAG

### Test via le chat

1. Lancer le chat
2. Demander : `"Quels sont les étapes d'une cession d'entreprise selon notre playbook ?"`
3. Vérifier que :
   - L'agent invoque `query_rag`
   - La réponse cite les bonnes sources
   - Le contenu est pertinent

### Test via API

```bash
curl -X POST http://localhost:3000/api/v1/chatflows/largo-main/predict \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Quels sont les multiples sectoriels pour le tech SaaS ?",
    "history": []
  }'
```

---

## Étape 7 : Maintenance du RAG

### Ajouter de nouveaux documents

1. Uploader le document
2. Vérifier l'indexation
3. Tester une requête

### Mettre à jour des documents

1. Supprimer l'ancienne version (via ID)
2. Uploader la nouvelle version
3. Vérifier la cohérence

### Supprimer des documents

```bash
curl -X DELETE http://localhost:3000/api/v1/document-store/delete \
  -H "Content-Type: application/json" \
  -d '{"ids": ["doc_id_1", "doc_id_2"]}'
```

---

## Optimisations

### Chunk Size

| Type de document | Chunk Size | Overlap |
|------------------|------------|---------|
| Playbooks | 1500 | 300 |
| Templates | 1000 | 200 |
| Glossaire | 500 | 100 |
| Deals | 2000 | 400 |

### Embeddings

| Modèle | Dimensions | Qualité | Coût |
|--------|------------|---------|------|
| text-embedding-3-large | 3072 | ⭐⭐⭐ | $$ |
| text-embedding-3-small | 1536 | ⭐⭐ | $ |
| text-embedding-ada-002 | 1536 | ⭐⭐ | $$ |

### Filtrage

Utiliser les métadonnées pour filtrer les résultats :

```javascript
// Dans le retriever
{
  "filter": {
    "category": "playbook",
    "deal_type": "cession"
  }
}
```

---

*Guide de configuration du RAG pour Largo*
