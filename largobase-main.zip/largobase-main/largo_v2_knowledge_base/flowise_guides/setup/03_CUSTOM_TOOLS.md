# Création de Custom Tools pour Flowise

> **Objectif** : Créer les outils personnalisés que Largo utilisera  
> **Temps estimé** : 45-60 minutes  
> **Fichiers de référence** : `flowise_kb/tools/*.json`

---

## Vue d'ensemble

Les Custom Tools dans Flowise permettent à l'agent d'interagir avec :
- APIs externes (Pappers, SIRENE, etc.)
- Microservices internes
- Bases de données
- Fonctions personnalisées

---

## Étape 1 : Accéder aux Tools

1. Dans Flowise, aller dans **"Tools"** dans le menu latéral
2. Cliquer sur **"Add New"**

---

## Étape 2 : Créer le Tool "search_company"

### 2.1 Informations générales

- **Name** : `search_company`
- **Description** : `Recherche une entreprise française par SIREN, SIRET ou nom. Retourne les informations légales, financières et un scoring M&A.`

### 2.2 Schéma (Schema)

```json
{
  "type": "object",
  "properties": {
    "query": {
      "type": "string",
      "description": "SIREN (9 chiffres), SIRET (14 chiffres) ou nom de l'entreprise"
    },
    "include_financials": {
      "type": "boolean",
      "description": "Inclure les données financières détaillées",
      "default": true
    },
    "depth": {
      "type": "string",
      "enum": ["quick", "standard", "deep"],
      "description": "Niveau de profondeur de la recherche",
      "default": "standard"
    }
  },
  "required": ["query"]
}
```

### 2.3 JavaScript Function

```javascript
const fetch = require('node-fetch');

const searchCompany = async (query, include_financials = true, depth = 'standard') => {
    try {
        const response = await fetch('http://localhost:8001/api/company/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query,
                include_financials,
                depth
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Formater la réponse pour l'agent
        return {
            company: data.company,
            ma_analysis: data.ma_analysis,
            summary: `Entreprise: ${data.company.name} (SIREN: ${data.company.siren}). ` +
                     `Score M&A: ${data.ma_analysis.attractiveness_score}/10. ` +
                     `Secteur: ${data.company.sector}. ` +
                     `CA: ${data.company.revenue || 'N/A'}.`,
            sources: data.sources
        };
        
    } catch (error) {
        return {
            error: true,
            message: `Erreur lors de la recherche: ${error.message}`,
            suggestion: "Vérifiez que le service mna-research est démarré sur le port 8001"
        };
    }
};

// Exécution
const result = await searchCompany($query, $include_financials, $depth);
return JSON.stringify(result);
```

---

## Étape 3 : Créer le Tool "get_valuation"

### 3.1 Informations générales

- **Name** : `get_valuation`
- **Description** : `Calcule la valorisation d'une entreprise française selon la méthode des multiples sectoriels.`

### 3.2 Schéma

```json
{
  "type": "object",
  "properties": {
    "ebitda": {
      "type": "number",
      "description": "EBITDA en euros"
    },
    "ebe": {
      "type": "number",
      "description": "EBE (Excédent Brut d'Exploitation) en euros"
    },
    "revenue": {
      "type": "number",
      "description": "Chiffre d'affaires en euros"
    },
    "net_debt": {
      "type": "number",
      "description": "Dette nette en euros",
      "default": 0
    },
    "sector": {
      "type": "string",
      "enum": ["tech_saas", "services_informatique", "biotech", "industrie", "distribution", "construction", "retail", "general"],
      "default": "general"
    },
    "company_size": {
      "type": "string",
      "enum": ["tpe", "pme", "eti", "large"],
      "default": "pme"
    },
    "growth_rate": {
      "type": "number",
      "description": "Taux de croissance du CA en %",
      "default": 0
    }
  },
  "required": []
}
```

### 3.3 JavaScript Function

```javascript
const fetch = require('node-fetch');

const getValuation = async (params) => {
    try {
        // Déterminer quel métrique utiliser
        const metric = params.ebitda || params.ebe || params.revenue;
        if (!metric) {
            return {
                error: true,
                message: "Au moins une métrique financière requise: ebitda, ebe, ou revenue"
            };
        }
        
        const response = await fetch('http://localhost:8001/api/valuation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        });
        
        const data = await response.json();
        
        // Formater pour l'agent
        return {
            enterprise_value: data.enterprise_value,
            equity_value: data.equity_value,
            multiple_applied: data.multiple_applied,
            summary: `Valorisation: ${data.enterprise_value.formatted_range} (EV). ` +
                     `Fonds propres: ${data.equity_value.formatted_range}. ` +
                     `Multiple: ${data.multiple_applied.mid}x ${data.multiple_applied.metric}.`,
            methodology: data.methodology,
            adjustments: data.adjustments
        };
        
    } catch (error) {
        return {
            error: true,
            message: `Erreur de valorisation: ${error.message}`
        };
    }
};

const result = await getValuation({
    ebitda: $ebitda,
    ebe: $ebe,
    revenue: $revenue,
    net_debt: $net_debt,
    sector: $sector,
    company_size: $company_size,
    growth_rate: $growth_rate
});

return JSON.stringify(result);
```

---

## Étape 4 : Créer le Tool "save_memory"

### 4.1 Informations générales

- **Name** : `save_memory`
- **Description** : `Sauvegarde une information dans la mémoire persistante de Largo.`

### 4.2 Schéma

```json
{
  "type": "object",
  "properties": {
    "key": {
      "type": "string",
      "description": "Clé d'identification (ex: preference_name, deal_x_status)"
    },
    "value": {
      "type": "string",
      "description": "Valeur à sauvegarder"
    },
    "category": {
      "type": "string",
      "enum": ["preference", "deal", "contact", "methodology", "general"],
      "default": "general"
    },
    "context": {
      "type": "string",
      "description": "Contexte additionnel",
      "default": ""
    }
  },
  "required": ["key", "value"]
}
```

### 4.3 JavaScript Function

```javascript
const fetch = require('node-fetch');

const saveMemory = async (key, value, category = 'general', context = '') => {
    try {
        const response = await fetch('http://localhost:8006/api/memory/save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                key,
                value,
                category,
                context,
                user_id: 'christophe.berthon'
            })
        });
        
        const data = await response.json();
        
        return {
            success: data.success,
            message: `C'est noté, j'ai enregistré: ${key} = ${value}`,
            memory_id: data.memory_id
        };
        
    } catch (error) {
        return {
            success: false,
            message: `Erreur de sauvegarde: ${error.message}`
        };
    }
};

const result = await saveMemory($key, $value, $category, $context);
return JSON.stringify(result);
```

---

## Étape 5 : Créer le Tool "query_rag"

### 5.1 Informations générales

- **Name** : `query_rag`
- **Description** : `Interroge la base de connaissances RAG de Largo.`

### 5.2 Schéma

```json
{
  "type": "object",
  "properties": {
    "query": {
      "type": "string",
      "description": "Question ou sujet à rechercher"
    },
    "top_k": {
      "type": "number",
      "description": "Nombre de documents à récupérer",
      "default": 5
    }
  },
  "required": ["query"]
}
```

### 5.3 JavaScript Function (avec Pinecone)

```javascript
const { Pinecone } = require('@pinecone-database/pinecone');
const { OpenAIEmbeddings } = require('langchain/embeddings/openai');

const queryRAG = async (query, top_k = 5) => {
    try {
        // Initialiser Pinecone
        const pinecone = new Pinecone({
            apiKey: process.env.PINECONE_API_KEY
        });
        
        const index = pinecone.Index('largo-kb');
        
        // Générer l'embedding
        const embeddings = new OpenAIEmbeddings({
            openAIApiKey: process.env.OPENAI_API_KEY
        });
        
        const queryEmbedding = await embeddings.embedQuery(query);
        
        // Rechercher
        const results = await index.query({
            vector: queryEmbedding,
            topK: top_k,
            includeMetadata: true
        });
        
        // Formater les résultats
        const formatted = results.matches.map(match => ({
            content: match.metadata.text,
            source: match.metadata.source,
            score: match.score,
            category: match.metadata.category
        }));
        
        return {
            results: formatted,
            query: query,
            total_results: formatted.length
        };
        
    } catch (error) {
        return {
            error: true,
            message: `Erreur RAG: ${error.message}`
        };
    }
};

const result = await queryRAG($query, $top_k);
return JSON.stringify(result);
```

---

## Étape 6 : Liste complète des Tools à créer

| Tool | Description | Priorité |
|------|-------------|----------|
| `search_company` | Recherche entreprise | ⭐⭐⭐ |
| `get_valuation` | Calcul valorisation | ⭐⭐⭐ |
| `get_multiples` | Multiples sectoriels | ⭐⭐⭐ |
| `web_search` | Recherche web | ⭐⭐ |
| `deep_research` | Recherche approfondie | ⭐⭐ |
| `generate_document` | Génération documents | ⭐⭐⭐ |
| `save_memory` | Sauvegarde mémoire | ⭐⭐⭐ |
| `get_memory` | Récupération mémoire | ⭐⭐⭐ |
| `delegate_to_agent` | Délégation agent | ⭐⭐ |
| `send_notification` | Notifications | ⭐⭐ |
| `query_rag` | Interrogation RAG | ⭐⭐⭐ |

---

## Étape 7 : Test des Tools

### 7.1 Test individuel

Dans Flowise, chaque tool a un bouton **"Test"** :

1. Remplir les paramètres
2. Cliquer sur **"Test"**
3. Vérifier la réponse

### 7.2 Test dans le Chatflow

1. Ajouter le tool au chatflow
2. Lancer le chat
3. Demander explicitement l'utilisation du tool

---

## Troubleshooting

| Problème | Solution |
|----------|----------|
| "Function not defined" | Vérifier que la fonction est bien déclarée avec `const` |
| Variables non remplacées | Utiliser `$variable` (avec le $) dans le code |
| Timeouts | Augmenter le timeout dans Additional Parameters |
| Erreurs CORS | Vérifier que le service accepte les requêtes cross-origin |

---

*Guide de création des Custom Tools pour Largo*
