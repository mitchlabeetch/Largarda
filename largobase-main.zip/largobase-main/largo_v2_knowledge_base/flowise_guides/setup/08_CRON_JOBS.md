# Configuration des Tâches Planifiées (Cron Jobs)

> **Objectif** : Automatiser les routines quotidiennes/hebdomadaires de Largo  
> **Temps estimé** : 15-25 minutes

---

## Vue d'ensemble

Les cron jobs dans Flowise permettent d'automatiser :
- Briefing M&A quotidien
- Veille sectorielle
- Enrichissement de prospects
- Rappels de réunions
- Sauvegardes

---

## Étape 1 : Créer un Workflow Cron

### 1.1 Briefing M&A Quotidien

1. Créer un nouveau **Chatflow**
2. Nommer : `Daily M&A Briefing`
3. Type : **Scheduled** (pas Conversation)

#### Nodes

```
[Schedule Trigger] → [Research Agent] → [Format Response] → [Send Notification]
```

#### Schedule Trigger

- Type : **Schedule Trigger**
- Schedule : `0 8 * * *` (tous les jours à 8h00)
- Timezone : `Europe/Paris`

#### Research Agent Call

```javascript
const fetch = require('node-fetch');

const generateBriefing = async () => {
    // 1. Recherche des actualités M&A
    const news = await fetch('http://localhost:8005/api/news/ma?date=today');
    
    // 2. Analyse des tendances
    const trends = await fetch('http://localhost:8005/api/trends');
    
    // 3. Générer le briefing
    const response = await fetch(
        'http://localhost:3000/api/v1/chatflows/research-agent/predict',
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question: `Génère un briefing M&A avec ces données: ${JSON.stringify({news, trends})}`
            })
        }
    );
    
    return await response.json();
};

const briefing = await generateBriefing();
return JSON.stringify(briefing);
```

#### Send Notification

```javascript
const sendNotification = async (message) => {
    await fetch('http://localhost:8008/api/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            channel: 'whatsapp',
            recipient: process.env.CHRISTOPHE_WHATSAPP,
            message: message,
            priority: 'normal'
        })
    });
};

await sendNotification($briefing_text);
return { sent: true, timestamp: new Date().toISOString() };
```

---

## Étape 2 : Liste des Cron Jobs Recommandés

| Job | Fréquence | Description |
|-----|-----------|-------------|
| `daily_briefing` | 8h00 quotidien | Briefing M&A du jour |
| `weekly_digest` | Lundi 9h00 | Résumé hebdomadaire |
| `prospect_enrichment` | Mercredi 14h00 | Enrichissement batch prospects |
| `deal_reminders` | 18h00 quotidien | Rappels actions en cours |
| `newsletter_prep` | Vendredi 10h00 | Préparation newsletter |
| `backup_flows` | Dimanche 2h00 | Sauvegarde des flows |
| `cleanup_old_memories` | 1er du mois | Nettoyage mémoire ancienne |

---

## Étape 3 : Configuration des Schedules

### Format Cron

```
# ┌───────────── minute (0 - 59)
# │ ┌───────────── hour (0 - 23)
# │ │ ┌───────────── day of month (1 - 31)
# │ │ │ ┌───────────── month (1 - 12)
# │ │ │ │ ┌───────────── day of week (0 - 6) (Sunday to Saturday)
# │ │ │ │ │
# │ │ │ │ │
# * * * * *

0 8 * * *    # Tous les jours à 8h00
0 9 * * 1    # Tous les lundis à 9h00
0 14 * * 3   # Tous les mercredis à 14h00
0 18 * * *   # Tous les jours à 18h00
0 10 * * 5   # Tous les vendredis à 10h00
0 2 * * 0    # Tous les dimanches à 2h00
0 0 1 * *    # 1er de chaque mois à minuit
```

### Configuration dans Flowise

Dans le node **Schedule Trigger** :

```json
{
  "schedule": "0 8 * * *",
  "timezone": "Europe/Paris",
  "enabled": true,
  "name": "daily_briefing"
}
```

---

## Étape 4 : Workflows Cron Spécifiques

### 4.1 Daily Briefing

**Objectif** : Envoyer un résumé des actualités M&A chaque matin

```javascript
// Contenu du briefing
createBriefing = () => {
    return `
📊 BRIEFING M&A DU JOUR — ${date}

🔥 TOP OPÉRATIONS
${topDeals.map(d => `- ${d.acquirer} → ${d.target} : ${d.value}`).join('\n')}

📈 TENDANCES
- Secteur le plus actif : ${topSector}
- Volume total : ${totalVolume}
- Multiples moyens : ${avgMultiple}x

🎯 OPPORTUNITÉS POUR ALECIA
${opportunities.map(o => `- ${o.company} (${o.sector})`).join('\n')}

_${articlesCount} articles analysés | Largo 2.0_
    `;
};
```

### 4.2 Deal Reminders

**Objectif** : Rappeler les actions en attente

```javascript
const getPendingActions = async () => {
    const response = await fetch('http://localhost:8006/api/memory/get', {
        method: 'POST',
        body: JSON.stringify({
            query: 'pending_actions',
            category: 'deal'
        })
    });
    
    return await response.json();
};

const sendReminders = async () => {
    const actions = await getPendingActions();
    
    if (actions.length === 0) return;
    
    const message = `
⏰ RAPPELS DU JOUR

${actions.map(a => `- ${a.deal}: ${a.action} (échéance: ${a.due_date})`).join('\n')}

Bon courage ! 🤝
    `;
    
    await sendNotification(message);
};
```

### 4.3 Prospect Enrichment Batch

**Objectif** : Enrichir automatiquement les nouveaux prospects

```javascript
const batchEnrichment = async () => {
    // 1. Récupérer les prospects non enrichis
    const prospects = await fetch('http://localhost:8006/api/prospects?enriched=false');
    
    // 2. Pour chaque prospect, lancer l'enrichissement
    for (const prospect of prospects) {
        await fetch('http://localhost:3000/api/v1/chatflows/prospect-agent/predict', {
            method: 'POST',
            body: JSON.stringify({
                question: `Enrichir le prospect ${prospect.name}`,
                overrideConfig: { prospect }
            })
        });
    }
    
    // 3. Notifier Christophe
    await sendNotification(
        `✅ ${prospects.length} prospects enrichis automatiquement`
    );
};
```

### 4.4 Backup Flows

**Objectif** : Sauvegarder tous les flows Flowise

```javascript
const backupFlows = async () => {
    // 1. Exporter tous les flows
    const flows = await fetch('http://localhost:3000/api/v1/flows/export');
    const flowsData = await flows.json();
    
    // 2. Sauvegarder avec date
    const date = new Date().toISOString().split('T')[0];
    const filename = `flowise_backup_${date}.json`;
    
    await fetch('http://localhost:8009/api/storage/save', {
        method: 'POST',
        body: JSON.stringify({
            filename,
            data: flowsData,
            bucket: 'backups'
        })
    });
    
    // 3. Nettoyer les vieux backups (garder 30 jours)
    await fetch('http://localhost:8009/api/storage/cleanup?days=30');
};
```

---

## Étape 5 : Monitoring des Cron Jobs

### 5.1 Logs

Chaque cron job doit logger :

```json
{
  "job_name": "daily_briefing",
  "scheduled_at": "2026-03-18T08:00:00Z",
  "started_at": "2026-03-18T08:00:02Z",
  "completed_at": "2026-03-18T08:00:45Z",
  "duration_ms": 43000,
  "status": "success",
  "output": { "articles_processed": 15, "notifications_sent": 1 }
}
```

### 5.2 Alertes en cas d'échec

```javascript
const handleJobFailure = async (jobName, error) => {
    await sendNotification({
        channel: 'email',
        recipient: process.env.ADMIN_EMAIL,
        message: `⚠️ Cron job ${jobName} a échoué: ${error.message}`,
        priority: 'high'
    });
};
```

---

## Étape 6 : Alternative avec Système Cron Externe

Si Flowise ne supporte pas nativement les cron jobs :

### 6.1 Crontab

```bash
# Éditer le crontab
crontab -e

# Ajouter les jobs
0 8 * * * curl -X POST http://localhost:3000/api/v1/chatflows/daily-briefing/trigger
0 18 * * * curl -X POST http://localhost:3000/api/v1/chatflows/deal-reminders/trigger
0 2 * * 0 curl -X POST http://localhost:3000/api/v1/chatflows/backup-flows/trigger
```

### 6.2 Node-cron (dans un service)

```javascript
const cron = require('node-cron');

// Daily briefing
cron.schedule('0 8 * * *', async () => {
    await triggerFlowiseFlow('daily-briefing');
});

// Deal reminders
cron.schedule('0 18 * * *', async () => {
    await triggerFlowiseFlow('deal-reminders');
});
```

---

*Guide de configuration des cron jobs pour Largo*
