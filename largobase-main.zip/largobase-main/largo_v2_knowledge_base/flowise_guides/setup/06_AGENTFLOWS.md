# Création des Agentflows (Multi-Agent)

> **Objectif** : Créer des agents spécialisés et les orchestrer  
> **Temps estimé** : 30-45 minutes  
> **Fichiers de référence** : `flowise_kb/agentflows/*.json`

---

## Vue d'ensemble

Les Agentflows permettent de créer des équipes d'agents spécialisés :
- **Document Agent** : Génération de documents
- **Research Agent** : Recherche et veille
- **Meeting Agent** : Préparation et suivi des réunions
- **Email Agent** : Gestion des communications
- **Prospect Agent** : Enrichissement des prospects

---

## Étape 1 : Créer un Agent Spécialisé

### 1.1 Document Agent

1. Dans Flowise, créer un nouveau **Agentflow**
2. Nommer : `Document Agent`
3. Description : `Agent spécialisé dans la génération de documents M&A`

#### System Message

```markdown
Tu es l'agent Document de Largo.

Ta spécialité : créer des documents professionnels pour le M&A.

Templates disponibles :
- teaser : Teaser d'acquisition anonyme
- company_profile : Profil d'entreprise détaillé
- valuation_report : Rapport de valorisation
- executive_summary : Résumé exécutif
- im : Information Memorandum
- nda : Accord de confidentialité

Règles :
1. Utilise toujours le branding Alecia
2. Structure les documents de manière professionnelle
3. Adapte le contenu au contexte M&A français
4. Vérifie la cohérence des données

Quand tu reçois une demande :
1. Confirme le template demandé
2. Vérifie que toutes les données nécessaires sont présentes
3. Génère le document via l'outil generate_document
4. Confirme la création avec le lien de téléchargement
```

#### Tools

- `generate_document`
- `query_rag` (pour les templates)
- `save_memory`

#### Model

- **Claude 3.5 Sonnet**
- Temperature : `0.5` (plus déterministe pour les documents)

---

### 1.2 Research Agent

#### System Message

```markdown
Tu es l'agent Recherche de Largo.

Ta spécialité : trouver et analyser des informations sur les entreprises et le marché M&A.

Capacités :
- Recherche d'entreprises (SIRENE, Pappers)
- Analyse financière
- Valorisation par multiples
- Veille sectorielle
- Recherche web approfondie
- Comparables de transactions

Méthodologie :
1. Toujours croiser plusieurs sources
2. Citer les sources utilisées
3. Indiquer le niveau de confiance
4. Signaler les informations manquantes

Quand tu analyses une entreprise :
1. Recherche les données légales
2. Analyse les données financières
3. Calcule le scoring M&A
4. Identifie les risques et opportunités
5. Propose des comparables
```

#### Tools

- `search_company`
- `get_valuation`
- `get_multiples`
- `web_search`
- `deep_research`
- `query_rag`

---

### 1.3 Meeting Agent

#### System Message

```markdown
Tu es l'agent Réunion de Largo.

Ta spécialité : préparer, suivre et optimiser les réunions M&A.

Tâches :
- Préparation de réunions (ordre du jour, documents)
- Synthèse de comptes-rendus
- Extraction d'actions à suivre
- Rappels automatiques
- Recherche historique des échanges

Processus de préparation :
1. Identifier les participants
2. Rechercher l'historique des échanges
3. Préparer l'ordre du jour
4. Rassembler les documents pertinents
5. Anticiper les questions

Processus post-réunion :
1. Synthétiser les points clés
2. Extraire les actions avec responsables et échéances
3. Envoyer le compte-rendu
4. Programmer les relances
```

#### Tools

- `query_rag`
- `save_memory`
- `get_memory`
- `send_notification`

---

## Étape 2 : Configurer la Délégation

### 2.1 Tool delegate_to_agent

Créer un tool qui permet à l'agent principal de déléguer :

```javascript
const fetch = require('node-fetch');

const delegateToAgent = async (agent_name, task, context, priority = 'normal') => {
    const agentUrls = {
        'document_agent': 'http://localhost:3000/api/v1/chatflows/document-agent/predict',
        'research_agent': 'http://localhost:3000/api/v1/chatflows/research-agent/predict',
        'meeting_agent': 'http://localhost:3000/api/v1/chatflows/meeting-agent/predict',
        'email_agent': 'http://localhost:3000/api/v1/chatflows/email-agent/predict',
        'prospect_agent': 'http://localhost:3000/api/v1/chatflows/prospect-agent/predict'
    };
    
    const url = agentUrls[agent_name];
    if (!url) {
        return { error: true, message: `Agent ${agent_name} inconnu` };
    }
    
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            question: task,
            overrideConfig: { context },
            history: []
        })
    });
    
    const result = await response.json();
    
    return {
        agent: agent_name,
        task: task,
        result: result.text || result,
        completed_at: new Date().toISOString()
    };
};

const result = await delegateToAgent($agent_name, $task, $context, $priority);
return JSON.stringify(result);
```

### 2.2 Intégration dans l'Agent Principal

Dans le system prompt de Largo Main :

```markdown
## Délégation Multi-Agents

Tu peux déléguer des tâches spécifiques à des agents spécialisés :

- document_agent : Génération de documents
- research_agent : Recherche et analyse
- meeting_agent : Préparation de réunions
- email_agent : Rédaction d'emails
- prospect_agent : Enrichissement prospects

Quand déléguer :
1. La tâche est complexe et spécifique
2. Tu n'as pas les outils nécessaires
3. La tâche peut être parallélisée
4. Un agent spécialisé serait plus efficace

Processus de délégation :
1. Confirme la délégation à Christophe
2. Invoque delegate_to_agent avec les paramètres
3. Attends le résultat
4. Synthétise et présente le résultat
```

---

## Étape 3 : Exemples de Délégation

### Exemple 1 : Génération de Teaser

**Christophe** : "Crée un teaser pour TechCorp"

**Largo Main** :
1. Analyse : C'est une tâche de génération de document
2. Décide de déléguer à document_agent
3. Invoque :
   ```json
   {
     "agent_name": "document_agent",
     "task": "Générer un teaser pour TechCorp",
     "context": {
       "company_name": "TechCorp",
       "template": "teaser"
     }
   }
   ```
4. Attend le résultat
5. Répond : "J'ai demandé à l'agent Document de créer le teaser. Voici le résultat..."

### Exemple 2 : Recherche Complète

**Christophe** : "Fais-moi une analyse complète de l'entreprise SIREN 123"

**Largo Main** :
1. Décide de déléguer à research_agent
2. Invoque avec profondeur "deep"
3. Reçoit l'analyse complète
4. Synthétise pour Christophe

---

## Étape 4 : Communication Inter-Agents

### 4.1 Passage de Contexte

Lors de la délégation, passer le contexte nécessaire :

```json
{
  "agent_name": "document_agent",
  "task": "Générer un teaser",
  "context": {
    "company_name": "TechCorp",
    "revenue": "5M€",
    "ebitda": "1M€",
    "sector": "tech_saas",
    "employees": 45,
    "location": "Sophia Antipolis"
  }
}
```

### 4.2 Retour de Résultat

L'agent spécialisé retourne :

```json
{
  "status": "success",
  "document_id": "doc_123",
  "download_url": "http://...",
  "summary": "Teaser généré avec succès",
  "metadata": {
    "pages": 7,
    "template": "teaser",
    "generated_at": "2026-03-18T10:30:00Z"
  }
}
```

---

## Étape 5 : Monitoring des Agents

### 5.1 Logs

Chaque agent doit logger ses actions :

```javascript
{
  "timestamp": "2026-03-18T10:30:00Z",
  "agent": "document_agent",
  "action": "generate_document",
  "input": { "template": "teaser", "company": "TechCorp" },
  "output": { "document_id": "doc_123" },
  "duration_ms": 2500,
  "status": "success"
}
```

### 5.2 Métriques

| Métrique | Description |
|----------|-------------|
| `agent_invocations` | Nombre d'invocations par agent |
| `agent_latency` | Temps de réponse moyen |
| `agent_success_rate` | Taux de succès |
| `agent_errors` | Nombre d'erreurs |

---

## Étape 6 : Patterns Avancés

### 6.1 Chaîne d'Agents

Un agent peut en appeler un autre :

```
Largo Main → Research Agent → Document Agent
```

Exemple : Recherche d'entreprise puis génération de profil

### 6.2 Parallélisation

Lancer plusieurs agents en parallèle :

```javascript
const results = await Promise.all([
  delegateToAgent('research_agent', 'Recherche entreprise A'),
  delegateToAgent('research_agent', 'Recherche entreprise B'),
  delegateToAgent('research_agent', 'Recherche entreprise C')
]);
```

### 6.3 Fallback

Si un agent échoue, essayer un autre :

```javascript
try {
  result = await delegateToAgent('document_agent', task);
} catch (error) {
  // Fallback to main agent
  result = await generateDocumentLocally(task);
}
```

---

*Guide de création des Agentflows pour Largo*
