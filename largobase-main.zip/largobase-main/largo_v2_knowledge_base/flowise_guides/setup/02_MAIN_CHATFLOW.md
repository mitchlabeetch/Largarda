# Création du Chatflow Principal Largo

> **Objectif** : Créer l'agent principal Largo dans Flowise  
> **Temps estimé** : 20-30 minutes

---

## Vue d'ensemble du Chatflow

Le chatflow principal de Largo est structuré comme suit :

```
[Start] → [System Message] → [Chat Model] → [Tools] → [Vector Store Retriever] → [End]
                ↑                ↑
         [Buffer Memory]    [Output Parser]
```

---

## Étape 1 : Créer un nouveau Chatflow

1. Dans Flowise, cliquer sur **"Add New"** → **"Chatflow"**
2. Nommer : `Largo Main Agent`
3. Description : `Agent principal de Largo pour Christophe Berthon`

---

## Étape 2 : Ajouter les Nodes

### 2.1 Node Start

- Type : **Start**
- Position : Début du flow
- Configuration : Par défaut

### 2.2 Node System Message

- Type : **System Message**
- Contenu : Copier le contenu de `flowise_kb/prompts/SYSTEM_PROMPT.md`
- Ce message définit l'identité et le comportement de Largo

### 2.3 Node Chat Model

- Type : **Chat Model**
- Modèle recommandé : **Claude 3.5 Sonnet** ou **GPT-4**
- Configuration :
  ```json
  {
    "temperature": 0.7,
    "maxTokens": 4000,
    "streaming": true
  }
  ```

### 2.4 Node Tools

- Type : **Tool Node**
- Ajouter les tools suivants (créés dans le guide 03) :
  - `search_company`
  - `get_valuation`
  - `get_multiples`
  - `web_search`
  - `deep_research`
  - `generate_document`
  - `save_memory`
  - `get_memory`
  - `delegate_to_agent`
  - `send_notification`
  - `query_rag`

### 2.5 Node Vector Store Retriever

- Type : **Vector Store Retriever**
- Vector Store : **Pinecone** (ou autre configuré)
- Index : `largo-knowledge-base`
- Top K : `5`
- Search Type : `Similarity`

### 2.6 Node Buffer Memory

- Type : **Buffer Memory**
- Memory Key : `chat_history`
- K : `10` (nombre de messages conservés)
- Return Messages : `true`

### 2.7 Node End

- Type : **End**
- Configuration : Par défaut

---

## Étape 3 : Connecter les Nodes

```
Start → System Message → Chat Model → Tools → End
              ↑            ↑
    Buffer Memory    Vector Store Retriever
```

1. **Start** → **System Message**
2. **System Message** → **Chat Model**
3. **Buffer Memory** → **Chat Model**
4. **Chat Model** → **Tools**
5. **Vector Store Retriever** → **Tools**
6. **Tools** → **End**

---

## Étape 4 : Configuration Avancée

### 4.1 Callbacks

Dans les **Additional Parameters** du Chat Model :

```json
{
  "callbacks": [
    {
      "name": "onToolStart",
      "handler": "console.log('Tool started:', tool.name)"
    },
    {
      "name": "onToolEnd", 
      "handler": "console.log('Tool completed:', tool.name)"
    }
  ]
}
```

### 4.2 Output Parser

Si besoin de parser la sortie :

- Type : **Structured Output Parser**
- Schema : Définir la structure de réponse attendue

---

## Étape 5 : Test du Chatflow

### 5.1 Mode Chat

1. Cliquer sur **"Chat"** en haut à droite
2. Tester avec : `"Salut Largo, tu peux me présenter une entreprise ?"`
3. Vérifier que :
   - Largo répond avec son ton jovial
   - Les tools sont invoqués correctement
   - La mémoire fonctionne

### 5.2 Logs de debug

Activer les logs détaillés :

```javascript
// Dans Additional Parameters
{
  "verbose": true,
  "tags": ["largo", "main-agent"]
}
```

---

## Étape 6 : Export du Chatflow

Pour sauvegarder :

1. Cliquer sur **"Settings"** (engrenage)
2. **"Export Chatflow"**
3. Sauvegarder le JSON dans `flowise_kb/agentflows/`

---

## Configuration du System Message

Le system message est crucial. Voici une version optimisée :

```markdown
# LARGO 2.0 — SYSTEM PROMPT

## Identité
Tu es Largo, l'assistant IA personnel de Christophe Berthon, associé fondateur d'Alecia M&A.

## Mission
Aider Christophe dans ses opérations de fusion-acquisition pour PME et ETI françaises, avec un focus sur la Côte d'Azur.

## Style de communication
- Tutoyer Christophe ("tu")
- Ton jovial et légèrement audacieux
- Références personnelles acceptées (Sylvie, Lisa, Michaël)
- Propositions spontanées

## Capacités
Tu as accès aux outils suivants :
- search_company : Recherche d'entreprises
- get_valuation : Calcul de valorisation
- get_multiples : Multiples sectoriels
- web_search : Recherche web
- deep_research : Recherche approfondie
- generate_document : Génération de documents
- save_memory / get_memory : Gestion de la mémoire
- delegate_to_agent : Délégation à des agents spécialisés
- send_notification : Notifications
- query_rag : Base de connaissances

## Processus de décision
1. Analyser la demande de Christophe
2. Décider : réponse directe / query RAG / tool call / délégation
3. Exécuter et vérifier
4. Répondre avec sources et prochaines étapes

## Terminologie M&A
Privilégier le français : EBE (pas EBITDA), CA (pas Revenue), valorisation (pas valuation).
```

---

## Intégration avec les Agents Spécialisés

Pour déléguer à un agent spécialisé, utiliser le tool `delegate_to_agent` :

```javascript
// Exemple d'appel
{
  "agent_name": "document_agent",
  "task": "Générer un teaser pour TechCorp",
  "context": {
    "company_name": "TechCorp",
    "revenue": "5M€",
    "ebitda": "1M€"
  }
}
```

---

## Troubleshooting

| Problème | Solution |
|----------|----------|
| Tools non invoqués | Vérifier que les tools sont bien connectés au Chat Model |
| Mémoire non persistante | Vérifier la configuration du Buffer Memory |
| RAG ne retourne rien | Vérifier l'index Pinecone et les documents indexés |
| Réponses lentes | Réduire maxTokens ou utiliser un modèle plus rapide |

---

*Guide de création du chatflow principal Largo*
