# LARGO 2.0 — Flowise Implementation Guides

> **Version**: 2.0-Flowise  
> **Purpose**: Guides détaillés pour implémenter Largo avec Flowise  
> **Audience**: Développeurs et intégrateurs

---

## 📚 Structure des Guides

### Setup & Configuration

| Guide | Description | Temps |
|-------|-------------|-------|
| [01. Installation](setup/01_INSTALLATION.md) | Installer Flowise et les dépendances | 30-45 min |
| [02. Main Chatflow](setup/02_MAIN_CHATFLOW.md) | Créer l'agent principal Largo | 20-30 min |
| [03. Custom Tools](setup/03_CUSTOM_TOOLS.md) | Créer les outils personnalisés | 45-60 min |
| [04. RAG Setup](setup/04_RAG_SETUP.md) | Configurer la base de connaissances | 30-45 min |
| [05. Memory Setup](setup/05_MEMORY_SETUP.md) | Configurer la mémoire persistante | 20-30 min |
| [06. Agentflows](setup/06_AGENTFLOWS.md) | Créer les agents spécialisés | 30-45 min |
| [07. Upload Handling](setup/07_UPLOAD_HANDLING.md) | Gérer les uploads de documents | 20-30 min |
| [08. Cron Jobs](setup/08_CRON_JOBS.md) | Automatiser les routines | 15-25 min |
| [09. Complete Configuration](setup/09_COMPLETE_CONFIGURATION.md) | **Configuration complète avec free tiers** | 2-3h |

---

## 🚀 Quick Start

### 1. Installation (30 min)

```bash
# Cloner et installer
cd ~/flowise
docker-compose up -d

# Vérifier
curl http://localhost:3000/api/v1/health
```

### 2. Configuration (1h)

1. [Créer le chatflow principal](setup/02_MAIN_CHATFLOW.md)
2. [Ajouter les custom tools](setup/03_CUSTOM_TOOLS.md)
3. [Configurer le RAG](setup/04_RAG_SETUP.md)

### 3. Test (15 min)

```bash
# Test via API
curl -X POST http://localhost:3000/api/v1/chatflows/largo-main/predict \
  -H "Content-Type: application/json" \
  -d '{"question": "Salut Largo, tu peux me présenter une entreprise ?"}'
```

---

## 📁 Fichiers Uploadables (flowise_kb/)

### Prompts
- `prompts/SYSTEM_PROMPT.md` — System prompt complet pour Largo

### Tools (JSON)
- `tools/search_company.json` — Recherche entreprise
- `tools/get_valuation.json` — Calcul valorisation
- `tools/get_multiples.json` — Multiples sectoriels
- `tools/web_search.json` — Recherche web
- `tools/deep_research.json` — Recherche approfondie
- `tools/generate_document.json` — Génération documents
- `tools/save_memory.json` — Sauvegarde mémoire
- `tools/get_memory.json` — Récupération mémoire
- `tools/delegate_to_agent.json` — Délégation multi-agents
- `tools/send_notification.json` — Notifications
- `tools/query_rag.json` — Interrogation RAG

### Agentflows
- `agentflows/largo_main_agent.json` — Agent principal
- `agentflows/document_agent.json` — Agent documents
- `agentflows/research_agent.json` — Agent recherche
- `agentflows/meeting_agent.json` — Agent réunions
- `agentflows/email_agent.json` — Agent email
- `agentflows/prospect_agent.json` — Agent prospection

### Documents
- `documents/pdf_loader_config.json` — Config PDF loader
- `documents/docx_loader_config.json` — Config DOCX loader
- `documents/csv_loader_config.json` — Config CSV loader
- `documents/knowledge_base_structure.json` — Structure KB

### Memory
- `memory/buffer_memory.json` — Mémoire court terme
- `memory/zep_memory.json` — Mémoire Zep
- `memory/vector_memory.json` — Mémoire vectorielle
- `memory/conversation_store.json` — Stockage conversations

---

## 🏗️ Architecture Flowise

```
┌─────────────────────────────────────────────────────────────┐
│                     FLOWISE PLATFORM                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              LARGO MAIN AGENT                        │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────────────────┐  │   │
│  │  │ System  │→ │ Claude  │→ │     TOOLS           │  │   │
│  │  │ Prompt  │  │  3.5    │  │  - search_company   │  │   │
│  │  └─────────┘  └─────────┘  │  - get_valuation    │  │   │
│  │         ↑                  │  - query_rag        │  │   │
│  │  ┌──────┴──────┐           │  - delegate_to_...  │  │   │
│  │  │Buffer Memory│           └─────────────────────┘  │   │
│  │  └─────────────┘                                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                           │                                  │
│              ┌────────────┼────────────┐                   │
│              ↓            ↓            ↓                   │
│  ┌───────────────┐ ┌──────────┐ ┌──────────────┐         │
│  │ Document Agent│ │ Research │ │ Meeting Agent│         │
│  └───────────────┘ │  Agent   │ └──────────────┘         │
│                    └──────────┘                            │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              INFRASTRUCTURE                          │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────────────────┐  │   │
│  │  │Pinecone │  │  Zep    │  │  PostgreSQL         │  │   │
│  │  │ (RAG)   │  │ (Memory)│  │  (Conversations)    │  │   │
│  │  └─────────┘  └─────────┘  └─────────────────────┘  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 Workflow de Développement

### 1. Créer un nouveau Tool

1. Définir le schéma JSON
2. Implémenter la fonction JavaScript
3. Tester individuellement
4. Intégrer dans le chatflow

### 2. Ajouter au RAG

1. Préparer les documents
2. Configurer le text splitter
3. Uploader via l'interface
4. Tester les requêtes

### 3. Créer un Agent Spécialisé

1. Définir le system prompt
2. Sélectionner les tools
3. Configurer le modèle
4. Tester la délégation

---

## 🛠️ Outils et Services Externes

| Service | Port | Description |
|---------|------|-------------|
| Flowise | 3000 | Plateforme principale |
| mna-research | 8001 | API recherche M&A |
| pptx-generator | 8002 | Génération PowerPoint |
| document-parser | 8004 | Parsing documents |
| web-search | 8005 | Recherche web |
| memory-service | 8006 | Service mémoire |
| agent-delegation | 8007 | Délégation agents |
| notification | 8008 | Notifications |

---

## 📊 Monitoring

### Logs

```bash
# Flowise logs
docker-compose logs -f flowise

# Tous les services
docker-compose logs -f
```

### Métriques

| Métrique | Endpoint |
|----------|----------|
| Health | `GET /api/v1/health` |
| Metrics | `GET /api/v1/metrics` |
| Flows | `GET /api/v1/flows` |

---

## 🔧 Troubleshooting

| Problème | Solution |
|----------|----------|
| Flowise ne démarre pas | Vérifier les ports, les credentials |
| Tools non invoqués | Vérifier la connexion au chat model |
| RAG vide | Vérifier l'index Pinecone |
| Mémoire perdue | Vérifier la configuration Zep |
| Erreurs CORS | Configurer les headers appropriés |

---

## 📚 Ressources Rapides

### Références
- [Free Tiers Cheatsheet](FREE_TIERS_CHEATSHEET.md) — **Référence rapide des options gratuites**
- [Configuration Complète](setup/09_COMPLETE_CONFIGURATION.md) — **Guide complet avec tous les free tiers**

### Documentation Externe
- [Flowise Documentation](https://docs.flowiseai.com/)
- [LangChain JS](https://js.langchain.com/)
- [Pinecone Docs](https://docs.pinecone.io/)
- [Zep Documentation](https://docs.getzep.com/)

---

## 🎯 Par où commencer ?

1. **Vous voulez du rapide ?** → [Free Tiers Cheatsheet](FREE_TIERS_CHEATSHEET.md)
2. **Vous voulez tout configurer ?** → [Configuration Complète](setup/09_COMPLETE_CONFIGURATION.md)
3. **Vous préférez étape par étape ?** → [01. Installation](setup/01_INSTALLATION.md)

---

*Flowise Implementation Guides for Largo 2.0*
