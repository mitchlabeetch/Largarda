# FILE_INDEX.md — Largo 2.0 Knowledge Base Index

> **Version**: 2.0 — Complete Knowledge Base  
> **Files**: 24 documents  
> **Generated**: 2026-03-18

---

## 📚 Documentation Core (9 fichiers)

| Fichier | Description | Priorité |
|---------|-------------|----------|
| [README.md](README.md) | Vue d'ensemble et démarrage rapide | 🔴 CRITIQUE |
| [SOUL.md](SOUL.md) | Philosophie, identité, règles fondamentales | 🔴 CRITIQUE |
| [IDENTITY.md](IDENTITY.md) | Personnalité détaillée et style de communication | 🔴 CRITIQUE |
| [USER.md](USER.md) | Profils utilisateurs et permissions | 🟠 HAUTE |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Architecture technique complète | 🔴 CRITIQUE |
| [API_REFERENCE.md](API_REFERENCE.md) | Documentation de toutes les APIs | 🟠 HAUTE |
| [SKILLS.md](SKILLS.md) | Capacités et workflows n8n | 🟠 HAUTE |
| [MEMORY.md](MEMORY.md) | Système de mémoire PostgreSQL | 🟠 HAUTE |
| [WORKFLOWS.md](WORKFLOWS.md) | Documentation des workflows n8n | 🟡 MOYENNE |

---

## 🚀 Déploiement (4 fichiers)

| Fichier | Description | Usage |
|---------|-------------|-------|
| [DEPLOYMENT.md](DEPLOYMENT.md) | Guide de déploiement complet | Référence |
| [docker-compose.yml](docker-compose.yml) | Configuration Docker | Production |
| [.env.example](.env.example) | Template variables d'environnement | Configuration |
| [init.sql](init.sql) | Initialisation PostgreSQL | Setup |

---

## 🐍 Scripts Python (4 fichiers)

| Fichier | Description | Usage |
|---------|-------------|-------|
| [scripts/france_mna.py](scripts/france_mna.py) | Recherche M&A entreprises françaises | API SIRENE, Pappers |
| [scripts/duckduckgo_search.py](scripts/duckduckgo_search.py) | Recherche web gratuite | News, recherche |
| [scripts/browser_scraper.py](scripts/browser_scraper.py) | Scraping avancé avec Playwright | Deep research |
| [scripts/pappers_api.py](scripts/pappers_api.py) | Client API Pappers | Données entreprises |

---

## 🔧 Microservices (4 fichiers)

| Fichier | Description | Port |
|---------|-------------|------|
| [services/mna-research/Dockerfile](services/mna-research/Dockerfile) | Docker image M&A Research | — |
| [services/mna-research/requirements.txt](services/mna-research/requirements.txt) | Dépendances Python | — |
| [services/mna-research/app.py](services/mna-research/app.py) | Service FastAPI M&A | 8001 |

---

## 📊 Workflows n8n (2 fichiers)

| Fichier | Description | Trigger |
|---------|-------------|---------|
| [workflows/mna/research-company.json](workflows/mna/research-company.json) | Recherche entreprise complète | Webhook |
| [workflows/routines/daily-mna-summary.json](workflows/routines/daily-mna-summary.json) | Résumé M&A quotidien | Cron 9h |

---

## 📁 Structure Complète

```
largo_v2_knowledge_base/
├── README.md                    # Vue d'ensemble
├── SOUL.md                      # Philosophie
├── IDENTITY.md                  # Personnalité
├── USER.md                      # Utilisateurs
├── ARCHITECTURE.md              # Architecture
├── API_REFERENCE.md             # APIs
├── SKILLS.md                    # Capacités
├── MEMORY.md                    # Mémoire
├── WORKFLOWS.md                 # Workflows
├── DEPLOYMENT.md                # Déploiement
├── FILE_INDEX.md               # Ce fichier
│
├── docker-compose.yml           # Docker
├── .env.example                 # Config template
├── init.sql                     # DB init
│
├── scripts/
│   ├── france_mna.py           # M&A France
│   ├── duckduckgo_search.py    # Search
│   ├── browser_scraper.py      # Scraping
│   └── pappers_api.py          # Pappers
│
├── services/
│   └── mna-research/
│       ├── Dockerfile
│       ├── requirements.txt
│       └── app.py
│
└── workflows/
    ├── mna/
    │   └── research-company.json
    └── routines/
        └── daily-mna-summary.json
```

---

## 🎯 Ordre de Lecture Recommandé

### Pour Développeur

1. [README.md](README.md) — Vue d'ensemble
2. [ARCHITECTURE.md](ARCHITECTURE.md) — Architecture
3. [docker-compose.yml](docker-compose.yml) — Infrastructure
4. [API_REFERENCE.md](API_REFERENCE.md) — Intégrations

### Pour Intégration M&A

1. [SOUL.md](SOUL.md) — Philosophie
2. [SKILLS.md](SKILLS.md) — Capacités
3. [scripts/france_mna.py](scripts/france_mna.py) — Recherche
4. [workflows/mna/research-company.json](workflows/mna/research-company.json) — Workflow

### Pour Déploiement

1. [DEPLOYMENT.md](DEPLOYMENT.md) — Guide complet
2. [.env.example](.env.example) — Configuration
3. [docker-compose.yml](docker-compose.yml) — Services
4. [init.sql](init.sql) — Database

---

## 🔄 Prochaines Étapes

### Phase 1: Setup Infrastructure
- [ ] Provisionner VPS (Contabo/Hetzner)
- [ ] Configurer DNS
- [ ] Déployer Docker
- [ ] Configurer n8n

### Phase 2: Intégrations
- [ ] WhatsApp (Baileys)
- [ ] Email (IMAP/SMTP)
- [ ] Microsoft Graph
- [ ] Pipedrive

### Phase 3: M&A Core
- [ ] SIRENE API
- [ ] Pappers API
- [ ] Valuation engine
- [ ] Document generation

### Phase 4: Intelligence
- [ ] Kimi integration
- [ ] Memory system
- [ ] Learning preferences
- [ ] Routines automation

---

*Largo 2.0 — Knowledge Base Complete*
