# WORKFLOWS.md — n8n Workflows Largo 2.0

> Version: 2.0 — n8n Architecture Edition
> Last Updated: 2026-03-18

---

## 🎯 Vue d'Ensemble

Les workflows n8n sont le cœur de Largo 2.0. Ils remplacent le système de skills OpenClaw par une orchestration visuelle et contrôlable.

**Avantages** :
- ✅ Visualisation du flux de données
- ✅ Débogage facilité
- ✅ Pas de code arbitraire (sécurité)
- ✅ Intégrations natives (200+ services)
- ✅ Scheduling intégré

---

## 📁 Structure des Workflows

```
workflows/
├── mna/                      # M&A workflows
│   ├── research-company.json
│   ├── analyze-financials.json
│   ├── generate-valuation.json
│   └── compare-companies.json
│
├── documents/                # Document generation
│   ├── create-excel.json
│   ├── create-pptx.json
│   ├── parse-pdf.json
│   └── summarize-document.json
│
├── communication/            # Messaging
│   ├── send-whatsapp.json
│   ├── send-email.json
│   ├── read-inbox.json
│   └── process-message.json
│
├── routines/                 # Scheduled tasks
│   ├── daily-mna-summary.json
│   ├── meeting-prep.json
│   └── prospect-enrichment.json
│
├── research/                 # Web research
│   ├── web-search.json
│   ├── deep-research.json
│   └── news-monitoring.json
│
└── system/                   # System workflows
    ├── backup-database.json
    ├── health-check.json
    └── error-handler.json
```

---

## 🔍 Workflows M&A

### 1. research-company

**Description** : Recherche complète d'une entreprise française

**Trigger** : Webhook ou manuel

**Input** :
```json
{
  "identifier": "34977287100027",
  "identifier_type": "siret",
  "depth": "full"
}
```

**Flow** :
```
Webhook Trigger
    ↓
Parse Input
    ↓
Parallel API Calls:
    ├── SIRENE API
    ├── Pappers API
    └── recherche-entreprises API
    ↓
Merge Results
    ↓
Kimi Analysis (2M context)
    ↓
Store in PostgreSQL
    ↓
Return JSON Response
```

**Output** :
```json
{
  "entreprise": { /* full profile */ },
  "financials": { /* analysis */ },
  "valuation": { /* range */ },
  "sources": ["sirene", "pappers"]
}
```

---

### 2. analyze-financials

**Description** : Analyse financière approfondie

**Input** :
```json
{
  "siren": "349772871",
  "years": 3,
  "include_benchmark": true
}
```

**Calculs** :
- Ratios de rentabilité (ROE, ROA, marge)
- Ratios de structure (autonomie, endettement)
- Ratios de liquidité
- Évolution temporelle
- Benchmark sectoriel

---

### 3. generate-valuation

**Description** : Génération fourchette de valorisation

**Méthodes** :
1. Multiples sectoriels (préféré)
2. DCF simplifié (si données)
3. Actif net corrigé (si applicable)

**Multiples Small-Mid Cap France** :

| Secteur | EV/EBE | EV/EBITDA |
|---------|--------|-----------|
| Industrie | 5.0x - 7.0x | 4.5x - 6.5x |
| Services | 6.0x - 9.0x | 5.0x - 7.5x |
| Distribution | 4.5x - 6.5x | 4.0x - 6.0x |
| BTP | 4.0x - 6.0x | 3.5x - 5.5x |
| Tech/SaaS | 8.0x - 15.0x | 6.0x - 10.0x |

---

## 📄 Workflows Documents

### 4. create-excel

**Description** : Génération de fichiers Excel

**Features** :
- Formules complexes
- Tableaux croisés dynamiques
- Graphiques
- Formatage conditionnel
- Multi-feuilles

**Input** :
```json
{
  "template": "analyse_prospects",
  "data": {
    "prospects": [...],
    "columns": [...]
  },
  "formatting": {
    "conditional_rules": [...],
    "charts": [...]
  }
}
```

---

### 5. create-pptx

**Description** : Génération PowerPoint depuis templates

**Templates** :
- `executive_summary.pptx`
- `company_profile.pptx`
- `valuation_report.pptx`
- `teaser_acquisition.pptx`

**Microservice** : `pptx-generator:8000`

**Flow** :
```
Webhook Trigger
    ↓
Validate Template
    ↓
Fetch Data (APIs, DB)
    ↓
Call pptx-generator Service
    ↓
Store in MinIO
    ↓
Return Download URL
```

---

## 💬 Workflows Communication

### 6. process-message

**Description** : Traitement des messages entrants

**Trigger** : Webhook (WhatsApp, Email, Slack)

**Flow** :
```
Webhook (message reçu)
    ↓
Identify User
    ↓
Retrieve Context (PostgreSQL)
    ↓
Parse Intent (Kimi)
    ↓
Route to Handler:
    ├── Research → mna/research-company
    ├── Document → documents/create-*
    ├── Info → llm/answer
    └── Unknown → clarification
    ↓
Execute Handler
    ↓
Format Response
    ↓
Send Reply
    ↓
Store Conversation
```

---

### 7. send-whatsapp

**Integration** : Baileys via HTTP Request

**Configuration** :
```json
{
  "method": "POST",
  "url": "http://whatsapp-gateway:8004/send",
  "body": {
    "jid": "={{ $json.recipient_jid }}",
    "message": "={{ $json.message }}",
    "options": {
      "quoted": "={{ $json.quote_message_id }}"
    }
  }
}
```

---

## 🔄 Workflows Routines

### 8. daily-mna-summary

**Schedule** : `0 9 * * *` (9h Europe/Paris)

**Sources** :
- Les Echos (RSS)
- CFNews (RSS)
- Capital Finance (RSS)
- Reuters France (API)

**Flow** :
```
Cron Trigger (9h)
    ↓
Fetch News (RSS/APIs)
    ↓
Deduplicate
    ↓
Kimi Summarization
    ↓
Format WhatsApp Message
    ↓
Send to Christophe
    ↓
Log Execution
```

**Output** :
```
📰 Résumé M&A du 18 mars 2026

🇫🇷 France
• [Titre] — [Source]
  [Résumé 2 lignes]

🇪🇺 Europe
• [Titre] — [Source]
  [Résumé 2 lignes]

📊 Tendance
• [Observation]
```

---

### 9. meeting-prep

**Trigger** : 45 min avant chaque réunion Teams

**Flow** :
```
Microsoft Graph Trigger (calendar)
    ↓
Get Meeting Details
    ↓
Extract Participants
    ↓
For Each Participant:
    ├── Search Pipedrive
    ├── Search Emails
    └── Search Deals
    ↓
Generate Briefing
    ↓
Send WhatsApp (45 min avant)
```

**Output** :
```
📅 Réunion dans 45 min: [Sujet]

👥 Avec: [Nom] ([Entreprise])

📝 Derniers échanges:
• [Date]: [Sujet]

📊 Prospect:
• CA: X M€
• Secteur: [Secteur]

💡 Suggestions:
• [Point à aborder]
```

---

## 🔬 Workflows Recherche

### 10. deep-research

**Description** : Recherche approfondie multi-sources

**Flow** :
```
Webhook Trigger (query)
    ↓
Parallel Search:
    ├── DuckDuckGo
    ├── Brave Search (if configured)
    └── News APIs
    ↓
Scrape Top Results (Playwright)
    ↓
Aggregate Content
    ↓
Kimi Analysis (2M context)
    ↓
Generate Report
    ↓
Return Structured Response
```

---

## ⚙️ Workflows Système

### 11. backup-database

**Schedule** : `0 3 * * *` (3h du matin)

**Flow** :
```
Cron Trigger
    ↓
pg_dump largo_memory
    ↓
gzip
    ↓
upload to S3
    ↓
Cleanup old backups (>30 days)
    ↓
Notify admin (Telegram)
```

---

### 12. health-check

**Schedule** : `*/5 * * * *` (toutes les 5 min)

**Checks** :
- n8n health endpoint
- PostgreSQL connection
- Redis connection
- WhatsApp connection
- LLM APIs availability

**Alert** : Telegram si erreur

---

## 📊 Workflow Templates

### Template: Webhook Handler

```json
{
  "name": "Webhook Handler Template",
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook",
      "name": "Webhook",
      "webhookId": "unique-id"
    },
    {
      "type": "n8n-nodes-base.function",
      "name": "Parse Input"
    },
    {
      "type": "n8n-nodes-base.postgres",
      "name": "Get Context"
    },
    {
      "type": "n8n-nodes-base.httpRequest",
      "name": "Call LLM"
    },
    {
      "type": "n8n-nodes-base.respondToWebhook",
      "name": "Response"
    }
  ]
}
```

### Template: Scheduled Task

```json
{
  "name": "Scheduled Task Template",
  "nodes": [
    {
      "type": "n8n-nodes-base.scheduleTrigger",
      "name": "Schedule",
      "interval": ["0 9 * * *"]
    },
    {
      "type": "n8n-nodes-base.httpRequest",
      "name": "Fetch Data"
    },
    {
      "type": "n8n-nodes-base.function",
      "name": "Process"
    },
    {
      "type": "n8n-nodes-base.telegram",
      "name": "Send Message"
    }
  ]
}
```

---

## 🔧 Création de Workflows

### Bonnes Pratiques

1. **Nommer clairement** : `category-action-target`
2. **Documenter** : Description dans chaque workflow
3. **Gérer les erreurs** : Error branch sur chaque node risqué
4. **Limiter la taille** : < 50 nodes par workflow
5. **Utiliser les sub-workflows** : Pour la réutilisation

### Variables d'Environnement

```
{{ $env.KIMI_API_KEY }}
{{ $env.CLAUDE_API_KEY }}
{{ $env.PAPPERS_API_KEY }}
```

### Credentials

```
{{ $credentials.kimiApi }}
{{ $credentials.postgresLargo }}
```

---

## 📈 Monitoring Workflows

### Métriques

| Métrique | Source | Alert |
|----------|--------|-------|
| Execution time | n8n metrics | > 30s |
| Error rate | n8n metrics | > 5% |
| API cost | api_calls table | > €10/jour |
| Queue size | Redis | > 100 |

### Dashboard

```sql
-- Daily workflow stats
SELECT 
    workflow_name,
    COUNT(*) as executions,
    AVG(EXTRACT(EPOCH FROM (finished_at - started_at))) as avg_duration,
    COUNT(CASE WHEN status = 'error' THEN 1 END) as errors
FROM executions
WHERE started_at > NOW() - INTERVAL '24 hours'
GROUP BY workflow_name;
```

---

*Largo 2.0 — Workflows orchestrés, processus maîtrisés.*
