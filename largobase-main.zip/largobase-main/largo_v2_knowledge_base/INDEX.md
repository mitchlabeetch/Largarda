# LARGO 2.0 — MASTER INDEX & NAVIGATION

> **Version**: 2.0-Flowise — Knowledge Base complète  
> **Déploiement**: Flowise Assistant  
> **Mis à jour**: 2026-04-12  
> **Fichiers**: 101 (vérifiés)

---

## 🚀 DÉMARRAGE RAPIDE — FLOWISE

**Nouveau sur Flowise ?** → [FLOWISE_COMPLETE_GUIDE.md](FLOWISE_COMPLETE_GUIDE.md) — Configuration complète 0€  
**Référence rapide free tiers ?** → [flowise_guides/FREE_TIERS_CHEATSHEET.md](flowise_guides/FREE_TIERS_CHEATSHEET.md)  
**Erreur 400 / problème API ?** → [flowise_guides/TROUBLESHOOTING_400_ERROR.md](flowise_guides/TROUBLESHOOTING_400_ERROR.md)  
**Résumé de l'implémentation ?** → [FLOWISE_SUMMARY.md](FLOWISE_SUMMARY.md)  
**Nouveau utilisateur (Christophe) ?** → [QUICKSTART.md](QUICKSTART.md)

---

## 🧭 NAVIGATION PAR RÔLE

| Je suis... | Commencer par... |
|------------|------------------|
| **Christophe (Utilisateur)** | [QUICKSTART.md](QUICKSTART.md) |
| **Développeur Flowise** | [flowise_guides/README.md](flowise_guides/README.md) → [flowise_kb/INDEX.md](flowise_kb/INDEX.md) |
| **Intégrateur M&A** | [knowledge/mna/FRAMEWORK.md](knowledge/mna/FRAMEWORK.md) |
| **Documentaliste** | [knowledge/documents/](knowledge/documents/) |
| **Administrateur** | [DEPLOYMENT.md](DEPLOYMENT.md) → [deploy.sh](deploy.sh) |
| **Développeur microservices** | [dev/README.md](dev/README.md) → [services/](services/) |

---

## 🏗️ ARCHITECTURE FLOWISE (PRIMAIRE)

```
┌──────────────────────────────────────────────────────┐
│               LARGO MAIN AGENT (Flowise)              │
│  System Prompt + LLM + Buffer Memory + 11 Tools       │
└────────────────────────┬─────────────────────────────┘
                         │ delegate_to_agent
         ┌───────────────┼───────────────┐
         ↓               ↓               ↓
  document_agent   research_agent   meeting_agent
  email_agent      prospect_agent
         │
         ↓
┌──────────────────────────────────────────────────────┐
│               INFRASTRUCTURE (Free Tier)              │
│  Vector Store (Chroma/Pinecone) • Zep Memory          │
│  LLM (Groq/Ollama/Kimi) • Embeddings (HuggingFace)   │
│  Web Search (DuckDuckGo/Brave)                        │
└──────────────────────────────────────────────────────┘
```

| Composant Flowise | Fichier | Description |
|-------------------|---------|-------------|
| **System Prompt** | [flowise_kb/prompts/SYSTEM_PROMPT.md](flowise_kb/prompts/SYSTEM_PROMPT.md) | Prompt principal Largo |
| **Tools (11)** | [flowise_kb/tools/](flowise_kb/tools/) | Custom Tools JSON |
| **Agentflows (6)** | [flowise_kb/agentflows/](flowise_kb/agentflows/) | Agents spécialisés |
| **RAG / Doc Loaders** | [flowise_kb/documents/](flowise_kb/documents/) | Configs Vector Store |
| **Mémoire (4 configs)** | [flowise_kb/memory/](flowise_kb/memory/) | Buffer, Zep, Vector, Store |
| **Guide complet** | [flowise_guides/setup/09_COMPLETE_CONFIGURATION.md](flowise_guides/setup/09_COMPLETE_CONFIGURATION.md) | Tous les free tiers |

---

## 📁 STRUCTURE RÉELLE DES FICHIERS

```
largo_v2_knowledge_base/
│
├── INDEX.md                         ← VOUS ÊTES ICI
├── README.md                        → Vue d'ensemble projet
├── QUICKSTART.md                    → Guide démarrage Christophe
├── SOUL.md                          → Philosophie & identité
├── IDENTITY.md                      → Personnalité détaillée
├── USER.md                          → Profils utilisateurs
├── MEMORY.md                        → Système de mémoire
├── ARCHITECTURE.md                  → Architecture technique (Flowise + n8n)
├── API_REFERENCE.md                 → Référence APIs
├── SKILLS.md                        → Capacités et workflows
├── WORKFLOWS.md                     → Documentation workflows
├── DEPLOYMENT.md                    → Guide déploiement
├── FILE_INDEX.md                    → Index détaillé des fichiers
├── SUMMARY.md                       → Résumé du projet
├── ENRICHMENT_SUMMARY.md            → Résumé enrichissements KB
├── IMPLEMENTATION_SUMMARY.md        → Résumé implémentation
│
├── FLOWISE_COMPLETE_GUIDE.md        ← FLOWISE — Guide complet (100% gratuit)
├── FLOWISE_IMPLEMENTATION.md        ← FLOWISE — Détails implémentation
├── FLOWISE_SUMMARY.md               ← FLOWISE — Résumé et livrables
│
├── flowise_kb/                      ← FLOWISE — FICHIERS UPLOADABLES
│   ├── INDEX.md                     → Index des fichiers Flowise
│   ├── prompts/
│   │   └── SYSTEM_PROMPT.md         → Prompt principal Largo
│   ├── tools/                       → 11 Custom Tools
│   │   ├── search_company.json      → Recherche entreprise SIRENE/Pappers
│   │   ├── get_valuation.json       → Calcul valorisation multiples
│   │   ├── get_multiples.json       → Multiples sectoriels M&A
│   │   ├── web_search.json          → Recherche web DuckDuckGo/Brave
│   │   ├── deep_research.json       → Recherche approfondie multi-sources
│   │   ├── generate_document.json   → Génération PowerPoint/Word/Excel
│   │   ├── save_memory.json         → Sauvegarde mémoire persistante
│   │   ├── get_memory.json          → Récupération mémoire
│   │   ├── delegate_to_agent.json   → Délégation multi-agents
│   │   ├── send_notification.json   → Notifications WhatsApp/Email
│   │   └── query_rag.json           → Interrogation base de connaissances
│   ├── agentflows/                  → 6 Agents spécialisés
│   │   ├── largo_main_agent.json    → Agent principal orchestrateur
│   │   ├── document_agent.json      → Génération de documents
│   │   ├── research_agent.json      → Recherche et veille M&A
│   │   ├── meeting_agent.json       → Préparation et suivi réunions
│   │   ├── email_agent.json         → Gestion des communications
│   │   └── prospect_agent.json      → Enrichissement prospects
│   ├── documents/                   → 4 Configs document loaders
│   │   ├── pdf_loader_config.json
│   │   ├── docx_loader_config.json
│   │   ├── csv_loader_config.json
│   │   └── knowledge_base_structure.json
│   └── memory/                      → 4 Configs mémoire
│       ├── buffer_memory.json
│       ├── zep_memory.json
│       ├── vector_memory.json
│       └── conversation_store.json
│
├── flowise_guides/                  ← FLOWISE — GUIDES DÉTAILLÉS
│   ├── README.md                    → Vue d'ensemble et navigation
│   ├── FREE_TIERS_CHEATSHEET.md     → Référence rapide free tiers
│   ├── TROUBLESHOOTING_400_ERROR.md → Résolution erreur 400
│   └── setup/                       → 9 guides de configuration
│       ├── 01_INSTALLATION.md       → Installation Flowise + Docker
│       ├── 02_MAIN_CHATFLOW.md      → Création chatflow principal
│       ├── 03_CUSTOM_TOOLS.md       → Création des custom tools
│       ├── 04_RAG_SETUP.md          → Configuration base de connaissances
│       ├── 05_MEMORY_SETUP.md       → Configuration mémoire persistante
│       ├── 06_AGENTFLOWS.md         → Création agents spécialisés
│       ├── 07_UPLOAD_HANDLING.md    → Gestion des uploads
│       ├── 08_CRON_JOBS.md          → Tâches planifiées
│       └── 09_COMPLETE_CONFIGURATION.md → Config complète 0€
│
├── dev/                             ← DOCUMENTATION DÉVELOPPEUR
│   └── README.md                    → Démarrage développeur
│
├── .env.example                     → Variables d'environnement
├── docker-compose.yml               → Configuration Docker
├── init.sql                         → Schéma PostgreSQL
├── deploy.sh                        → Script déploiement complet
│
├── knowledge/                       ← CONNAISSANCES MÉTIER
│   ├── mna/                         → Framework M&A
│   │   ├── FRAMEWORK.md             → Méthodologie M&A
│   │   ├── VALUATION.md             → Valorisation
│   │   ├── GLOSSARY.md              → Glossaire M&A
│   │   └── GOLDEN_RULES.md          → Règles d'or M&A
│   │
│   ├── france/                      → Écosystème France
│   │   ├── ECOSYSTEM.md             → Vue d'ensemble
│   │   ├── COTE_AZUR_MA.md          → M&A Côte d'Azur
│   │   ├── INVESTMENT_LAW.md        → Droit de l'investissement
│   │   └── TAX_LAW.md               → Fiscalité
│   │
│   ├── documents/                   → Création documents
│   │   ├── EXCEL.md                 → Excel avancé
│   │   └── POWERPOINT.md            → PowerPoint templates
│   │
│   ├── composio/                    → Intégration Composio
│   │   └── COMPOSIO_INTEGRATION.md  → Guide Composio
│   │
│   └── tools/                       → Outils disponibles
│       └── FREE_TOOLS.md            → Outils gratuits
│
├── scripts/                         ← SCRIPTS PYTHON
│   ├── france_mna.py                → Recherche entreprises FR
│   ├── pappers_api.py               → API Pappers
│   ├── duckduckgo_search.py         → Recherche web DuckDuckGo
│   ├── browser_scraper.py           → Scraping avancé
│   ├── mna/
│   │   └── valuation.py             → Valorisation complète
│   ├── documents/
│   │   └── pptx_generator.py        → Génération PowerPoint
│   └── utils/
│       └── llm_router.py            → Routage LLM (Kimi/Claude)
│
├── workflows/                       ← WORKFLOWS N8N (JSON exportables)
│   ├── mna/
│   │   ├── research-company.json    → Recherche entreprise
│   │   └── generate-valuation.json  → Génération valorisation
│   ├── documents/
│   │   └── create-pptx.json         → Création PowerPoint
│   ├── communication/
│   │   └── process-message.json     → Traitement messages WhatsApp
│   └── routines/
│       ├── daily-mna-summary.json   → Résumé M&A quotidien
│       └── prospect-enrichment.json → Enrichissement prospects
│
└── services/                        ← MICROSERVICES DOCKER
    ├── pptx-generator/              → Service PowerPoint (Flask)
    ├── mna-research/                → Service recherche M&A
    ├── document-parser/             → Parser documents (OCR)
    └── whatsapp-gateway/            → Gateway WhatsApp (Node.js)
```

---

## 🔍 INDEX PAR SUJET

### M&A — Fusion-Acquisition

| Sujet | Fichier |
|-------|---------|
| Méthodologie | [knowledge/mna/FRAMEWORK.md](knowledge/mna/FRAMEWORK.md) |
| Valorisation | [knowledge/mna/VALUATION.md](knowledge/mna/VALUATION.md) |
| Glossaire | [knowledge/mna/GLOSSARY.md](knowledge/mna/GLOSSARY.md) |
| Règles d'or | [knowledge/mna/GOLDEN_RULES.md](knowledge/mna/GOLDEN_RULES.md) |
| Recherche entreprise (script) | [scripts/france_mna.py](scripts/france_mna.py) |
| API Pappers (script) | [scripts/pappers_api.py](scripts/pappers_api.py) |
| Workflow recherche | [workflows/mna/research-company.json](workflows/mna/research-company.json) |
| Workflow valorisation | [workflows/mna/generate-valuation.json](workflows/mna/generate-valuation.json) |

### France — Écosystème

| Sujet | Fichier |
|-------|---------|
| Vue d'ensemble | [knowledge/france/ECOSYSTEM.md](knowledge/france/ECOSYSTEM.md) |
| Côte d'Azur M&A | [knowledge/france/COTE_AZUR_MA.md](knowledge/france/COTE_AZUR_MA.md) |
| Droit de l'investissement | [knowledge/france/INVESTMENT_LAW.md](knowledge/france/INVESTMENT_LAW.md) |
| Fiscalité | [knowledge/france/TAX_LAW.md](knowledge/france/TAX_LAW.md) |

### Documents

| Sujet | Fichier |
|-------|---------|
| Excel | [knowledge/documents/EXCEL.md](knowledge/documents/EXCEL.md) |
| PowerPoint | [knowledge/documents/POWERPOINT.md](knowledge/documents/POWERPOINT.md) |
| Génération PPTX (script) | [scripts/documents/pptx_generator.py](scripts/documents/pptx_generator.py) |
| Workflow PPTX | [workflows/documents/create-pptx.json](workflows/documents/create-pptx.json) |

### Flowise — Configuration

| Sujet | Fichier |
|-------|---------|
| Guide complet | [FLOWISE_COMPLETE_GUIDE.md](FLOWISE_COMPLETE_GUIDE.md) |
| Résumé implémentation | [FLOWISE_SUMMARY.md](FLOWISE_SUMMARY.md) |
| Détails techniques | [FLOWISE_IMPLEMENTATION.md](FLOWISE_IMPLEMENTATION.md) |
| Free tiers cheatsheet | [flowise_guides/FREE_TIERS_CHEATSHEET.md](flowise_guides/FREE_TIERS_CHEATSHEET.md) |
| Troubleshooting 400 | [flowise_guides/TROUBLESHOOTING_400_ERROR.md](flowise_guides/TROUBLESHOOTING_400_ERROR.md) |
| Tous les guides setup | [flowise_guides/setup/](flowise_guides/setup/) |

### Outils & Intégrations

| Sujet | Fichier |
|-------|---------|
| Outils gratuits | [knowledge/tools/FREE_TOOLS.md](knowledge/tools/FREE_TOOLS.md) |
| Composio | [knowledge/composio/COMPOSIO_INTEGRATION.md](knowledge/composio/COMPOSIO_INTEGRATION.md) |
| Recherche web (script) | [scripts/duckduckgo_search.py](scripts/duckduckgo_search.py) |
| Scraping (script) | [scripts/browser_scraper.py](scripts/browser_scraper.py) |
| Routage LLM (script) | [scripts/utils/llm_router.py](scripts/utils/llm_router.py) |

---

## ⚡ QUICK START FLOWISE

### 1. Installer et lancer Flowise

```bash
docker-compose up -d
# Interface : http://localhost:3000
```

### 2. Importer les tools (11 JSON)

Dans Flowise → **Tools** → **Add New** → coller le contenu de chaque fichier dans `flowise_kb/tools/`.

### 3. Créer le chatflow principal

1. **Chatflows** → **New Chatflow** → nommer `Largo Main Agent`
2. Copier le contenu de [flowise_kb/prompts/SYSTEM_PROMPT.md](flowise_kb/prompts/SYSTEM_PROMPT.md) dans le nœud System Prompt
3. Choisir le modèle : Groq (llama-3.3-70b) ou Ollama
4. Ajouter les 11 tools importés
5. Ajouter Buffer Memory (k=10)

### 4. Configurer le RAG

Voir [flowise_guides/setup/04_RAG_SETUP.md](flowise_guides/setup/04_RAG_SETUP.md) — uploader les fichiers `knowledge/` dans le Vector Store.

### 5. Tester

```
"Salut Largo, recherche l'entreprise SIREN 123456789"
```

---

## 📊 STATISTIQUES (FICHIERS RÉELS)

| Catégorie | Nombre |
|-----------|--------|
| Documentation racine | 18 |
| **Flowise Tools JSON** | **11** |
| **Flowise Agentflows** | **6** |
| Flowise doc loaders | 4 |
| Flowise memory configs | 4 |
| **Flowise Guides** | **12** (9 setup + 3 autres) |
| Knowledge (MD) | 14 |
| Scripts Python | 7 |
| Workflows n8n (JSON) | 6 |
| Microservices | 4 (avec Docker) |
| **Coût mensuel Flowise** | **0€ (100% free tier)** |

---

## 🔄 MISES À JOUR

| Date | Version | Changements |
|------|---------|-------------|
| 2026-04-12 | 2.0-Flowise | Ajout guides Flowise, troubleshooting, config complète |
| 2026-03-18 | 2.0 | Version initiale complète |

---

*Largo 2.0 — Index maître Flowise. Seuls les fichiers réellement présents sont référencés.*
