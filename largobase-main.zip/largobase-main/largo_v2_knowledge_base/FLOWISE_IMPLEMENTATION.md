# LARGO 2.0 — Flowise Implementation Summary

> **Date**: 18 Mars 2026  
> **Version**: 2.0-Flowise  
> **Status**: ✅ Complete

---

## 🎯 Objectif

Transformer Largo d'une architecture n8n + PostgreSQL vers une architecture **Flowise native** avec :
- Agents autonomes avec RAG
- Custom Tools pour les APIs M&A
- Mémoire persistante (Zep + Vector)
- Multi-agent orchestration
- Gestion des uploads
- Tâches planifiées

---

## 📦 Livrables

### 1. flowise_kb/ — Fichiers Uploadables

#### Prompts (1)
| Fichier | Description |
|---------|-------------|
| `prompts/SYSTEM_PROMPT.md` | System prompt complet pour l'agent Largo |

#### Tools (11)
| Fichier | Fonction |
|---------|----------|
| `tools/search_company.json` | Recherche entreprise SIRENE/Pappers |
| `tools/get_valuation.json` | Calcul valorisation multiples |
| `tools/get_multiples.json` | Multiples sectoriels M&A |
| `tools/web_search.json` | Recherche web DuckDuckGo/Brave |
| `tools/deep_research.json` | Recherche approfondie multi-sources |
| `tools/generate_document.json` | Génération PowerPoint/Word/Excel |
| `tools/save_memory.json` | Sauvegarde mémoire persistante |
| `tools/get_memory.json` | Récupération mémoire |
| `tools/delegate_to_agent.json` | Délégation multi-agents |
| `tools/send_notification.json` | Notifications WhatsApp/Email |
| `tools/query_rag.json` | Interrogation base de connaissances |

#### Agentflows (6)
| Fichier | Rôle |
|---------|------|
| `agentflows/largo_main_agent.json` | Agent principal orchestrateur |
| `agentflows/document_agent.json` | Génération de documents |
| `agentflows/research_agent.json` | Recherche et veille M&A |
| `agentflows/meeting_agent.json` | Préparation et suivi réunions |
| `agentflows/email_agent.json` | Gestion des communications |
| `agentflows/prospect_agent.json` | Enrichissement prospects |

#### Documents (4)
| Fichier | Description |
|---------|-------------|
| `documents/pdf_loader_config.json` | Configuration PDF loader |
| `documents/docx_loader_config.json` | Configuration DOCX loader |
| `documents/csv_loader_config.json` | Configuration CSV loader |
| `documents/knowledge_base_structure.json` | Structure de la base de connaissances |

#### Memory (4)
| Fichier | Type |
|---------|------|
| `memory/buffer_memory.json` | Mémoire court terme (session) |
| `memory/zep_memory.json` | Mémoire long terme persistante |
| `memory/vector_memory.json` | Mémoire vectorielle (préférences) |
| `memory/conversation_store.json` | Stockage des conversations |

### 2. flowise_guides/ — Guides Détaillés

#### Setup Guides (8)
| Guide | Contenu |
|-------|---------|
| `setup/01_INSTALLATION.md` | Installation Flowise + Docker |
| `setup/02_MAIN_CHATFLOW.md` | Création chatflow principal |
| `setup/03_CUSTOM_TOOLS.md` | Création des custom tools |
| `setup/04_RAG_SETUP.md` | Configuration base de connaissances |
| `setup/05_MEMORY_SETUP.md` | Configuration mémoire persistante |
| `setup/06_AGENTFLOWS.md` | Création agents spécialisés |
| `setup/07_UPLOAD_HANDLING.md` | Gestion des uploads |
| `setup/08_CRON_JOBS.md` | Tâches planifiées |

#### Documentation
| Fichier | Description |
|---------|-------------|
| `flowise_guides/README.md` | Vue d'ensemble et navigation |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        LARGO 2.0 — FLOWISE                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   LARGO MAIN AGENT                       │   │
│   │                                                          │   │
│   │   System Prompt (Identity + Tools + RAG + Memory)        │   │
│   │                    ↓                                     │   │
│   │   Chat Model (Claude 3.5 / GPT-4 / Kimi)                 │   │
│   │                    ↓                                     │   │
│   │   ┌─────────────────────────────────────────────────┐   │   │
│   │   │  TOOLS                                          │   │   │
│   │   │  • search_company    • get_valuation           │   │   │
│   │   │  • web_search        • deep_research           │   │   │
│   │   │  • generate_document • save/get_memory         │   │   │
│   │   │  • delegate_to_agent • send_notification       │   │   │
│   │   │  • query_rag                                    │   │   │
│   │   └─────────────────────────────────────────────────┘   │   │
│   │                    ↓                                     │   │
│   │   Buffer Memory (10 derniers échanges)                   │   │
│   └─────────────────────────────────────────────────────────┘   │
│                              │                                   │
│           ┌──────────────────┼──────────────────┐              │
│           ↓                  ↓                  ↓              │
│   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐      │
│   │Document Agent│   │Research Agent│   │Meeting Agent │      │
│   └──────────────┘   └──────────────┘   └──────────────┘      │
│                                                                  │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │                   INFRASTRUCTURE                         │   │
│   │                                                          │   │
│   │   ┌──────────┐  ┌──────────┐  ┌─────────────────────┐   │   │
│   │   │ Pinecone │  │   Zep    │  │     PostgreSQL      │   │   │
│   │   │  (RAG)   │  │ (Memory) │  │  (Conversations)    │   │   │
│   │   └──────────┘  └──────────┘  └─────────────────────┘   │   │
│   │                                                          │   │
│   │   ┌──────────┐  ┌──────────┐  ┌─────────────────────┐   │   │
│   │   │mna-res.  │  │  pptx    │  │   document-parser   │   │   │
│   │   │  :8001   │  │  :8002   │  │       :8004         │   │   │
│   │   └──────────┘  └──────────┘  └─────────────────────┘   │   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Démarrage Rapide

### 1. Installation

```bash
# 1. Installer Flowise
cd ~/flowise
docker-compose up -d

# 2. Copier les fichiers kb
cp -r flowise_kb/* ~/flowise/

# 3. Configurer les credentials
# - OpenAI / Anthropic / Moonshot
# - Pinecone
# - Zep (optionnel)
```

### 2. Configuration

```bash
# 1. Créer le chatflow principal
# Voir setup/02_MAIN_CHATFLOW.md

# 2. Importer les tools
# Flowise → Tools → Import → Sélectionner les JSON

# 3. Configurer le RAG
# Voir setup/04_RAG_SETUP.md

# 4. Uploader les documents
# Flowise → Document Stores → Upload
```

### 3. Test

```bash
# Test via API
curl -X POST http://localhost:3000/api/v1/chatflows/largo-main/predict \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Recherche l'entreprise SIREN 123456789"
  }'
```

---

## 📊 Comparaison n8n vs Flowise

| Aspect | n8n (Ancien) | Flowise (Nouveau) |
|--------|--------------|-------------------|
| **Paradigme** | Workflows visuels | Agents + Tools |
| **RAG** | Manuel (nœuds HTTP) | Natif (Vector Store) |
| **Mémoire** | PostgreSQL manuel | Zep natif |
| **LLM** | Appels API explicites | Intégré au chat model |
| **Multi-agent** | Complexe | Délégation native |
| **Uploads** | Webhooks manuels | File Upload node |
| **Maintenance** | Plus complexe | Simplifiée |

---

## 💰 Coûts

| Service | Coût mensuel |
|---------|--------------|
| VPS (Flowise + services) | 15€ |
| Pinecone (Vector Store) | ~70€ (ou Chroma gratuit) |
| Claude 3.5 API | ~10-20€ |
| Kimi API (alternative) | ~5€ |
| **Total** | **~30-100€** |

**Économie vs OpenClaw** : ~80-90% de réduction

---

## 🔄 Migration depuis n8n

### Étape 1 : Exporter les données

```bash
# Exporter les workflows n8n
n8n export:workflow --all

# Exporter la base PostgreSQL
pg_dump largo > largo_backup.sql
```

### Étape 2 : Transformer en Flowise

| n8n Workflow | Flowise Équivalent |
|--------------|-------------------|
| `research-company.json` | Tool `search_company` |
| `generate-valuation.json` | Tool `get_valuation` |
| `daily-mna-summary.json` | Cron job + Agentflow |
| `prospect-enrichment.json` | Agent `prospect_agent` |

### Étape 3 : Migrer les données

```bash
# Importer dans Pinecone
python migrate_to_pinecone.py

# Importer les conversations
python migrate_conversations.py
```

---

## 📈 Prochaines Étapes

### Court terme (1-2 semaines)
- [ ] Déployer Flowise sur VPS
- [ ] Importer les tools
- [ ] Configurer le RAG
- [ ] Tester l'agent principal

### Moyen terme (1 mois)
- [ ] Créer les agents spécialisés
- [ ] Configurer les cron jobs
- [ ] Intégrer WhatsApp
- [ ] Former Christophe

### Long terme (3 mois)
- [ ] Fine-tuning des prompts
- [ ] Ajout de nouveaux tools
- [ ] Analytics et monitoring
- [ ] Documentation utilisateur

---

## 📚 Ressources

### Documentation
- [Flowise Docs](https://docs.flowiseai.com/)
- [LangChain JS](https://js.langchain.com/)
- [Pinecone Docs](https://docs.pinecone.io/)

### Fichiers de référence
- `flowise_kb/prompts/SYSTEM_PROMPT.md`
- `flowise_guides/README.md`
- `flowise_guides/setup/01_INSTALLATION.md`

---

## ✅ Checklist Implémentation

### Phase 1 : Infrastructure
- [ ] Installer Flowise
- [ ] Configurer Docker Compose
- [ ] Mettre en place PostgreSQL
- [ ] Configurer Pinecone (ou Chroma)

### Phase 2 : Core
- [ ] Créer le chatflow principal
- [ ] Importer le system prompt
- [ ] Créer les custom tools
- [ ] Configurer le RAG

### Phase 3 : Memory
- [ ] Configurer Buffer Memory
- [ ] Installer Zep (optionnel)
- [ ] Créer tools save/get_memory
- [ ] Tester la persistance

### Phase 4 : Agents
- [ ] Créer Document Agent
- [ ] Créer Research Agent
- [ ] Créer Meeting Agent
- [ ] Tester la délégation

### Phase 5 : Intégrations
- [ ] Configurer WhatsApp
- [ ] Configurer Email
- [ ] Gérer les uploads
- [ ] Créer les cron jobs

### Phase 6 : Production
- [ ] Tests complets
- [ ] Monitoring
- [ ] Backup automatique
- [ ] Documentation

---

*Flowise Implementation for Largo 2.0 — Complete*
