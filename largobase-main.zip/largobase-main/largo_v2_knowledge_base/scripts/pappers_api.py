#!/usr/bin/env python3
"""
pappers_api.py - Module d'intégration API Pappers
Largo 2.0 - n8n Architecture Edition

API Pappers: https://www.pappers.fr/api
Documentation: https://www.pappers.fr/api/documentation
"""

import requests
import json
import os
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
from datetime import datetime
import logging

# Configuration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration API
PAPPERS_API_URL = "https://api.pappers.fr/v2"
PAPPERS_API_KEY = os.getenv("PAPPERS_API_KEY", "")


class PappersAPI:
    """Client API Pappers"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or PAPPERS_API_KEY
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json"
        })
    
    def _make_request(self, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """Effectue une requête API"""
        if not self.api_key:
            logger.error("Clé API Pappers non configurée")
            return {"error": "Clé API Pappers non configurée"}
        
        url = f"{PAPPERS_API_URL}/{endpoint}"
        params = params or {}
        params["api_token"] = self.api_key
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if response.status_code == 404:
                logger.warning(f"Entreprise non trouvée: {params}")
                return {"error": "Entreprise non trouvée"}
            elif response.status_code == 429:
                logger.error("Limite API Pappers atteinte")
                return {"error": "Limite API atteinte"}
            else:
                logger.error(f"Erreur HTTP Pappers: {e}")
                return {"error": f"Erreur HTTP {response.status_code}"}
        except requests.exceptions.RequestException as e:
            logger.error(f"Erreur requête Pappers: {e}")
            return {"error": str(e)}
    
    def get_entreprise(self, siren: str = None, siret: str = None) -> Dict:
        """
        Récupère les informations d'une entreprise
        
        Args:
            siren: Numéro SIREN (9 chiffres)
            siret: Numéro SIRET (14 chiffres)
        
        Returns:
            Données entreprise
        """
        params = {}
        if siren:
            params["siren"] = siren.replace(" ", "").replace("-", "")
        elif siret:
            params["siret"] = siret.replace(" ", "").replace("-", "")
        else:
            return {"error": "SIREN ou SIRET requis"}
        
        logger.info(f"Récupération entreprise: {siren or siret}")
        return self._make_request("entreprise", params)
    
    def search(self, query: str, page: int = 1, par_page: int = 10) -> Dict:
        """
        Recherche d'entreprises
        
        Args:
            query: Terme de recherche (nom, SIREN, etc.)
            page: Numéro de page
            par_page: Résultats par page
        
        Returns:
            Résultats de recherche
        """
        params = {
            "q": query,
            "page": page,
            "par_page": par_page
        }
        
        logger.info(f"Recherche Pappers: '{query}'")
        return self._make_request("recherche", params)
    
    def get_documents(self, siren: str) -> Dict:
        """
        Récupère la liste des documents disponibles
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Liste des documents
        """
        params = {"siren": siren}
        logger.info(f"Récupération documents pour {siren}")
        return self._make_request("documents", params)
    
    def download_document(self, siren: str, document_type: str, 
                          token: str = None, format: str = "pdf") -> Dict:
        """
        Télécharge un document
        
        Args:
            siren: Numéro SIREN
            document_type: Type de document (kbis, statutes, etc.)
            token: Token de téléchargement (si requis)
            format: Format (pdf, etc.)
        
        Returns:
            URL de téléchargement ou données
        """
        params = {
            "siren": siren,
            "type": document_type,
            "format": format
        }
        if token:
            params["token"] = token
        
        logger.info(f"Téléchargement document {document_type} pour {siren}")
        return self._make_request("document/telecharger", params)
    
    def get_beneficiaires(self, siren: str) -> Dict:
        """
        Récupère les bénéficiaires effectifs
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Liste des bénéficiaires
        """
        entreprise = self.get_entreprise(siren=siren)
        return {
            "siren": siren,
            "beneficiaires": entreprise.get("beneficiaires_effectifs", [])
        }
    
    def get_dirigeants(self, siren: str) -> Dict:
        """
        Récupère les dirigeants
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Liste des dirigeants
        """
        entreprise = self.get_entreprise(siren=siren)
        return {
            "siren": siren,
            "dirigeants": entreprise.get("dirigeants", [])
        }
    
    def get_financials(self, siren: str) -> Dict:
        """
        Récupère les données financières
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Données financières
        """
        entreprise = self.get_entreprise(siren=siren)
        
        return {
            "siren": siren,
            "chiffres_affaires": entreprise.get("chiffres_affaires", []),
            "ratios": {
                "rentabilite": entreprise.get("rentabilite", {}),
                "structure_financiere": entreprise.get("structure_financiere", {}),
                "equilibre_financier": entreprise.get("equilibre_financier", {}),
                "liquidite": entreprise.get("liquidite", {})
            },
            "capital": entreprise.get("capital", {}),
            "evolution_effectif": entreprise.get("evolution_effectif", [])
        }
    
    def get_etablissements(self, siren: str) -> Dict:
        """
        Récupère les établissements
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Liste des établissements
        """
        entreprise = self.get_entreprise(siren=siren)
        return {
            "siren": siren,
            "etablissements": entreprise.get("etablissements", []),
            "nombre_etablissements": entreprise.get("nombre_etablissements", 0)
        }
    
    def get_related_companies(self, siren: str) -> Dict:
        """
        Récupère les entreprises liées (mêmes dirigeants/bénéficiaires)
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Entreprises liées
        """
        entreprise = self.get_entreprise(siren=siren)
        return {
            "siren": siren,
            "entreprises_liées": entreprise.get("entreprises_liées", []),
            "nombre_entreprises_liées": entreprise.get("nombre_entreprises_liées", 0)
        }
    
    def full_profile(self, siren: str) -> Dict:
        """
        Profil complet d'une entreprise
        
        Args:
            siren: Numéro SIREN
        
        Returns:
            Profil complet
        """
        logger.info(f"Profil complet pour {siren}")
        
        entreprise = self.get_entreprise(siren=siren)
        
        if "error" in entreprise:
            return entreprise
        
        # Construction profil
        profile = {
            "identite": {
                "siren": entreprise.get("siren"),
                "siret": entreprise.get("siret"),
                "denomination": entreprise.get("nom_entreprise"),
                "forme_juridique": entreprise.get("forme_juridique"),
                "categorie_juridique": entreprise.get("categorie_juridique"),
                "date_creation": entreprise.get("date_creation"),
                "date_creation_formate": entreprise.get("date_creation_formate"),
                "duree_personne_morale": entreprise.get("duree_personne_morale")
            },
            "activite": {
                "code_naf": entreprise.get("code_naf"),
                "libelle_naf": entreprise.get("libelle_code_naf"),
                "domaine_activite": entreprise.get("domaine_activite"),
                "activite": entreprise.get("activite")
            },
            "effectif": {
                "tranche": entreprise.get("effectif"),
                "min": entreprise.get("effectif_min"),
                "max": entreprise.get("effectif_max"),
                "annee": entreprise.get("annee_effectif"),
                "evolution": entreprise.get("evolution_effectif", [])
            },
            "siege": entreprise.get("siege", {}),
            "etablissements": entreprise.get("etablissements", []),
            "dirigeants": entreprise.get("dirigeants", []),
            "beneficiaires_effectifs": entreprise.get("beneficiaires_effectifs", []),
            "financials": {
                "chiffres_affaires": entreprise.get("chiffres_affaires", []),
                "ratios": {
                    "rentabilite": entreprise.get("rentabilite", {}),
                    "structure": entreprise.get("structure_financiere", {})
                }
            },
            "documents": entreprise.get("documents", []),
            "entreprises_liées": entreprise.get("entreprises_liées", []),
            "scoring": {
                "non_diffusable": entreprise.get("non_diffusable", False),
                "diffusable": entreprise.get("diffusable", True),
                "entreprise_cessee": entreprise.get("entreprise_cessee", False),
                "date_cessation": entreprise.get("date_cessation"),
                "entreprise_employeuse": entreprise.get("entreprise_employeuse", True)
            },
            "metadata": {
                "derniere_mise_a_jour": entreprise.get("derniere_mise_a_jour_sirene"),
                "date_extraction": datetime.now().isoformat(),
                "source": "pappers.fr"
            }
        }
        
        return profile


# Fonctions utilitaires pour n8n

def get_entreprise(siren: str = None, siret: str = None) -> Dict:
    """
    Récupère une entreprise
    Utilisable depuis n8n Function Node
    """
    api = PappersAPI()
    return api.get_entreprise(siren=siren, siret=siret)


def search_entreprises(query: str, max_results: int = 10) -> Dict:
    """
    Recherche d'entreprises
    Utilisable depuis n8n Function Node
    """
    api = PappersAPI()
    results = api.search(query, par_page=max_results)
    
    return {
        "query": query,
        "results_count": results.get("nombre_de_resultats", 0),
        "results": results.get("resultats", [])[:max_results]
    }


def get_financial_profile(siren: str) -> Dict:
    """
    Profil financier complet
    Utilisable depuis n8n Function Node
    """
    api = PappersAPI()
    return api.get_financials(siren)


def full_company_profile(siren: str) -> Dict:
    """
    Profil complet d'entreprise
    Utilisable depuis n8n Function Node
    """
    api = PappersAPI()
    return api.full_profile(siren)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Pappers API for Largo")
    parser.add_argument("action", choices=["get", "search", "financials", "profile"])
    parser.add_argument("value", help="SIREN, SIRET, or search query")
    
    args = parser.parse_args()
    
    api = PappersAPI()
    
    if args.action == "get":
        # Détecter SIREN vs SIRET
        value_clean = args.value.replace(" ", "").replace("-", "")
        if len(value_clean) == 14:
            result = api.get_entreprise(siret=value_clean)
        else:
            result = api.get_entreprise(siren=value_clean)
    elif args.action == "search":
        result = api.search(args.value)
    elif args.action == "financials":
        result = api.get_financials(args.value)
    elif args.action == "profile":
        result = api.full_profile(args.value)
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
