#!/usr/bin/env python3
"""
france_mna.py - Module de recherche M&A pour entreprises françaises
Largo 2.0 - n8n Architecture Edition

Ce module fournit des fonctions pour rechercher et analyser des entreprises
françaises via les APIs SIRENE, Pappers, et autres sources.
"""

import requests
import json
import os
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
from datetime import datetime
import logging

# Configuration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration APIs
INSEE_API_URL = "https://api.insee.fr/entreprises/sirene/V3.11"
PAPPERS_API_URL = "https://api.pappers.fr/v2"
RECHERCHE_ENTREPRISES_URL = "https://recherche-entreprises.api.gouv.fr"

# Credentials (à configurer via variables d'environnement)
INSEE_TOKEN = os.getenv("INSEE_API_TOKEN", "")
PAPPERS_API_KEY = os.getenv("PAPPERS_API_KEY", "")


@dataclass
class EntrepriseData:
    """Structure de données pour une entreprise"""
    siren: str
    siret: Optional[str] = None
    denomination: str = ""
    forme_juridique: str = ""
    date_creation: Optional[str] = None
    code_naf: str = ""
    libelle_naf: str = ""
    effectif: str = ""
    capital: Optional[int] = None
    siege: Dict = None
    dirigeants: List[Dict] = None
    beneficiaires: List[Dict] = None
    financials: Dict = None
    documents: List[Dict] = None
    
    def to_dict(self) -> Dict:
        return {
            "siren": self.siren,
            "siret": self.siret,
            "denomination": self.denomination,
            "forme_juridique": self.forme_juridique,
            "date_creation": self.date_creation,
            "code_naf": self.code_naf,
            "libelle_naf": self.libelle_naf,
            "effectif": self.effectif,
            "capital": self.capital,
            "siege": self.siege or {},
            "dirigeants": self.dirigeants or [],
            "beneficiaires": self.beneficiaires or [],
            "financials": self.financials or {},
            "documents": self.documents or []
        }


class FranceMNAResearcher:
    """Classe principale pour la recherche M&A en France"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json"
        })
        
    def _make_request(self, url: str, headers: Dict = None, params: Dict = None) -> Optional[Dict]:
        """Effectue une requête HTTP avec gestion d'erreurs"""
        try:
            response = self.session.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Erreur requête {url}: {e}")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Erreur JSON {url}: {e}")
            return None
    
    def search_by_siret(self, siret: str) -> Optional[EntrepriseData]:
        """Recherche une entreprise par SIRET"""
        logger.info(f"Recherche par SIRET: {siret}")
        
        # Nettoyage SIRET
        siret = siret.replace(" ", "").replace("-", "")
        
        # Recherche via API publique (sans auth)
        url = f"{RECHERCHE_ENTREPRISES_URL}/search?q={siret}"
        data = self._make_request(url)
        
        if not data or not data.get("results"):
            logger.warning(f"Aucun résultat pour SIRET {siret}")
            return None
        
        result = data["results"][0]
        return self._parse_recherche_entreprises_result(result)
    
    def search_by_siren(self, siren: str) -> Optional[EntrepriseData]:
        """Recherche une entreprise par SIREN"""
        logger.info(f"Recherche par SIREN: {siren}")
        
        # Nettoyage SIREN
        siren = siren.replace(" ", "").replace("-", "")
        
        url = f"{RECHERCHE_ENTREPRISES_URL}/search?q={siren}"
        data = self._make_request(url)
        
        if not data or not data.get("results"):
            logger.warning(f"Aucun résultat pour SIREN {siren}")
            return None
        
        result = data["results"][0]
        return self._parse_recherche_entreprises_result(result)
    
    def search_by_name(self, name: str, code_postal: str = None) -> List[EntrepriseData]:
        """Recherche des entreprises par nom"""
        logger.info(f"Recherche par nom: {name}")
        
        params = {"q": name}
        if code_postal:
            params["code_postal"] = code_postal
        
        url = f"{RECHERCHE_ENTREPRISES_URL}/search"
        data = self._make_request(url, params=params)
        
        if not data or not data.get("results"):
            logger.warning(f"Aucun résultat pour {name}")
            return []
        
        return [self._parse_recherche_entreprises_result(r) for r in data["results"]]
    
    def _parse_recherche_entreprises_result(self, result: Dict) -> EntrepriseData:
        """Parse un résultat de l'API recherche-entreprises"""
        siege = result.get("siege", {})
        
        return EntrepriseData(
            siren=result.get("siren", ""),
            siret=siege.get("siret"),
            denomination=result.get("nom_complet", ""),
            forme_juridique=result.get("forme_juridique", ""),
            date_creation=result.get("date_creation"),
            code_naf=result.get("activite_principale", ""),
            libelle_naf=result.get("libelle_activite_principale", ""),
            effectif=result.get("effectif", ""),
            capital=result.get("capital", None),
            siege={
                "adresse": siege.get("adresse", ""),
                "code_postal": siege.get("code_postal", ""),
                "commune": siege.get("commune", ""),
                "pays": "FRANCE"
            }
        )
    
    def get_pappers_data(self, siren: str) -> Dict:
        """Récupère les données complémentaires depuis Pappers"""
        if not PAPPERS_API_KEY:
            logger.warning("Clé API Pappers non configurée")
            return {}
        
        logger.info(f"Récupération données Pappers pour {siren}")
        
        url = f"{PAPPERS_API_URL}/entreprise"
        params = {
            "siren": siren,
            "api_token": PAPPERS_API_KEY
        }
        
        data = self._make_request(url, params=params)
        
        if not data:
            return {}
        
        return {
            "dirigeants": data.get("dirigeants", []),
            "beneficiaires": data.get("beneficiaires_effectifs", []),
            "documents": data.get("documents", []),
            "ratios": {
                "rentabilite": data.get("rentabilite", {}),
                "structure": data.get("structure_financiere", {})
            },
            "capital": data.get("capital", {}),
            "chiffres_affaires": data.get("chiffres_affaires", [])
        }
    
    def get_insee_data(self, siret: str) -> Dict:
        """Récupère les données depuis l'API INSEE SIRENE"""
        if not INSEE_TOKEN:
            logger.warning("Token INSEE non configuré")
            return {}
        
        logger.info(f"Récupération données INSEE pour {siret}")
        
        url = f"{INSEE_API_URL}/siret/{siret}"
        headers = {"Authorization": f"Bearer {INSEE_TOKEN}"}
        
        data = self._make_request(url, headers=headers)
        
        if not data:
            return {}
        
        etablissement = data.get("etablissement", {})
        unite_legale = etablissement.get("uniteLegale", {})
        
        return {
            "siret": etablissement.get("siret"),
            "siren": unite_legale.get("siren"),
            "denomination": unite_legale.get("denominationUniteLegale"),
            "forme_juridique": unite_legale.get("categorieJuridiqueUniteLegale"),
            "date_creation": unite_legale.get("dateCreationUniteLegale"),
            "activite_principale": etablissement.get("activitePrincipaleEtablissement"),
            "tranche_effectif": etablissement.get("trancheEffectifsEtablissement"),
            "adresse": {
                "numero": etablissement.get("adresseEtablissement", {}).get("numeroVoieEtablissement"),
                "voie": etablissement.get("adresseEtablissement", {}).get("libelleVoieEtablissement"),
                "code_postal": etablissement.get("adresseEtablissement", {}).get("codePostalEtablissement"),
                "commune": etablissement.get("adresseEtablissement", {}).get("libelleCommuneEtablissement")
            }
        }
    
    def full_research(self, identifier: str, identifier_type: str = "auto") -> Dict:
        """Recherche complète d'une entreprise"""
        logger.info(f"Recherche complète: {identifier} (type: {identifier_type})")
        
        # Détection automatique du type
        if identifier_type == "auto":
            identifier_clean = identifier.replace(" ", "").replace("-", "")
            if len(identifier_clean) == 14 and identifier_clean.isdigit():
                identifier_type = "siret"
            elif len(identifier_clean) == 9 and identifier_clean.isdigit():
                identifier_type = "siren"
            else:
                identifier_type = "name"
        
        # Recherche selon le type
        if identifier_type == "siret":
            entreprise = self.search_by_siret(identifier)
        elif identifier_type == "siren":
            entreprise = self.search_by_siren(identifier)
        else:
            results = self.search_by_name(identifier)
            entreprise = results[0] if results else None
        
        if not entreprise:
            return {"error": f"Entreprise non trouvée: {identifier}"}
        
        # Enrichissement avec Pappers
        pappers_data = self.get_pappers_data(entreprise.siren)
        
        # Enrichissement avec INSEE si SIRET disponible
        insee_data = {}
        if entreprise.siret:
            insee_data = self.get_insee_data(entreprise.siret)
        
        # Assemblage du résultat
        result = {
            "entreprise": entreprise.to_dict(),
            "pappers": pappers_data,
            "insee": insee_data,
            "recherche_date": datetime.now().isoformat(),
            "sources": ["recherche-entreprises.api.gouv.fr"]
        }
        
        if pappers_data:
            result["sources"].append("pappers.fr")
        if insee_data:
            result["sources"].append("api.insee.fr")
        
        return result
    
    def analyze_financials(self, siren: str, years: int = 3) -> Dict:
        """Analyse financière d'une entreprise"""
        logger.info(f"Analyse financière pour {siren}")
        
        # Récupération données Pappers
        pappers_data = self.get_pappers_data(siren)
        chiffres_affaires = pappers_data.get("chiffres_affaires", [])
        
        if not chiffres_affaires:
            return {"error": "Données financières non disponibles"}
        
        # Tri par année décroissante
        chiffres_affaires.sort(key=lambda x: x.get("annee", 0), reverse=True)
        recent_data = chiffres_affaires[:years]
        
        # Calcul des ratios
        analysis = {
            "historique_ca": [],
            "croissance": {},
            "moyennes": {},
            "tendances": {}
        }
        
        cas = [c.get("ca", 0) for c in recent_data if c.get("ca")]
        resultats = [c.get("resultat", 0) for c in recent_data if c.get("resultat")]
        
        if cas:
            analysis["historique_ca"] = [
                {"annee": c.get("annee"), "ca": c.get("ca"), "resultat": c.get("resultat")}
                for c in recent_data
            ]
            
            # Croissance
            if len(cas) >= 2:
                croissance = ((cas[0] - cas[1]) / cas[1] * 100) if cas[1] else 0
                analysis["croissance"] = {
                    "derniere_annee": round(croissance, 2),
                    "tendance": "hausse" if croissance > 5 else "baisse" if croissance < -5 else "stable"
                }
            
            # Moyennes
            analysis["moyennes"] = {
                "ca_3ans": round(sum(cas) / len(cas), 0) if cas else 0,
                "marge_nette": round(sum(resultats) / sum(cas) * 100, 2) if cas and resultats else 0
            }
        
        return analysis
    
    def get_valuation_range(self, siren: str, sector: str = None) -> Dict:
        """Calcule une fourchette de valorisation"""
        logger.info(f"Valorisation pour {siren}")
        
        # Récupération données
        research = self.full_research(siren, "siren")
        
        if "error" in research:
            return research
        
        entreprise = research.get("entreprise", {})
        pappers = research.get("pappers", {})
        
        # Détection secteur si non fourni
        if not sector:
            code_naf = entreprise.get("code_naf", "")
            sector = self._detect_sector_from_naf(code_naf)
        
        # Récupération EBE (ou estimation)
        chiffres = pappers.get("chiffres_affaires", [])
        ebe = None
        
        if chiffres:
            dernier = chiffres[0]
            ca = dernier.get("ca", 0)
            resultat = dernier.get("resultat", 0)
            # Estimation EBE = Résultat + Charges (approximation)
            ebe = resultat * 1.5 if resultat > 0 else ca * 0.08
        
        if not ebe or ebe <= 0:
            return {"error": "EBE non disponible ou négatif"}
        
        # Multiples sectoriels (Small-Mid Cap France)
        multiples = {
            "industrie": (4.5, 6.5),
            "services": (5.0, 7.5),
            "distribution": (4.0, 6.0),
            "btp": (3.5, 5.5),
            "tech": (6.0, 10.0),
            "conseil": (5.0, 8.0),
            "default": (4.5, 6.5)
        }
        
        mult_min, mult_max = multiples.get(sector, multiples["default"])
        
        valuation = {
            "methode": "Multiples sectoriels (EV/EBE)",
            "ebe": round(ebe, 0),
            "secteur": sector,
            "multiple_min": mult_min,
            "multiple_max": mult_max,
            "fourchette_basse": round(ebe * mult_min, 0),
            "fourchette_haute": round(ebe * mult_max, 0),
            "fourchette_formatee": f"{round(ebe * mult_min / 1000000, 1)}M€ - {round(ebe * mult_max / 1000000, 1)}M€",
            "hypotheses": [
                f"EBE estimé à {round(ebe / 1000, 0)}k€",
                f"Multiple {sector}: {mult_min}x - {mult_max}x EBE",
                "Fourchette indicative pour small-mid cap France"
            ]
        }
        
        return valuation
    
    def _detect_sector_from_naf(self, code_naf: str) -> str:
        """Détecte le secteur à partir du code NAF"""
        if not code_naf:
            return "default"
        
        # Mapping simplifié
        if code_naf.startswith(("62", "63", "73")):
            return "tech"
        elif code_naf.startswith(("70", "71", "74")):
            return "conseil"
        elif code_naf.startswith(("10", "20", "25", "28")):
            return "industrie"
        elif code_naf.startswith(("45", "46", "47")):
            return "distribution"
        elif code_naf.startswith(("41", "42", "43")):
            return "btp"
        elif code_naf.startswith(("55", "56", "79")):
            return "services"
        
        return "default"


# Fonction utilitaire pour n8n
def research_company(identifier: str, identifier_type: str = "auto", depth: str = "full") -> Dict:
    """
    Fonction principale pour la recherche d'entreprise
    Utilisable directement depuis n8n (Function Node)
    """
    researcher = FranceMNAResearcher()
    
    result = researcher.full_research(identifier, identifier_type)
    
    if depth == "full":
        # Ajout analyse financière
        if "entreprise" in result and result["entreprise"].get("siren"):
            siren = result["entreprise"]["siren"]
            result["financial_analysis"] = researcher.analyze_financials(siren)
            result["valuation"] = researcher.get_valuation_range(siren)
    
    return result


if __name__ == "__main__":
    # Test
    import sys
    
    if len(sys.argv) > 1:
        identifier = sys.argv[1]
        result = research_company(identifier)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print("Usage: python france_mna.py <SIRET/SIREN/Nom>")
