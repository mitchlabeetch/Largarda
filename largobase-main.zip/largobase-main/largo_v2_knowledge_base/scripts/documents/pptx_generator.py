#!/usr/bin/env python3
"""
pptx_generator.py — Générateur de présentations PowerPoint
Largo 2.0 — PowerPoint generation for M&A documents

Usage:
    python pptx_generator.py --template executive_summary --data data.json --output out.pptx
"""

import json
import argparse
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import os

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RgbColor
    from pptx.enum.text import PP_ALIGN
    from pptx.enum.shapes import MSO_SHAPE
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False
    print("Warning: python-pptx not installed. PowerPoint generation disabled.")


# Couleurs Alecia
ALECIA_COLORS = {
    "primary": (31, 78, 121),      # Bleu foncé
    "secondary": (112, 173, 71),    # Vert
    "accent": (197, 90, 17),        # Orange
    "text": (51, 51, 51),           # Gris foncé
    "light_bg": (242, 242, 242),    # Gris clair
    "white": (255, 255, 255)
}


class PowerPointGenerator:
    """Générateur de présentations PowerPoint"""
    
    def __init__(self, templates_dir: str = "templates/pptx"):
        self.templates_dir = templates_dir
        self.colors = ALECIA_COLORS
    
    def generate(
        self,
        template: str,
        data: Dict[str, Any],
        output_path: str
    ) -> Dict[str, Any]:
        """Génère une présentation PowerPoint"""
        
        if not PPTX_AVAILABLE:
            return {"error": "python-pptx not installed"}
        
        # Charger template ou créer nouveau
        template_path = os.path.join(self.templates_dir, f"{template}.pptx")
        if os.path.exists(template_path):
            prs = Presentation(template_path)
        else:
            prs = Presentation()
        
        # Mettre à jour slides existants
        self._update_title_slide(prs, data)
        self._update_content_slides(prs, data)
        
        # Sauvegarder
        prs.save(output_path)
        
        return {
            "success": True,
            "output_path": output_path,
            "slide_count": len(prs.slides),
            "template_used": template
        }
    
    def _update_title_slide(self, prs: Presentation, data: Dict):
        """Met à jour la slide de titre"""
        if not prs.slides:
            return
        
        slide = prs.slides[0]
        
        # Titre
        if slide.shapes.title:
            slide.shapes.title.text = data.get("project_name", "Projet M&A")
        
        # Sous-titre
        for shape in slide.placeholders:
            if shape.placeholder_format.type == 2:  # SUBTITLE
                shape.text = data.get("date", datetime.now().strftime("%d/%m/%Y"))
    
    def _update_content_slides(self, prs: Presentation, data: Dict):
        """Met à jour les slides de contenu"""
        
        # Slide entreprise
        if "company" in data:
            self._add_company_slide(prs, data["company"])
        
        # Slide financière
        if "financials" in data:
            self._add_financials_slide(prs, data["financials"])
        
        # Slide valorisation
        if "valuation" in data:
            self._add_valuation_slide(prs, data["valuation"])
        
        # Slide next steps
        if "next_steps" in data:
            self._add_next_steps_slide(prs, data["next_steps"])
    
    def _add_company_slide(self, prs: Presentation, company: Dict):
        """Ajoute une slide entreprise"""
        slide_layout = prs.slide_layouts[1]  # Title and Content
        slide = prs.slides.add_slide(slide_layout)
        
        slide.shapes.title.text = "Profil de l'Entreprise"
        
        content = f"""
{company.get('name', 'N/A')}

📍 Localisation: {company.get('location', 'N/A')}
👥 Effectif: {company.get('employees', 'N/A')} personnes
🏢 Activité: {company.get('activity', 'N/A')}
🆔 SIREN: {company.get('siren', 'N/A')}
        """.strip()
        
        body_shape = slide.placeholders[1]
        body_shape.text = content
    
    def _add_financials_slide(self, prs: Presentation, financials: Dict):
        """Ajoute une slide financière"""
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        
        slide.shapes.title.text = "Données Financières"
        
        content = f"""
Chiffre d'affaires: {financials.get('ca', 'N/A')}
EBITDA: {financials.get('ebitda', 'N/A')}
Marge EBITDA: {financials.get('margin', 'N/A')}

Valeur d'entreprise indicative:
{financials.get('ev', 'N/A')}
        """.strip()
        
        body_shape = slide.placeholders[1]
        body_shape.text = content
    
    def _add_valuation_slide(self, prs: Presentation, valuation: Dict):
        """Ajoute une slide valorisation"""
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        
        slide.shapes.title.text = "Valorisation"
        
        content = f"""
Méthode: Multiples sectoriels

Fourchette de valeur:
{valuation.get('range', 'N/A')}

Multiple appliqué:
{valuation.get('multiple', 'N/A')}
        """.strip()
        
        body_shape = slide.placeholders[1]
        body_shape.text = content
    
    def _add_next_steps_slide(self, prs: Presentation, next_steps: List[str]):
        """Ajoute une slide prochaines étapes"""
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        
        slide.shapes.title.text = "Prochaines Étapes"
        
        content = "\n".join(f"• {step}" for step in next_steps)
        
        body_shape = slide.placeholders[1]
        body_shape.text = content
    
    def generate_teaser(
        self,
        sector: str,
        location: str,
        ca_range: str,
        ebitda_margin: str,
        employees: int,
        highlights: List[str],
        output_path: str
    ) -> Dict[str, Any]:
        """Génère un teaser anonymisé"""
        
        if not PPTX_AVAILABLE:
            return {"error": "python-pptx not installed"}
        
        prs = Presentation()
        
        # Slide 1: Titre
        slide_layout = prs.slide_layouts[6]  # Blank
        slide = prs.slides.add_slide(slide_layout)
        
        title_box = slide.shapes.add_textbox(
            Inches(1), Inches(2), Inches(8), Inches(1.5)
        )
        title_frame = title_box.text_frame
        title_frame.text = "OPPORTUNITÉ D'ACQUISITION"
        title_frame.paragraphs[0].font.size = Pt(44)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RgbColor(*self.colors["primary"])
        
        # Slide 2: Résumé
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        slide.shapes.title.text = "Résumé de l'Opportunité"
        
        content = f"""
Secteur: {sector}
Localisation: {location}
Chiffre d'affaires: {ca_range}
Marge EBITDA: {ebitda_margin}
Effectif: {employees} personnes

Points forts:
{chr(10).join(f"• {h}" for h in highlights)}
        """.strip()
        
        body_shape = slide.placeholders[1]
        body_shape.text = content
        
        # Sauvegarder
        prs.save(output_path)
        
        return {
            "success": True,
            "output_path": output_path,
            "slide_count": len(prs.slides)
        }


def main():
    parser = argparse.ArgumentParser(description="PowerPoint Generator for Largo")
    parser.add_argument("--template", type=str, required=True, help="Template name")
    parser.add_argument("--data", type=str, required=True, help="JSON data file")
    parser.add_argument("--output", type=str, required=True, help="Output PPTX file")
    parser.add_argument("--teaser", action="store_true", help="Generate teaser")
    
    args = parser.parse_args()
    
    generator = PowerPointGenerator()
    
    if args.teaser:
        with open(args.data) as f:
            data = json.load(f)
        result = generator.generate_teaser(
            sector=data.get("sector", ""),
            location=data.get("location", ""),
            ca_range=data.get("ca_range", ""),
            ebitda_margin=data.get("ebitda_margin", ""),
            employees=data.get("employees", 0),
            highlights=data.get("highlights", []),
            output_path=args.output
        )
    else:
        with open(args.data) as f:
            data = json.load(f)
        result = generator.generate(
            template=args.template,
            data=data,
            output_path=args.output
        )
    
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
