#!/usr/bin/env python3
"""
llm_router.py — Routage intelligent des requêtes LLM
Largo 2.0 — Route requests to Kimi (90%) or Claude (10%) based on task type

Usage:
    python llm_router.py --task research --prompt "Analyze this company..."
"""

import os
import json
import argparse
from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum
import requests


class TaskType(Enum):
    """Types de tâches pour routage"""
    RESEARCH = "research"           # Kimi (2M context)
    ANALYSIS = "analysis"           # Kimi
    SUMMARIZE = "summarize"         # Kimi
    CREATIVE = "creative"           # Kimi
    REVIEW = "review"               # Claude (quality critical)
    COMPLEX_REASONING = "complex"   # Claude
    CLIENT_FACING = "client"        # Claude
    CODE = "code"                   # Claude


# Configuration des modèles
MODELS = {
    "kimi": {
        "endpoint": "https://api.moonshot.cn/v1/chat/completions",
        "model": "kimi-k2-0711-preview",
        "context": 2000000,  # 2M tokens
        "cost_input": 0.50,   # $ per 1M tokens
        "cost_output": 1.00,  # $ per 1M tokens
    },
    "claude": {
        "endpoint": "https://api.anthropic.com/v1/messages",
        "model": "claude-3-5-sonnet-20241022",
        "context": 200000,   # 200K tokens
        "cost_input": 3.00,   # $ per 1M tokens
        "cost_output": 15.00, # $ per 1M tokens
    }
}


# Routage par type de tâche
TASK_ROUTING = {
    TaskType.RESEARCH: "kimi",
    TaskType.ANALYSIS: "kimi",
    TaskType.SUMMARIZE: "kimi",
    TaskType.CREATIVE: "kimi",
    TaskType.REVIEW: "claude",
    TaskType.COMPLEX_REASONING: "claude",
    TaskType.CLIENT_FACING: "claude",
    TaskType.CODE: "claude",
}


class LLMRouter:
    """Routeur intelligent LLM"""
    
    def __init__(self):
        self.kimi_key = os.getenv("KIMI_API_KEY", "")
        self.claude_key = os.getenv("CLAUDE_API_KEY", "")
        self.models = MODELS
    
    def route_task(self, task_type: TaskType) -> str:
        """Détermine le modèle optimal pour une tâche"""
        return TASK_ROUTING.get(task_type, "kimi")
    
    def call_kimi(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000
    ) -> Dict:
        """Appelle l'API Kimi"""
        
        if not self.kimi_key:
            return {"error": "KIMI_API_KEY not configured"}
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        headers = {
            "Authorization": f"Bearer {self.kimi_key}",
            "Content-Type": "application/json"
        }
        
        body = {
            "model": self.models["kimi"]["model"],
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            response = requests.post(
                self.models["kimi"]["endpoint"],
                headers=headers,
                json=body,
                timeout=120
            )
            response.raise_for_status()
            data = response.json()
            
            return {
                "success": True,
                "model": "kimi",
                "content": data["choices"][0]["message"]["content"],
                "usage": data.get("usage", {}),
                "cost": self._calculate_cost("kimi", data.get("usage", {}))
            }
        except Exception as e:
            return {"error": str(e), "model": "kimi"}
    
    def call_claude(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000
    ) -> Dict:
        """Appelle l'API Claude"""
        
        if not self.claude_key:
            return {"error": "CLAUDE_API_KEY not configured"}
        
        headers = {
            "x-api-key": self.claude_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json"
        }
        
        body = {
            "model": self.models["claude"]["model"],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        if system_prompt:
            body["system"] = system_prompt
        
        try:
            response = requests.post(
                self.models["claude"]["endpoint"],
                headers=headers,
                json=body,
                timeout=120
            )
            response.raise_for_status()
            data = response.json()
            
            usage = data.get("usage", {})
            return {
                "success": True,
                "model": "claude",
                "content": data["content"][0]["text"],
                "usage": usage,
                "cost": self._calculate_cost("claude", usage)
            }
        except Exception as e:
            return {"error": str(e), "model": "claude"}
    
    def _calculate_cost(self, model: str, usage: Dict) -> float:
        """Calcule le coût d'un appel"""
        model_config = self.models[model]
        
        input_tokens = usage.get("prompt_tokens", 0) or usage.get("input_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0) or usage.get("output_tokens", 0)
        
        input_cost = (input_tokens / 1_000_000) * model_config["cost_input"]
        output_cost = (output_tokens / 1_000_000) * model_config["cost_output"]
        
        return round(input_cost + output_cost, 6)
    
    def complete(
        self,
        prompt: str,
        task_type: TaskType = TaskType.RESEARCH,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000,
        force_model: Optional[str] = None
    ) -> Dict:
        """
        Complète une requête avec le modèle optimal
        
        Args:
            prompt: Prompt utilisateur
            task_type: Type de tâche pour routage
            system_prompt: Instructions système
            temperature: Créativité (0-1)
            max_tokens: Limite tokens
            force_model: Forcer un modèle spécifique
        
        Returns:
            Réponse avec métadonnées
        """
        # Déterminer le modèle
        if force_model:
            model = force_model
        else:
            model = self.route_task(task_type)
        
        # Appeler le modèle approprié
        if model == "kimi":
            result = self.call_kimi(prompt, system_prompt, temperature, max_tokens)
        else:
            result = self.call_claude(prompt, system_prompt, temperature, max_tokens)
        
        # Ajouter métadonnées de routage
        result["routed_to"] = model
        result["task_type"] = task_type.value
        
        return result
    
    def research_deep(
        self,
        query: str,
        context: Optional[str] = None,
        max_tokens: int = 8000
    ) -> Dict:
        """Recherche approfondie avec Kimi (2M context)"""
        
        system_prompt = """Tu es un analyste M&A senior spécialisé dans les small-mid cap françaises.
        Fournis des analyses approfondies, sourcées et structurées.
        Utilise le vocabulaire M&A français (EBE, CA, multiples, etc.)."""
        
        prompt = f"""Requête: {query}
        
        {f"Contexte additionnel:\n{context}" if context else ""}
        
        Fournis une analyse structurée avec:
        1. Résumé exécutif
        2. Points clés
        3. Analyse détaillée
        4. Sources et références
        5. Recommandations
        """
        
        return self.complete(
            prompt=prompt,
            task_type=TaskType.RESEARCH,
            system_prompt=system_prompt,
            max_tokens=max_tokens
        )
    
    def review_document(
        self,
        document: str,
        document_type: str = "general"
    ) -> Dict:
        """Revue qualité avec Claude"""
        
        system_prompt = """Tu es un expert en révision de documents M&A.
        Analyse la qualité, la cohérence et la pertinence du document.
        Identifie les erreurs, omissions et points à améliorer."""
        
        prompt = f"""Document type: {document_type}
        
        Document à réviser:
        {document}
        
        Fournis:
        1. Évaluation globale
        2. Points forts
        3. Points à améliorer
        4. Erreurs identifiées
        5. Suggestions de modifications
        """
        
        return self.complete(
            prompt=prompt,
            task_type=TaskType.REVIEW,
            system_prompt=system_prompt,
            temperature=0.2
        )


def main():
    parser = argparse.ArgumentParser(description="LLM Router for Largo")
    parser.add_argument("--task", type=str, default="research",
                       choices=[t.value for t in TaskType],
                       help="Type de tâche")
    parser.add_argument("--prompt", type=str, required=True, help="Prompt")
    parser.add_argument("--system", type=str, help="System prompt")
    parser.add_argument("--temperature", type=float, default=0.3)
    parser.add_argument("--max-tokens", type=int, default=4000)
    parser.add_argument("--force-model", type=str, choices=["kimi", "claude"])
    parser.add_argument("--pretty", action="store_true", help="Sortie formatée")
    
    args = parser.parse_args()
    
    router = LLMRouter()
    
    result = router.complete(
        prompt=args.prompt,
        task_type=TaskType(args.task),
        system_prompt=args.system,
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        force_model=args.force_model
    )
    
    if args.pretty and "content" in result:
        print("\n" + "="*60)
        print(f"RÉPONSE ({result.get('routed_to', 'unknown').upper()})")
        print("="*60)
        print(result["content"])
        print("\n" + "-"*60)
        print(f"Coût: ${result.get('cost', 0):.6f}")
        if "usage" in result:
            usage = result["usage"]
            print(f"Tokens: {usage.get('prompt_tokens', 0)} in / {usage.get('completion_tokens', 0)} out")
        print("="*60)
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
