#!/usr/bin/env python3
"""
valuation.py — Moteur de valorisation M&A
Largo 2.0 — Valuation Engine for French Small-Mid Cap

Usage:
    python valuation.py --ebitda 500000 --sector services --pretty
    python valuation.py --dcf --projections projections.json --wacc 0.12
"""

import json
import argparse
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime


# Multiples sectoriels France (Small-Mid Cap)
SECTOR_MULTIPLES = {
    "industrie": {"ebitda": (4.5, 6.5), "ebe": (5.0, 7.0), "ca": (0.8, 1.5)},
    "industrie_alimentaire": {"ebitda": (5.0, 7.0), "ebe": (5.5, 7.5), "ca": (0.6, 1.2)},
    "services_informatique": {"ebitda": (6.0, 9.0), "ebe": (7.0, 11.0), "ca": (1.0, 2.0)},
    "services_conseil": {"ebitda": (5.0, 8.0), "ebe": (6.0, 10.0), "ca": (0.8, 1.5)},
    "distribution_alimentaire": {"ebitda": (4.0, 6.0), "ebe": (4.5, 6.5), "ca": (0.15, 0.30)},
    "distribution_specialisee": {"ebitda": (4.5, 6.5), "ebe": (5.0, 7.0), "ca": (0.4, 0.8)},
    "btp_gros_oeuvre": {"ebitda": (3.5, 5.0), "ebe": (4.0, 5.5), "ca": (0.15, 0.25)},
    "btp_second_oeuvre": {"ebitda": (4.0, 5.5), "ebe": (4.5, 6.0), "ca": (0.20, 0.35)},
    "hotellerie": {"ebitda": (5.0, 7.0), "ebe": (6.0, 8.0), "ca": (1.5, 3.0)},
    "restauration": {"ebitda": (4.0, 6.0), "ebe": (4.5, 6.5), "ca": (0.5, 1.0)},
    "transport": {"ebitda": (4.0, 5.5), "ebe": (4.5, 6.0), "ca": (0.4, 0.7)},
    "logistique": {"ebitda": (4.5, 6.0), "ebe": (5.0, 6.5), "ca": (0.5, 0.8)},
    "sante": {"ebitda": (5.5, 8.0), "ebe": (6.5, 10.0), "ca": (0.8, 1.5)},
    "edition_media": {"ebitda": (4.5, 6.5), "ebe": (5.0, 7.5), "ca": (0.8, 1.5)},
    "immobilier": {"ebitda": (8.0, 12.0), "ebe": (10.0, 15.0), "ca": (2.0, 4.0)},
    "tech_saas": {"ebitda": (6.0, 10.0), "ebe": (8.0, 15.0), "ca": (3.0, 8.0)},
}


@dataclass
class ValuationResult:
    """Résultat d'une valorisation"""
    method: str
    enterprise_value_low: float
    enterprise_value_high: float
    equity_value_low: float
    equity_value_high: float
    multiple_applied: Tuple[float, float]
    assumptions: List[str]
    warnings: List[str]
    timestamp: str


class ValuationEngine:
    """Moteur de valorisation M&A"""
    
    def __init__(self):
        self.sector_multiples = SECTOR_MULTIPLES
    
    def get_sector_multiple(self, sector: str, metric: str = "ebitda") -> Tuple[float, float]:
        """Récupère le multiple sectoriel"""
        sector_lower = sector.lower().replace(" ", "_")
        if sector_lower in self.sector_multiples:
            return self.sector_multiples[sector_lower].get(metric, (5.0, 7.0))
        return (5.0, 7.0)  # Default
    
    def calculate_adjustments(
        self,
        base_multiple: Tuple[float, float],
        growth_rate: float = 0,
        margin: float = 0,
        client_concentration: float = 0,
        debt_ebitda: float = 0,
        recurring_revenue: float = 0
    ) -> Tuple[float, float]:
        """Calcule les ajustements de multiple"""
        low, high = base_multiple
        
        # Croissance
        if growth_rate > 0.15:
            low += 0.5
            high += 1.0
        elif growth_rate > 0.10:
            low += 0.3
            high += 0.5
        elif growth_rate < 0:
            low -= 0.5
            high -= 0.5
        
        # Marge
        if margin > 0.20:
            low += 0.5
            high += 0.5
        elif margin < 0.08:
            low -= 0.5
            high -= 0.5
        
        # Concentration client
        if client_concentration > 0.30:
            low -= 0.5
            high -= 1.0
        
        # Dette
        if debt_ebitda > 3.0:
            low -= 0.5
            high -= 0.5
        
        # Revenu récurrent
        if recurring_revenue > 0.70:
            low += 0.5
            high += 0.5
        
        return (round(low, 1), round(high, 1))
    
    def valuate_by_multiples(
        self,
        ebitda: float,
        sector: str,
        net_debt: float = 0,
        growth_rate: float = 0,
        margin: float = 0,
        client_concentration: float = 0,
        debt_ebitda: float = 0,
        recurring_revenue: float = 0,
        metric: str = "ebitda"
    ) -> Dict:
        """Valorisation par multiples"""
        
        # Multiple de base
        base_multiple = self.get_sector_multiple(sector, metric)
        
        # Ajustements
        adjusted_multiple = self.calculate_adjustments(
            base_multiple,
            growth_rate,
            margin,
            client_concentration,
            debt_ebitda,
            recurring_revenue
        )
        
        # Calcul EV
        ev_low = ebitda * adjusted_multiple[0]
        ev_high = ebitda * adjusted_multiple[1]
        
        # Calcul Equity Value
        equity_low = ev_low - net_debt
        equity_high = ev_high - net_debt
        
        # Hypothèses
        assumptions = [
            f"EBITDA de base: {ebitda:,.0f}€",
            f"Secteur: {sector}",
            f"Multiple de base: {base_multiple[0]}x - {base_multiple[1]}x",
            f"Multiple ajusté: {adjusted_multiple[0]}x - {adjusted_multiple[1]}x",
            f"Dette nette: {net_debt:,.0f}€"
        ]
        
        if growth_rate:
            assumptions.append(f"Croissance: {growth_rate*100:.0f}%")
        if margin:
            assumptions.append(f"Marge EBITDA: {margin*100:.1f}%")
        
        # Warnings
        warnings = []
        if client_concentration > 0.30:
            warnings.append(f"Concentration client élevée ({client_concentration*100:.0f}%)")
        if debt_ebitda > 3.0:
            warnings.append(f"Levier élevé (Dette/EBITDA: {debt_ebitda:.1f}x)")
        
        return {
            "method": "Multiples sectoriels",
            "enterprise_value": {
                "low": ev_low,
                "high": ev_high,
                "formatted": f"{ev_low/1e6:.1f}M€ - {ev_high/1e6:.1f}M€"
            },
            "equity_value": {
                "low": equity_low,
                "high": equity_high,
                "formatted": f"{equity_low/1e6:.1f}M€ - {equity_high/1e6:.1f}M€"
            },
            "multiple": {
                "base": base_multiple,
                "adjusted": adjusted_multiple
            },
            "assumptions": assumptions,
            "warnings": warnings,
            "timestamp": datetime.now().isoformat()
        }
    
    def valuate_by_dcf(
        self,
        projections: List[Dict],
        wacc: float = 0.12,
        terminal_growth: float = 0.025,
        net_debt: float = 0
    ) -> Dict:
        """Valorisation par DCF"""
        
        fcf_values = []
        for i, proj in enumerate(projections):
            ebitda = proj.get("revenue", 0) * proj.get("ebitda_margin", 0.15)
            depreciation = proj.get("depreciation", ebitda * 0.2)
            ebit = ebitda - depreciation
            tax = max(0, ebit * 0.25)
            nopat = ebit - tax
            
            capex = proj.get("capex", 0)
            wc_change = proj.get("wc_change", 0)
            
            fcf = nopat + depreciation - capex - wc_change
            fcf_values.append(fcf)
        
        # Calcul VAN des FCF
        pv_fcf = sum(
            fcf / ((1 + wacc) ** (i + 1))
            for i, fcf in enumerate(fcf_values)
        )
        
        # Valeur terminale
        terminal_fcf = fcf_values[-1] * (1 + terminal_growth)
        terminal_value = terminal_fcf / (wacc - terminal_growth)
        pv_terminal = terminal_value / ((1 + wacc) ** len(fcf_values))
        
        # Enterprise Value
        ev = pv_fcf + pv_terminal
        equity_value = ev - net_debt
        
        # Sensibilité
        sensitivity = self._calculate_dcf_sensitivity(
            fcf_values, wacc, terminal_growth, net_debt
        )
        
        return {
            "method": "DCF (Discounted Cash Flow)",
            "enterprise_value": ev,
            "equity_value": equity_value,
            "pv_fcf": pv_fcf,
            "pv_terminal": pv_terminal,
            "wacc": wacc,
            "terminal_growth": terminal_growth,
            "fcf_projections": fcf_values,
            "sensitivity": sensitivity,
            "timestamp": datetime.now().isoformat()
        }
    
    def _calculate_dcf_sensitivity(
        self,
        fcf_values: List[float],
        base_wacc: float,
        base_growth: float,
        net_debt: float
    ) -> Dict:
        """Calcule la matrice de sensibilité DCF"""
        wacc_range = [base_wacc - 0.02, base_wacc, base_wacc + 0.02]
        growth_range = [base_growth - 0.01, base_growth, base_growth + 0.01]
        
        matrix = {}
        for wacc in wacc_range:
            matrix[f"{wacc*100:.0f}%"] = {}
            for growth in growth_range:
                # Recalcul rapide
                pv_fcf = sum(
                    fcf / ((1 + wacc) ** (i + 1))
                    for i, fcf in enumerate(fcf_values)
                )
                terminal_fcf = fcf_values[-1] * (1 + growth)
                terminal_value = terminal_fcf / (wacc - growth)
                pv_terminal = terminal_value / ((1 + wacc) ** len(fcf_values))
                ev = pv_fcf + pv_terminal
                
                matrix[f"{wacc*100:.0f}%"][f"{growth*100:.1f}%"] = round((ev - net_debt) / 1e6, 1)
        
        return matrix


def format_currency(value: float) -> str:
    """Formate un montant en euros"""
    if value >= 1e6:
        return f"{value/1e6:.2f}M€"
    elif value >= 1e3:
        return f"{value/1e3:.0f}k€"
    return f"{value:,.0f}€"


def main():
    parser = argparse.ArgumentParser(description="M&A Valuation Engine")
    parser.add_argument("--ebitda", type=float, required=True, help="EBITDA en euros")
    parser.add_argument("--sector", type=str, default="services", help="Secteur d'activité")
    parser.add_argument("--net-debt", type=float, default=0, help="Dette nette")
    parser.add_argument("--growth-rate", type=float, default=0, help="Taux de croissance")
    parser.add_argument("--margin", type=float, default=0, help="Marge EBITDA")
    parser.add_argument("--client-concentration", type=float, default=0, help="Concentration client")
    parser.add_argument("--debt-ebitda", type=float, default=0, help="Ratio dette/EBITDA")
    parser.add_argument("--multiple-range", type=str, help="Fourchette multiple manuelle (ex: 4-7)")
    parser.add_argument("--dcf", action="store_true", help="Utiliser méthode DCF")
    parser.add_argument("--projections", type=str, help="Fichier JSON projections")
    parser.add_argument("--wacc", type=float, default=0.12, help="WACC pour DCF")
    parser.add_argument("--pretty", action="store_true", help="Sortie formatée")
    
    args = parser.parse_args()
    
    engine = ValuationEngine()
    
    if args.dcf and args.projections:
        with open(args.projections) as f:
            projections = json.load(f)
        result = engine.valuate_by_dcf(
            projections=projections,
            wacc=args.wacc,
            net_debt=args.net_debt
        )
    else:
        result = engine.valuate_by_multiples(
            ebitda=args.ebitda,
            sector=args.sector,
            net_debt=args.net_debt,
            growth_rate=args.growth_rate,
            margin=args.margin,
            client_concentration=args.client_concentration,
            debt_ebitda=args.debt_ebitda
        )
    
    if args.pretty:
        print("\n" + "="*60)
        print(f"VALORISATION M&A — {result['method']}")
        print("="*60)
        
        if "enterprise_value" in result:
            if isinstance(result["enterprise_value"], dict):
                print(f"\n📊 VALEUR D'ENTREPRISE (EV)")
                print(f"   Fourchette: {result['enterprise_value']['formatted']}")
                print(f"\n📊 VALEUR DES CAPITAUX PROPRES")
                print(f"   Fourchette: {result['equity_value']['formatted']}")
            else:
                print(f"\n📊 VALEUR D'ENTREPRISE (EV): {format_currency(result['enterprise_value'])}")
                print(f"📊 VALEUR DES CAPITAUX PROPRES: {format_currency(result['equity_value'])}")
        
        if "multiple" in result:
            print(f"\n📈 MULTIPLES")
            print(f"   Base: {result['multiple']['base'][0]}x - {result['multiple']['base'][1]}x")
            print(f"   Ajusté: {result['multiple']['adjusted'][0]}x - {result['multiple']['adjusted'][1]}x")
        
        if result.get("assumptions"):
            print(f"\n📝 HYPOTHÈSES")
            for assumption in result["assumptions"]:
                print(f"   • {assumption}")
        
        if result.get("warnings"):
            print(f"\n⚠️  ALERTES")
            for warning in result["warnings"]:
                print(f"   • {warning}")
        
        print("\n" + "="*60)
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
