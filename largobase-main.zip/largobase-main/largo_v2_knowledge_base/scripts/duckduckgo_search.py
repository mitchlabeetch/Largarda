#!/usr/bin/env python3
"""
duckduckgo_search.py - Module de recherche web via DuckDuckGo
Largo 2.0 - n8n Architecture Edition

Alternative gratuite à Brave Search API.
Pas de clé API requise.
"""

import json
import sys
from typing import List, Dict, Optional
from dataclasses import dataclass
import logging

# Configuration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Essayer d'importer duckduckgo-search
try:
    from duckduckgo_search import DDGS
    DDGS_AVAILABLE = True
except ImportError:
    logger.warning("duckduckgo-search non installé. Utilisation fallback.")
    DDGS_AVAILABLE = False


@dataclass
class SearchResult:
    """Structure pour un résultat de recherche"""
    title: str
    link: str
    snippet: str
    source: str = "DuckDuckGo"
    
    def to_dict(self) -> Dict:
        return {
            "title": self.title,
            "link": self.link,
            "snippet": self.snippet,
            "source": self.source
        }


class DuckDuckGoSearcher:
    """Classe pour la recherche DuckDuckGo"""
    
    def __init__(self):
        self.ddgs = None
        if DDGS_AVAILABLE:
            try:
                self.ddgs = DDGS()
            except Exception as e:
                logger.error(f"Erreur initialisation DDGS: {e}")
    
    def search_text(self, query: str, max_results: int = 10, region: str = "fr-fr") -> List[SearchResult]:
        """
        Recherche texte via DuckDuckGo
        
        Args:
            query: Requête de recherche
            max_results: Nombre maximum de résultats
            region: Région (fr-fr, en-us, etc.)
        
        Returns:
            Liste de SearchResult
        """
        logger.info(f"Recherche DDG: '{query}' (max: {max_results})")
        
        if not DDGS_AVAILABLE or not self.ddgs:
            logger.error("DDGS non disponible")
            return []
        
        try:
            results = self.ddgs.text(
                query,
                max_results=max_results,
                region=region
            )
            
            return [
                SearchResult(
                    title=r.get("title", ""),
                    link=r.get("href", ""),
                    snippet=r.get("body", "")
                )
                for r in results
            ]
        except Exception as e:
            logger.error(f"Erreur recherche DDG: {e}")
            return []
    
    def search_news(self, query: str, max_results: int = 10, region: str = "fr-fr") -> List[SearchResult]:
        """
        Recherche actualités via DuckDuckGo
        
        Args:
            query: Requête de recherche
            max_results: Nombre maximum de résultats
            region: Région (fr-fr, en-us, etc.)
        
        Returns:
            Liste de SearchResult
        """
        logger.info(f"Recherche news DDG: '{query}' (max: {max_results})")
        
        if not DDGS_AVAILABLE or not self.ddgs:
            logger.error("DDGS non disponible")
            return []
        
        try:
            results = self.ddgs.news(
                query,
                max_results=max_results,
                region=region
            )
            
            return [
                SearchResult(
                    title=r.get("title", ""),
                    link=r.get("url", ""),
                    snippet=r.get("body", ""),
                    source=r.get("source", "DuckDuckGo News")
                )
                for r in results
            ]
        except Exception as e:
            logger.error(f"Erreur recherche news DDG: {e}")
            return []
    
    def search_images(self, query: str, max_results: int = 10) -> List[Dict]:
        """
        Recherche d'images via DuckDuckGo
        
        Args:
            query: Requête de recherche
            max_results: Nombre maximum de résultats
        
        Returns:
            Liste de dictionnaires avec image info
        """
        logger.info(f"Recherche images DDG: '{query}' (max: {max_results})")
        
        if not DDGS_AVAILABLE or not self.ddgs:
            logger.error("DDGS non disponible")
            return []
        
        try:
            results = self.ddgs.images(query, max_results=max_results)
            
            return [
                {
                    "title": r.get("title", ""),
                    "image": r.get("image", ""),
                    "thumbnail": r.get("thumbnail", ""),
                    "url": r.get("url", ""),
                    "source": r.get("source", "")
                }
                for r in results
            ]
        except Exception as e:
            logger.error(f"Erreur recherche images DDG: {e}")
            return []
    
    def get_instant_answer(self, query: str) -> Optional[str]:
        """
        Obtient une réponse instantanée si disponible
        
        Args:
            query: Requête
        
        Returns:
            Réponse instantanée ou None
        """
        # DuckDuckGo n'a pas d'API directe pour instant answer
        # On peut approximer avec la première recherche
        results = self.search_text(query, max_results=1)
        
        if results:
            return results[0].snippet
        
        return None


# Fonctions utilitaires pour n8n

def search_web(query: str, max_results: int = 5, region: str = "fr-fr") -> Dict:
    """
    Recherche web générale
    Utilisable depuis n8n Function Node
    """
    searcher = DuckDuckGoSearcher()
    results = searcher.search_text(query, max_results, region)
    
    return {
        "query": query,
        "results_count": len(results),
        "results": [r.to_dict() for r in results]
    }


def search_news(query: str, max_results: int = 10, region: str = "fr-fr") -> Dict:
    """
    Recherche actualités
    Utilisable depuis n8n Function Node
    """
    searcher = DuckDuckGoSearcher()
    results = searcher.search_news(query, max_results, region)
    
    return {
        "query": query,
        "results_count": len(results),
        "results": [r.to_dict() for r in results]
    }


def search_mna_news(date_filter: str = "today") -> Dict:
    """
    Recherche actualités M&A France
    
    Args:
        date_filter: today, week, month
    
    Returns:
        Résultats de recherche
    """
    queries = [
        "fusion acquisition France",
        "M&A France actualité",
        "cession entreprise France",
        "LBO France",
        "private equity France"
    ]
    
    searcher = DuckDuckGoSearcher()
    all_results = []
    
    for query in queries:
        results = searcher.search_news(query, max_results=5)
        all_results.extend(results)
    
    # Dédoublonnage par URL
    seen_urls = set()
    unique_results = []
    
    for r in all_results:
        if r.link not in seen_urls:
            seen_urls.add(r.link)
            unique_results.append(r)
    
    return {
        "query": "M&A France news",
        "results_count": len(unique_results),
        "results": [r.to_dict() for r in unique_results[:20]]
    }


def search_company_news(company_name: str, max_results: int = 10) -> Dict:
    """
    Recherche actualités sur une entreprise spécifique
    
    Args:
        company_name: Nom de l'entreprise
        max_results: Nombre max de résultats
    
    Returns:
        Résultats de recherche
    """
    queries = [
        f"{company_name} acquisition",
        f"{company_name} cession",
        f"{company_name} fusion",
        f"{company_name} actualité"
    ]
    
    searcher = DuckDuckGoSearcher()
    all_results = []
    
    for query in queries:
        results = searcher.search_news(query, max_results=5)
        all_results.extend(results)
    
    # Dédoublonnage
    seen_urls = set()
    unique_results = []
    
    for r in all_results:
        if r.link not in seen_urls:
            seen_urls.add(r.link)
            unique_results.append(r)
    
    return {
        "company": company_name,
        "results_count": len(unique_results),
        "results": [r.to_dict() for r in unique_results[:max_results]]
    }


if __name__ == "__main__":
    # Test
    import argparse
    
    parser = argparse.ArgumentParser(description="DuckDuckGo Search for Largo")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--type", choices=["web", "news", "mna", "company"], default="web")
    parser.add_argument("--max", type=int, default=5)
    
    args = parser.parse_args()
    
    if args.type == "web":
        result = search_web(args.query, args.max)
    elif args.type == "news":
        result = search_news(args.query, args.max)
    elif args.type == "mna":
        result = search_mna_news()
    elif args.type == "company":
        result = search_company_news(args.query, args.max)
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
