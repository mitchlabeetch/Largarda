#!/usr/bin/env python3
"""
browser_scraper.py - Module de scraping web avec Playwright
Largo 2.0 - n8n Architecture Edition

Utilise Playwright pour le scraping avancé quand les APIs ne suffisent pas.
"""

import json
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse
import logging

# Configuration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Essayer d'importer playwright
try:
    from playwright.async_api import async_playwright, Page, Browser
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    logger.warning("playwright non installé. Scraping désactivé.")
    PLAYWRIGHT_AVAILABLE = False


@dataclass
class ScrapedContent:
    """Structure pour le contenu scrapé"""
    url: str
    title: str
    text: str
    links: List[Dict]
    images: List[Dict]
    metadata: Dict
    
    def to_dict(self) -> Dict:
        return {
            "url": self.url,
            "title": self.title,
            "text": self.text[:5000] + "..." if len(self.text) > 5000 else self.text,
            "links": self.links[:20],
            "images": self.images[:10],
            "metadata": self.metadata
        }


class BrowserScraper:
    """Scraper basé sur Playwright"""
    
    def __init__(self, headless: bool = True):
        self.headless = headless
        self.browser: Optional[Browser] = None
        self.playwright = None
    
    async def __aenter__(self):
        if PLAYWRIGHT_AVAILABLE:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=self.headless)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
    
    async def scrape_page(self, url: str, wait_for: str = None, timeout: int = 30000) -> Optional[ScrapedContent]:
        """
        Scrape une page web
        
        Args:
            url: URL à scraper
            wait_for: Sélecteur CSS à attendre
            timeout: Timeout en ms
        
        Returns:
            ScrapedContent ou None
        """
        if not PLAYWRIGHT_AVAILABLE or not self.browser:
            logger.error("Playwright non disponible")
            return None
        
        logger.info(f"Scraping: {url}")
        
        try:
            context = await self.browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            )
            page = await context.new_page()
            
            # Navigation
            response = await page.goto(url, wait_until="networkidle", timeout=timeout)
            
            if not response or response.status >= 400:
                logger.warning(f"Erreur HTTP {response.status if response else 'unknown'}")
                await context.close()
                return None
            
            # Attente élément si spécifié
            if wait_for:
                await page.wait_for_selector(wait_for, timeout=10000)
            
            # Extraction données
            title = await page.title()
            
            # Texte principal
            text = await page.evaluate("""() => {
                const article = document.querySelector('article');
                const main = document.querySelector('main');
                const content = document.querySelector('.content, .article-content, .post-content');
                
                if (article) return article.innerText;
                if (main) return main.innerText;
                if (content) return content.innerText;
                
                // Fallback: paragraphes
                return Array.from(document.querySelectorAll('p'))
                    .map(p => p.innerText)
                    .filter(t => t.length > 50)
                    .join('\\n\\n');
            }""")
            
            # Liens
            links = await page.evaluate("""() => {
                return Array.from(document.querySelectorAll('a[href]'))
                    .map(a => ({
                        text: a.innerText.trim(),
                        href: a.href,
                        is_external: !a.href.includes(window.location.hostname)
                    }))
                    .filter(l => l.text.length > 0)
                    .slice(0, 50);
            }""")
            
            # Images
            images = await page.evaluate("""() => {
                return Array.from(document.querySelectorAll('img[src]'))
                    .map(img => ({
                        src: img.src,
                        alt: img.alt,
                        width: img.width,
                        height: img.height
                    }))
                    .filter(i => i.width > 100 && i.height > 100)
                    .slice(0, 20);
            }""")
            
            # Métadonnées
            metadata = await page.evaluate("""() => {
                const meta = {};
                document.querySelectorAll('meta').forEach(m => {
                    const name = m.getAttribute('name') || m.getAttribute('property');
                    const content = m.getAttribute('content');
                    if (name && content) meta[name] = content;
                });
                return meta;
            }""")
            
            await context.close()
            
            return ScrapedContent(
                url=url,
                title=title,
                text=text or "",
                links=links,
                images=images,
                metadata=metadata
            )
            
        except Exception as e:
            logger.error(f"Erreur scraping {url}: {e}")
            return None
    
    async def scrape_article(self, url: str) -> Optional[Dict]:
        """
        Scrape un article avec extraction intelligente
        
        Args:
            url: URL de l'article
        
        Returns:
            Données extraites
        """
        content = await self.scrape_page(url)
        
        if not content:
            return None
        
        # Extraction date si possible
        date = None
        for key in ["article:published_time", "datePublished", "publishedDate", "date"]:
            if key in content.metadata:
                date = content.metadata[key]
                break
        
        # Extraction auteur
        author = None
        for key in ["author", "article:author", "twitter:creator"]:
            if key in content.metadata:
                author = content.metadata[key]
                break
        
        return {
            "url": content.url,
            "title": content.title,
            "text": content.text,
            "date": date,
            "author": author,
            "source": urlparse(url).netloc,
            "images": [img["src"] for img in content.images[:5]]
        }
    
    async def search_and_scrape(self, query: str, max_results: int = 5) -> List[Dict]:
        """
        Recherche sur Google et scrape les résultats
        
        Args:
            query: Requête de recherche
            max_results: Nombre max de résultats à scraper
        
        Returns:
            Liste de contenus scrapés
        """
        if not PLAYWRIGHT_AVAILABLE:
            logger.error("Playwright non disponible")
            return []
        
        logger.info(f"Search & scrape: '{query}'")
        
        search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        
        try:
            context = await self.browser.new_context()
            page = await context.new_page()
            
            await page.goto(search_url, wait_until="networkidle")
            
            # Extraction URLs résultats
            result_urls = await page.evaluate("""() => {
                return Array.from(document.querySelectorAll('div.g a[href]'))
                    .map(a => a.href)
                    .filter(href => href.startsWith('http') && !href.includes('google'))
                    .slice(0, 10);
            }""")
            
            await context.close()
            
            # Scrape chaque résultat
            results = []
            for url in result_urls[:max_results]:
                content = await self.scrape_article(url)
                if content:
                    results.append(content)
            
            return results
            
        except Exception as e:
            logger.error(f"Erreur search & scrape: {e}")
            return []


# Fonctions utilitaires pour n8n

async def scrape_url(url: str, extract_article: bool = True) -> Dict:
    """
    Scrape une URL
    Utilisable depuis n8n (via HTTP Request ou Function)
    """
    async with BrowserScraper(headless=True) as scraper:
        if extract_article:
            result = await scraper.scrape_article(url)
        else:
            content = await scraper.scrape_page(url)
            result = content.to_dict() if content else None
        
        return {
            "success": result is not None,
            "url": url,
            "data": result or {}
        }


def scrape_url_sync(url: str, extract_article: bool = True) -> Dict:
    """Version synchrone pour n8n"""
    return asyncio.run(scrape_url(url, extract_article))


async def deep_research(query: str, max_sources: int = 5) -> Dict:
    """
    Recherche approfondie avec scraping multi-sources
    
    Args:
        query: Requête de recherche
        max_sources: Nombre max de sources
    
    Returns:
        Résultats agrégés
    """
    async with BrowserScraper(headless=True) as scraper:
        results = await scraper.search_and_scrape(query, max_sources)
        
        # Agrégation
        combined_text = "\n\n---\n\n".join([
            f"Source: {r['source']}\nTitle: {r['title']}\n\n{r['text'][:2000]}"
            for r in results
        ])
        
        return {
            "query": query,
            "sources_count": len(results),
            "sources": [{"url": r["url"], "title": r["title"], "source": r["source"]} for r in results],
            "combined_text": combined_text[:10000]  # Limite pour LLM
        }


def deep_research_sync(query: str, max_sources: int = 5) -> Dict:
    """Version synchrone pour n8n"""
    return asyncio.run(deep_research(query, max_sources))


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Browser Scraper for Largo")
    parser.add_argument("url", help="URL to scrape")
    parser.add_argument("--article", action="store_true", help="Extract as article")
    
    args = parser.parse_args()
    
    result = scrape_url_sync(args.url, args.article)
    print(json.dumps(result, indent=2, ensure_ascii=False))
