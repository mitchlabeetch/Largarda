# SKILLS.md — Largo 2.0 Capabilities & Skills

> Version: 2.0 — n8n Architecture Edition
> Last Updated: 2026-03-18

---

## 🎯 Vue d'Ensemble des Capacités

Largo 2.0 repose sur une architecture de **workflows n8n** et **microservices Python** plutôt que sur le système de skills OpenClaw. Cette approche offre:

- ✅ Plus de contrôle sur le code
- ✅ Meilleure sécurité (pas de skills non vérifiés)
- ✅ Débogage facilité
- ✅ Intégration native n8n

---

## 📁 Structure des Capacités

```
skills/
├── workflows/              # Workflows n8n (JSON)
│   ├── mna/
│   │   ├── research-company.json
│   │   ├── analyze-financials.json
│   │   └── generate-valuation.json
│   ├── documents/
│   │   ├── create-excel.json
│   │   ├── create-pptx.json
│   │   └── parse-pdf.json
│   ├── communication/
│   │   ├── send-whatsapp.json
│   │   ├── send-email.json
│   │   └── read-inbox.json
│   └── routines/
│       ├── daily-mna-summary.json
│       ├── meeting-prep.json
│       └── prospect-enrichment.json
│
├── microservices/          # Services Python
│   ├── pptx-generator/
│   ├── mna-research/
│   ├── audio-processor/
│   └── document-parser/
│
└── integrations/           # Connecteurs n8n
    ├── whatsapp-baileys/
    ├── microsoft-graph/
    └── pipedrive/
```

---

## 🔍 M&A & Finance

### 1. Recherche Entreprise (Complete)

**Workflow** : `mna/research-company.json`

**Description** : Recherche complète d'une entreprise française

**Inputs** :
```json
{
  "identifier": "34977287100027",  // SIRET, SIREN, ou nom
  "identifier_type": "siret",      // siret, siren, name
  "include_financials": true,
  "include_news": true,
  "include_risks": true
}
```

**Outputs** :
```json
{
  "sirene": {
    "siren": "349772871",
    "siret": "34977287100027",
    "denomination": "ALECIA CONSEIL",
    "forme_juridique": "SAS",
    "date_creation": "1989-01-01",
    "code_naf": "7022Z",
    "libelle_naf": "Conseil pour les affaires et autres conseils de gestion",
    "effectif": "20 à 49 salariés",
    "capital": 100000
  },
  "pappers": {
    "dirigeants": [...],
    "beneficiaires": [...],
    "documents": [...],
    "ratios": {...}
  },
  "financials": {
    "ca": [/* historique */],
    "resultat": [/* historique */],
    "ebe": "calculated"
  },
  "news": [...],
  "risks": [...],
  "valuation_indication": {
    "multiple_ebitda_range": [4.5, 6.5],
    "estimated_value_range": "2.1M€ - 3.0M€"
  }
}
```

**n8n Nodes** :
1. Webhook Trigger
2. Parse Input
3. Parallel API Calls (SIRENE, Pappers)
4. Data Merge
5. Financial Analysis (Kimi)
6. Response Formatting

---

### 2. Analyse Financière

**Workflow** : `mna/analyze-financials.json`

**Description** : Analyse approfondie des comptes d'une entreprise

**Inputs** :
```json
{
  "siren": "349772871",
  "years": 3,
  "include_benchmark": true,
  "sector": "conseil_gestion"
}
```

**Analyses** :
- Ratios financiers (rentabilité, structure, liquidité)
- Évolution sur N années
- Benchmark sectoriel
- Tendances et alertes

**Ratios calculés** :
```python
ratios = {
    "rentabilite": {
        "roe": "Résultat net / Capitaux propres",
        "roa": "Résultat net / Total actif",
        "marge_nette": "Résultat net / CA",
        "marge_operationnelle": "EBE / CA"
    },
    "structure": {
        "autonomie_financiere": "Capitaux propres / Total passif",
        "endettement": "Dettes / Capitaux propres",
        "leverage": "Dettes nettes / EBE"
    },
    "liquidite": {
        "fr": "FR = Ressources stables - Actif immobilisé",
        "bfre": "BFRE = Actif circulant - Passif circulant",
        "treorerie": "Trésorerie active - Trésorerie passive"
    }
}
```

---

### 3. Valorisation

**Workflow** : `mna/generate-valuation.json`

**Description** : Génération d'une fourchette de valorisation

**Méthodes** :
1. **Multiples sectoriels** (préféré small-mid cap)
2. **DCF simplifié** (si données suffisantes)
3. **Actif net corrigé** (si holding/patrimonial)

**Multiples par secteur (Small-Mid Cap France)** :

| Secteur | Multiple EV/EBITDA | Multiple EV/EBE |
|---------|-------------------|-----------------|
| Industrie | 4.5x - 6.5x | 5.0x - 7.0x |
| Services | 5.0x - 7.5x | 6.0x - 9.0x |
| Distribution | 4.0x - 6.0x | 4.5x - 6.5x |
| BTP | 3.5x - 5.5x | 4.0x - 6.0x |
| Tech/SaaS | 6.0x - 10.0x | 8.0x - 15.0x |

**Output** :
```json
{
  "methodologie": "Multiples sectoriels",
  "fourchette_basse": "2.1M€",
  "fourchette_haute": "3.0M€",
  "multiple_median": "5.5x EBE",
  "hypotheses": [...],
  "sensibilite": {
    "multiple_4x": "1.8M€",
    "multiple_6x": "2.7M€",
    "multiple_8x": "3.6M€"
  },
  "comparables": [...]
}
```

---

## 📄 Documents

### 4. Génération Excel

**Workflow** : `documents/create-excel.json`

**Description** : Création de tableaux Excel avancés

**Features** :
- Formules complexes
- Tableaux croisés dynamiques
- Graphiques
- Formatage conditionnel
- Multi-feuilles

**Input** :
```json
{
  "template": "analyse_prospects",
  "data": {
    "prospects": [...],
    "columns": ["nom", "secteur", "ca", "ebitda", "effectif"]
  },
  "formatting": {
    "conditional_rules": [...],
    "charts": [...]
  }
}
```

---

### 5. Génération PowerPoint

**Workflow** : `documents/create-pptx.json`

**Microservice** : `pptx-generator/`

**Description** : Génération de présentations depuis templates

**Templates disponibles** :
- `executive_summary.pptx` — Résumé exécutif
- `company_profile.pptx` — Profil entreprise
- `valuation_report.pptx` — Rapport de valorisation
- `teaser_acquisition.pptx` — Teaser anonymisé

**Input** :
```json
{
  "template": "templates/executive_summary.pptx",
  "data": {
    "project_name": "Projet Acquisition - Société X",
    "date": "2026-03-18",
    "slides": [...]
  }
}
```

**Python Service** :
```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RgbColor

def generate_pptx(template_path, data, output_path):
    prs = Presentation(template_path)
    
    # Update title slide
    title_slide = prs.slides[0]
    title_slide.shapes.title.text = data["project_name"]
    title_slide.placeholders[1].text = data["date"]
    
    # Add/update content slides
    for slide_data in data["slides"]:
        slide = add_slide_from_layout(prs, slide_data["type"])
        populate_slide(slide, slide_data)
    
    prs.save(output_path)
    return output_path
```

---

### 6. Parsing PDF

**Workflow** : `documents/parse-pdf.json`

**Microservice** : `document-parser/`

**Features** :
- Extraction texte
- OCR (images scannées)
- Table extraction
- Métadonnées

**Output** :
```json
{
  "text": "...",
  "pages": [
    {"page_num": 1, "text": "...", "tables": [...]}
  ],
  "metadata": {
    "title": "...",
    "author": "...",
    "creation_date": "..."
  }
}
```

---

## 💬 Communication

### 7. WhatsApp

**Workflow** : `communication/send-whatsapp.json`

**Integration** : Baileys (n8n custom node)

**Features** :
- Text messages
- Audio messages (TTS)
- Media (images, documents)
- Read receipts
- Typing indicators

**n8n Node Configuration** :
```json
{
  "name": "Send WhatsApp",
  "type": "largoWhatsApp",
  "operation": "send",
  "jid": "={{ $json.recipient_jid }}",
  "message": "={{ $json.message }}",
  "options": {
    "quoted": "={{ $json.quote_message_id }}",
    "mentions": "={{ $json.mentions }}"
  }
}
```

---

### 8. Email

**Workflow** : `communication/send-email.json`

**Integration** : Microsoft Graph / SMTP

**Features** :
- HTML/Text emails
- Pièces jointes
- CC/BCC
- Templates

**Input** :
```json
{
  "to": ["christophe@alecia.fr"],
  "subject": "Analyse M&A - Société X",
  "body_html": "<p>Voici l'analyse...</p>",
  "attachments": [
    {"filename": "analyse.xlsx", "path": "/tmp/analyse.xlsx"}
  ]
}
```

---

### 9. Lecture Inbox

**Workflow** : `communication/read-inbox.json`

**Triggers** :
- IMAP polling (toutes les 5 min)
- Microsoft Graph webhook

**Filters** :
- Expéditeur
- Sujet (regex)
- Pièces jointes
- Date

---

## 🔄 Routines Automatisées

### 10. Résumé M&A Quotidien

**Workflow** : `routines/daily-mna-summary.json`

**Schedule** : `0 9 * * *` (9h Europe/Paris)

**Sources** :
- Les Echos M&A
- CFNews
- Capital Finance
- Reuters France
- Bloomberg Europe

**Output** :
```
📰 Résumé M&A du 18 mars 2026

🇫🇷 France
• [Titre] — [Source] — [Résumé 2 lignes]

🇪🇺 Europe (gros dossiers)
• [Titre] — [Source] — [Résumé 2 lignes]

📊 Tendance du jour
• [Observation sectorielle]
```

---

### 11. Préparation Réunion

**Workflow** : `routines/meeting-prep.json`

**Trigger** : 45 min avant chaque réunion Teams

**Actions** :
1. Lire détails réunion (Graph API)
2. Identifier participants
3. Rechercher dernières interactions (Pipedrive, Emails)
4. Générer résumé
5. Envoyer WhatsApp

**Output** :
```
📅 Réunion dans 45 min : [Sujet]

👥 Participants :
• [Nom] — [Entreprise] — [Rôle]

📝 Derniers échanges :
• [Date] : [Sujet email/call]

📊 Métriques prospect :
• CA : X M€
• Secteur : [Secteur]
• Localisation : [Ville]

💡 Suggestions :
• [Point à aborder]
```

---

### 12. Enrichissement Prospects

**Workflow** : `routines/prospect-enrichment.json`

**Trigger** : Manuel ou quotidien

**Process** :
1. Lire liste prospects (Pipedrive)
2. Pour chaque prospect avec données incomplètes :
   - Recherche SIRENE/Pappers
   - Mise à jour fiche Pipedrive
   - Notification si données importantes trouvées

---

## 🐍 Microservices Python

### Structure Standard

```python
# microservices/service-name/app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Largo Service: [Name]")

class InputModel(BaseModel):
    # Define input schema
    pass

class OutputModel(BaseModel):
    # Define output schema
    pass

@app.post("/process", response_model=OutputModel)
async def process(input_data: InputModel):
    try:
        result = await process_logic(input_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### Dockerfile Standard

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "app.py"]
```

---

## 📊 Matrice de Compétences

| Capacité | n8n Workflow | Python Service | API Externe | Status |
|----------|--------------|----------------|-------------|--------|
| Recherche entreprise | ✅ | ✅ | SIRENE, Pappers | Ready |
| Analyse financière | ✅ | ✅ | - | Ready |
| Valorisation | ✅ | - | - | Ready |
| Génération Excel | ✅ | - | - | Ready |
| Génération PPTX | ✅ | ✅ | - | Ready |
| Parsing PDF | ✅ | ✅ | - | Ready |
| WhatsApp | ✅ | - | Baileys | Ready |
| Email | ✅ | - | Graph/SMTP | Ready |
| Résumé M&A | ✅ | - | News APIs | Ready |
| Préparation réunion | ✅ | - | Graph, Pipedrive | Ready |
| TTS/STT | ✅ | ✅ | edge-tts, whisper | Ready |
| OCR | ✅ | ✅ | PaddleOCR | Ready |

---

*Largo 2.0 — Capacités maîtrisées, workflows fluides.*
